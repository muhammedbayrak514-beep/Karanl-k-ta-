extends Node

const ProjectileScript = preload("res://scripts/siege_projectile.gd")

signal siege_status_changed(text: String, gate_health: float, gate_max_health: float)

const GATE_MAX_HEALTH: float = 900.0
const CATAPULT_COST: int = 25
const CATAPULT_COOLDOWN: float = 12.0
const COURTYARD_CENTER := Vector3(0.0, 0.0, -47.0)
const SIEGE_SITES: Dictionary = {
	"frontier_castle": {"name": "Karanlık Taç Kalesi", "center": Vector3(0.0, 0.0, -33.0), "gate_node": "GateWoodenDoors", "courtyard_center": Vector3(0.0, 0.0, -47.0), "half_x": 10.5, "min_z": -55.5, "max_z": -39.5, "territory": "frontier_castle"},
	"eastwatch_fort": {"name": "Doğu Gözetleme Kalesi", "center": Vector3(362.0, 0.0, -20.0), "gate_node": "GateEastWatch", "courtyard_center": Vector3(362.0, 0.0, -19.3), "half_x": 8.5, "min_z": -25.0, "max_z": -9.0, "territory": "eastern_watch"},
	"frost_hold": {"name": "Karakış Kal'ası", "center": Vector3(-292.0, 0.0, -325.0), "gate_node": "GateFrostHold", "courtyard_center": Vector3(-292.0, 0.0, -324.3), "half_x": 8.5, "min_z": -330.0, "max_z": -314.0, "territory": "frost_monastery"}
}

var game_ref: Variant = null
var arena_ref: Variant = null
var gate_visual: Variant = null
var gate_health: float = GATE_MAX_HEALTH
var siege_started: bool = false
var gate_assault_active: bool = false
var capture_attempt_active: bool = false
var castle_captured: bool = false
var capture_progress: float = 0.0
var catapult_cooldown: float = 0.0
var _assault_tick: float = 0.0
var _tower_tick: float = 0.0
var _status_tick: float = 0.0
var _player_gate_cooldown: float = 0.0
var _gate_collision_removed: bool = false
var _last_notice: String = ""
var active_site_id: String = "frontier_castle"
var site_states: Dictionary = {}

func initialize(game: Variant, arena: Variant, saved_world: Dictionary = {}) -> void:
	game_ref = game
	arena_ref = arena
	var nested_value: Variant = saved_world.get("sieges", {})
	var nested: Dictionary = nested_value if nested_value is Dictionary else {}
	var states_value: Variant = nested.get("sites", {})
	var saved_sites: Dictionary = states_value if states_value is Dictionary else {}
	for site_id in SIEGE_SITES.keys():
		var state: Dictionary = {"gate_health": GATE_MAX_HEALTH, "castle_captured": false, "siege_started": false, "gate_assault_active": false, "capture_attempt_active": false, "capture_progress": 0.0}
		if saved_sites.get(site_id, {}) is Dictionary:
			state.merge(saved_sites.get(site_id, {}), true)
		elif site_id == "frontier_castle":
			# Keep v0.14 saves compatible with the original single-castle fields.
			state["gate_health"] = float(saved_world.get("gate_health", GATE_MAX_HEALTH))
			state["castle_captured"] = bool(saved_world.get("castle_captured", false))
			state["siege_started"] = bool(saved_world.get("siege_started", false))
			state["gate_assault_active"] = bool(saved_world.get("gate_assault_active", false))
			state["capture_attempt_active"] = bool(saved_world.get("capture_attempt_active", false))
			state["capture_progress"] = float(saved_world.get("capture_progress", 0.0))
		state["gate_health"] = clampf(float(state.get("gate_health", GATE_MAX_HEALTH)), 0.0, GATE_MAX_HEALTH)
		state["castle_captured"] = bool(state.get("castle_captured", false))
		state["siege_started"] = bool(state.get("siege_started", false)) and not bool(state["castle_captured"])
		state["gate_assault_active"] = bool(state.get("gate_assault_active", false)) and bool(state["siege_started"]) and float(state["gate_health"]) > 0.0
		state["capture_attempt_active"] = bool(state.get("capture_attempt_active", false)) and bool(state["siege_started"]) and float(state["gate_health"]) <= 0.0 and not bool(state["castle_captured"])
		state["capture_progress"] = clampf(float(state.get("capture_progress", 0.0)), 0.0, 10.0)
		site_states[str(site_id)] = state
	active_site_id = str(nested.get("active_site_id", "frontier_castle"))
	if not SIEGE_SITES.has(active_site_id):
		active_site_id = "frontier_castle"
	_load_active_site_state()
	_emit_status()

func _process(delta: float) -> void:
	if not is_instance_valid(game_ref) or game_ref.game_over:
		return
	_try_auto_select_site()
	catapult_cooldown = maxf(0.0, catapult_cooldown - delta)
	_player_gate_cooldown = maxf(0.0, _player_gate_cooldown - delta)
	_assault_tick -= delta
	_tower_tick -= delta
	_status_tick -= delta

	if siege_started and gate_assault_active and gate_health > 0.0 and _assault_tick <= 0.0:
		_assault_tick = 0.85
		var attackers: int = _count_allies_at_gate()
		if attackers > 0:
			apply_gate_damage(float(attackers) * 18.0, "Birlik hücumu")

	if siege_started and not castle_captured and gate_health > 0.0 and _tower_tick <= 0.0:
		_tower_tick = 3.7
		_fire_defensive_towers()

	if capture_attempt_active and not castle_captured:
		_update_capture_progress(delta)

	if _status_tick <= 0.0:
		_status_tick = 0.35
		_emit_status()

func request_command(command_id: String) -> void:
	if not is_instance_valid(game_ref) or not is_instance_valid(game_ref.player_unit):
		return
	_select_nearest_site()
	match command_id:
		"start":
			if castle_captured:
				_notice("Kale zaten senin kontrolünde.")
				return
			if game_ref.player_unit.global_position.distance_to(_gate_position()) > 68.0:
				var site_for_notice: Dictionary = SIEGE_SITES.get(active_site_id, SIEGE_SITES["frontier_castle"])
				_notice("Kuşatmayı başlatmak için %s yakınına git." % str(site_for_notice.get("name", "kaleye")))
				return
			siege_started = true
			_mark_dirty()
			_notice("Kuşatma başladı! Kapı düşmeden iç kaleyi ele geçiremezsin.")
		"assault":
			if not siege_started:
				_notice("Önce kuşatmayı başlat.")
				return
			if gate_health <= 0.0:
				_notice("Ana kapı yıkıldı. Fetih emri verebilirsin.")
				return
			gate_assault_active = true
			if game_ref.has_method("_issue_army_order"):
				game_ref._issue_army_order("charge")
			_notice("Birlik kapıya gönderildi! Askerlerin kapı çevresine ulaştıkça hasar verecek.")
		"catapult":
			_fire_catapult()
		"capture":
			if castle_captured:
				var captured_site: Dictionary = SIEGE_SITES.get(active_site_id, SIEGE_SITES["frontier_castle"])
				_notice("%s zaten senin kontrolünde." % str(captured_site.get("name", "Kale")))
				return
			if gate_health > 0.0:
				_notice("Fetih için önce ana kapıyı yıkmalısın.")
				return
			capture_attempt_active = true
			_notice("Fetih başladı! İç avluya gir ve savunmacıları temizle.")
		_:
			_notice("Bilinmeyen kuşatma emri.")
	_emit_status()

func try_player_attack_gate() -> bool:
	if not is_instance_valid(game_ref) or not is_instance_valid(game_ref.player_unit) or gate_health <= 0.0:
		return false
	if game_ref.player_unit.global_position.distance_to(_gate_position()) > 4.35:
		return false
	if _player_gate_cooldown > 0.0:
		return true
	_player_gate_cooldown = 0.82
	var base_damage: float = float(game_ref.player_unit.attack_damage) * 1.75
	apply_gate_damage(base_damage, "Komutanın saldırısı")
	return true

func is_unit_assaulting_gate() -> bool:
	return siege_started and gate_assault_active and gate_health > 0.0 and not castle_captured

func get_gate_approach_position(index: int) -> Vector3:
	# Sixteen non-overlapping slots cover the full leadership-upgraded army.
	var offsets: Array[float] = [-8.4, -7.28, -6.16, -5.04, -3.92, -2.8, -1.68, -0.56, 0.56, 1.68, 2.8, 3.92, 5.04, 6.16, 7.28, 8.4]
	var site: Dictionary = SIEGE_SITES.get(active_site_id, SIEGE_SITES["frontier_castle"])
	var center: Vector3 = site["center"]
	var x: float = center.x + float(offsets[clampi(index, 0, offsets.size() - 1)])
	var destination: Vector3 = Vector3(x, 0.0, _gate_position().z + 3.7)
	if is_instance_valid(arena_ref) and arena_ref.has_method("get_ground_height"):
		destination.y = arena_ref.get_ground_height(destination.x, destination.z)
	return destination

func apply_gate_damage(amount: float, source: String = "") -> void:
	if gate_health <= 0.0 or castle_captured or amount <= 0.0:
		return
	gate_health = maxf(0.0, gate_health - amount)
	_update_gate_visual()
	_mark_dirty()
	if gate_health <= 0.0:
		gate_assault_active = false
		capture_progress = 0.0
		_notice("ANA KAPI YIKILDI! İç avluya ilerle ve FETİH emrini ver.")
	else:
		_notice("Kapıya %.0f hasar (%s). Kalan dayanıklılık: %d/%d." % [amount, source, roundi(gate_health), roundi(GATE_MAX_HEALTH)])
	_emit_status()

func on_catapult_impact(impact_position: Vector3, damage: float) -> void:
	if not is_instance_valid(game_ref):
		return
	var gate_distance: float = Vector2(impact_position.x - _gate_position().x, impact_position.z - _gate_position().z).length()
	if gate_health > 0.0 and gate_distance <= 5.2:
		apply_gate_damage(damage, "Mancınık")
	else:
		_notice("Mancınık mermisi kapının yanına düştü; savunmacılar geri savruldu!")
		for unit in get_tree().get_nodes_in_group("battle_units"):
			if not is_instance_valid(unit) or unit.team != 1 or unit.health <= 0.0:
				continue
			if unit.global_position.distance_to(impact_position) <= 7.5:
				unit.receive_damage(damage * 0.45, null)

func get_catapult_cost() -> int:
	return CATAPULT_COST

func get_save_state() -> Dictionary:
	_flush_active_site_state()
	return {"active_site_id": active_site_id, "sites": site_states.duplicate(true), "gate_health": gate_health, "castle_captured": castle_captured, "siege_started": siege_started, "gate_assault_active": gate_assault_active, "capture_attempt_active": capture_attempt_active, "capture_progress": capture_progress}

func get_current_phase_name() -> String:
	var site: Dictionary = SIEGE_SITES.get(active_site_id, SIEGE_SITES["frontier_castle"])
	if castle_captured:
		return "%s · FETİH TAMAMLANDI" % str(site.get("name", "Kale"))
	if not siege_started:
		return "%s · 1/3 KUŞATMA HAZIRLIĞI" % str(site.get("name", "Kale"))
	if gate_health > 0.0:
		return "%s · 2/3 KAPI MUHASARASI" % str(site.get("name", "Kale"))
	return "%s · 3/3 İÇ AVLÜ VE FETİH" % str(site.get("name", "Kale"))

func get_status_text() -> String:
	var gate_text: String = "YIKILDI" if gate_health <= 0.0 else "%d/%d" % [roundi(gate_health), roundi(GATE_MAX_HEALTH)]
	var mode: String = "Kontrol sende" if castle_captured else ("Başlamadı" if not siege_started else ("Kapıya saldırılıyor" if gate_assault_active else "Aktif"))
	var catapult_text: String = "Hazır" if catapult_cooldown <= 0.0 else "%d sn" % ceili(catapult_cooldown)
	var capture_text: String = "Tamamlandı" if castle_captured else ("%d%%" % roundi(capture_progress / 10.0 * 100.0) if capture_attempt_active else "Başlatılmadı")
	return "%s\nKAPI: %s\nKUŞATMA: %s\nMANCINIK: %s  •  %d ALTIN\nFETİH: %s\nYakındaki sahaya yaklaş; üç kalenin ilerlemesi ayrı kaydedilir." % [get_current_phase_name(), gate_text, mode, catapult_text, CATAPULT_COST, capture_text]

func _fire_catapult() -> void:
	if castle_captured:
		_notice("Kale fethedildi; mancınığa artık gerek yok.")
		return
	if not siege_started:
		_notice("Önce kuşatmayı başlat.")
		return
	if catapult_cooldown > 0.0:
		_notice("Mancınık yeniden hazırlanıyor: %d saniye." % ceili(catapult_cooldown))
		return
	if int(game_ref.gold) < CATAPULT_COST:
		_notice("Mancınık atışı için %d altın gerekiyor." % CATAPULT_COST)
		return
	game_ref.gold -= CATAPULT_COST
	catapult_cooldown = CATAPULT_COOLDOWN
	_mark_dirty()
	var site: Dictionary = SIEGE_SITES.get(active_site_id, SIEGE_SITES["frontier_castle"])
	var center: Vector3 = site["center"]
	var origin: Vector3 = Vector3(center.x - 24.0, 0.0, center.z + 15.0)
	if is_instance_valid(arena_ref) and arena_ref.has_method("get_ground_height"):
		origin.y = arena_ref.get_ground_height(origin.x, origin.z) + 3.8
	var destination: Vector3 = _gate_position() + Vector3(0.0, -0.3, 0.0)
	var projectile: Variant = ProjectileScript.new()
	projectile.configure(self, origin, destination, 265.0)
	game_ref.add_child(projectile)
	_notice("Mancınık ateşlendi! Mermi yaklaşık iki saniye içinde düşecek.")

func _count_allies_at_gate() -> int:
	var count: int = 0
	for unit in get_tree().get_nodes_in_group("battle_units"):
		if not is_instance_valid(unit) or unit.team != 2 or unit.health <= 0.0:
			continue
		var approach: Vector3 = get_gate_approach_position(int(unit.formation_index))
		if unit.global_position.distance_to(approach) <= 2.8:
			count += 1
	return count

func _fire_defensive_towers() -> void:
	if not is_instance_valid(game_ref) or not game_ref.has_method("launch_arrow"):
		return
	var gate: Vector3 = _gate_position()
	var target: Variant = null
	var best_distance: float = 34.0
	if is_instance_valid(game_ref.player_unit) and game_ref.player_unit.health > 0.0:
		var player_distance: float = game_ref.player_unit.global_position.distance_to(gate)
		if player_distance < best_distance:
			best_distance = player_distance
			target = game_ref.player_unit
	for unit in get_tree().get_nodes_in_group("battle_units"):
		if not is_instance_valid(unit) or unit.team != 2 or unit.health <= 0.0:
			continue
		var distance: float = unit.global_position.distance_to(gate)
		if distance < best_distance:
			best_distance = distance
			target = unit
	if target == null:
		return
	var left_origin: Vector3 = gate + Vector3(-12.4, 6.0, -0.8)
	var right_origin: Vector3 = gate + Vector3(12.4, 6.0, -0.8)
	var origin: Vector3 = left_origin if int(Time.get_ticks_msec() / 3700) % 2 == 0 else right_origin
	game_ref.launch_arrow(origin, target, 15.0, null)

func _update_capture_progress(delta: float) -> void:
	if not is_instance_valid(game_ref.player_unit) or gate_health > 0.0:
		capture_progress = 0.0
		return
	var player_position: Vector3 = game_ref.player_unit.global_position
	var site: Dictionary = SIEGE_SITES.get(active_site_id, SIEGE_SITES["frontier_castle"])
	var courtyard_center: Vector3 = site["courtyard_center"]
	var inside_courtyard: bool = absf(player_position.x - courtyard_center.x) <= float(site["half_x"]) and player_position.z >= float(site["min_z"]) and player_position.z <= float(site["max_z"])
	if not inside_courtyard:
		capture_progress = maxf(0.0, capture_progress - delta * 0.7)
		return
	var defenders: int = 0
	for unit in get_tree().get_nodes_in_group("battle_units"):
		if not is_instance_valid(unit) or unit.team != 1 or unit.health <= 0.0:
			continue
		if unit.global_position.distance_to(courtyard_center) <= 19.0:
			defenders += 1
	if defenders > 0:
		capture_progress = maxf(0.0, capture_progress - delta * 0.6)
		return
	capture_progress = minf(10.0, capture_progress + delta)
	if capture_progress >= 10.0:
		castle_captured = true
		capture_attempt_active = false
		gate_assault_active = false
		_flush_active_site_state()
		_mark_dirty()
		var site: Dictionary = SIEGE_SITES.get(active_site_id, SIEGE_SITES["frontier_castle"])
		if active_site_id == "frontier_castle":
			_notice("KALE FETHEDİLDİ! Karanlık Taç Kalesi artık senin kontrolünde.")
		else:
			_notice("%s fethedildi! Bölge krallık kayıtlarına işlendi." % str(site.get("name", "Kale")))
			if is_instance_valid(game_ref) and game_ref.has_method("on_campaign_siege_captured"):
				game_ref.on_campaign_siege_captured(active_site_id)

func _gate_position() -> Vector3:
	if is_instance_valid(gate_visual) and gate_visual is Node3D:
		return (gate_visual as Node3D).global_position
	var site: Dictionary = SIEGE_SITES.get(active_site_id, SIEGE_SITES["frontier_castle"])
	var center: Vector3 = site["center"]
	return Vector3(center.x, 2.0, center.z - 8.0)

func _update_gate_visual() -> void:
	if not is_instance_valid(gate_visual) or not gate_visual is Node3D:
		return
	var ratio: float = gate_health / GATE_MAX_HEALTH
	if gate_health <= 0.0:
		gate_visual.visible = false
		_remove_gate_collision()
	else:
		gate_visual.visible = true
		gate_visual.scale = Vector3(maxf(0.18, ratio), maxf(0.24, ratio), 1.0)

func _remove_gate_collision() -> void:
	if _gate_collision_removed:
		return
	_gate_collision_removed = true
	if is_instance_valid(gate_visual) and gate_visual is Node3D:
		var gate_root: Node = gate_visual.get_parent()
		if is_instance_valid(gate_root):
			var body: StaticBody3D = gate_root.get_node_or_null("WorldSolidBody") as StaticBody3D
			if is_instance_valid(body):
				body.collision_layer = 0
				body.collision_mask = 0
				var shape: CollisionShape3D = body.get_node_or_null("CollisionShape3D") as CollisionShape3D
				if is_instance_valid(shape):
					shape.set_deferred("disabled", true)
	if is_instance_valid(arena_ref) and arena_ref.has_method("unregister_navigation_obstacle"):
		arena_ref.unregister_navigation_obstacle(_gate_position(), Vector3(3.2, 4.2, 0.4))

func _select_nearest_site() -> void:
	if not is_instance_valid(game_ref) or not is_instance_valid(game_ref.player_unit):
		return
	var nearest_id: String = active_site_id
	var nearest_distance: float = INF
	for site_id in SIEGE_SITES.keys():
		var site: Dictionary = SIEGE_SITES[site_id]
		var center: Vector3 = site["center"]
		var distance: float = game_ref.player_unit.global_position.distance_to(center)
		if distance < nearest_distance:
			nearest_distance = distance
			nearest_id = str(site_id)
	if nearest_distance <= 82.0 and nearest_id != active_site_id:
		_switch_active_site(nearest_id)

func _try_auto_select_site() -> void:
	if not is_instance_valid(game_ref) or not is_instance_valid(game_ref.player_unit):
		return
	var nearest_id: String = active_site_id
	var nearest_distance: float = INF
	for site_id in SIEGE_SITES.keys():
		var site: Dictionary = SIEGE_SITES[site_id]
		var center: Vector3 = site["center"]
		var distance: float = game_ref.player_unit.global_position.distance_to(center)
		if distance < nearest_distance:
			nearest_distance = distance
			nearest_id = str(site_id)
	if nearest_id != active_site_id and nearest_distance <= 82.0:
		_switch_active_site(nearest_id)

func _switch_active_site(site_id: String) -> void:
	if not SIEGE_SITES.has(site_id) or site_id == active_site_id:
		return
	_flush_active_site_state()
	active_site_id = site_id
	_load_active_site_state()
	if is_instance_valid(game_ref) and is_instance_valid(game_ref.player_unit):
		var current_site: Dictionary = SIEGE_SITES[active_site_id]
		if game_ref.player_unit.global_position.distance_to(current_site["center"]) < 82.0:
			_notice("Kuşatma sahası: %s. Bu kalenin kapısı ve fetih durumu ayrı kaydedilir." % str(current_site.get("name", "Kale")))
	_emit_status()

func _flush_active_site_state() -> void:
	site_states[active_site_id] = {"gate_health": gate_health, "castle_captured": castle_captured, "siege_started": siege_started, "gate_assault_active": gate_assault_active, "capture_attempt_active": capture_attempt_active, "capture_progress": capture_progress}

func _load_active_site_state() -> void:
	var state: Dictionary = site_states.get(active_site_id, {"gate_health": GATE_MAX_HEALTH, "castle_captured": false, "siege_started": false, "gate_assault_active": false, "capture_attempt_active": false, "capture_progress": 0.0})
	gate_health = clampf(float(state.get("gate_health", GATE_MAX_HEALTH)), 0.0, GATE_MAX_HEALTH)
	castle_captured = bool(state.get("castle_captured", false))
	siege_started = bool(state.get("siege_started", false)) and not castle_captured
	gate_assault_active = bool(state.get("gate_assault_active", false)) and siege_started and gate_health > 0.0
	capture_attempt_active = bool(state.get("capture_attempt_active", false)) and siege_started and gate_health <= 0.0 and not castle_captured
	capture_progress = clampf(float(state.get("capture_progress", 0.0)), 0.0, 10.0)
	var site: Dictionary = SIEGE_SITES.get(active_site_id, SIEGE_SITES["frontier_castle"])
	gate_visual = arena_ref.find_child(str(site.get("gate_node", "GateWoodenDoors")), true, false) if is_instance_valid(arena_ref) else null
	_gate_collision_removed = false
	_update_gate_visual()

func _mark_dirty() -> void:
	if is_instance_valid(game_ref) and game_ref.has_method("_mark_progress_dirty"):
		game_ref._mark_progress_dirty()

func _notice(message: String) -> void:
	_last_notice = message
	if is_instance_valid(game_ref) and game_ref.has_method("show_notice"):
		game_ref.show_notice(message)

func _emit_status() -> void:
	siege_status_changed.emit(get_status_text(), gate_health, GATE_MAX_HEALTH)
