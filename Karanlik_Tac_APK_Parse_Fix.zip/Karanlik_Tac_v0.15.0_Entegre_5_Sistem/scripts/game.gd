extends Node3D

const ArenaScript = preload("res://scripts/arena.gd")
const PlayerScript = preload("res://scripts/player.gd")
const UnitScript = preload("res://scripts/battle_unit.gd")
const HUDScript = preload("res://scripts/hud.gd")
const NPCScript = preload("res://scripts/world_npc.gd")
const CreatureScript = preload("res://scripts/wild_creature.gd")
const ChestScript = preload("res://scripts/loot_chest.gd")
const ArrowScript = preload("res://scripts/arrow_projectile.gd")
const SiegeScript = preload("res://scripts/siege_manager.gd")
const KingdomSystemScript = preload("res://scripts/kingdom_system.gd")
const SettlementScript = preload("res://scripts/settlement_manager.gd")
const QuestSystemScript = preload("res://scripts/quest_system.gd")
const WorldLifeScript = preload("res://scripts/world_life.gd")

var player_unit: Variant = null
var hud: Variant = null
var world_ref: Variant = null
var kills: int = 0
var summon_cooldown: float = 0.0
var game_over: bool = false
var look_touch_index: int = -1
var mouse_look_active: bool = false
var gold: int = 45
var xp: int = 0
var level: int = 1
var weapon_level: int = 1
var armor_level: int = 0
var boots_level: int = 0
var ring_level: int = 0
var weapon_type: String = "sword"
var bandit_quest_state: int = 0 # 0 not started, 1 active, 2 ready to turn in, 3 complete
var bandit_quest_count: int = 0
var active_save_slot: int = 1
var selected_save_slot: int = 1
var _loaded_from_legacy: bool = false
var wolf_quest_state: int = 0 # 0 not started, 1 active, 2 ready to turn in, 3 complete
var wolf_quest_count: int = 0
var ruin_quest_state: int = 0
var skeleton_quest_count: int = 0
var _keyboard_summon_latch: bool = false
var _keyboard_interact_latch: bool = false
var _notice_timer: float = 0.0
var _rng := RandomNumberGenerator.new()
const LEGACY_SAVE_PATH: String = "user://karanlik_tac_save.json"
const ACTIVE_SLOT_PATH: String = "user://karanlik_tac_active_slot.cfg"
const GRAPHICS_CONFIG_PATH: String = "user://karanlik_tac_graphics.cfg"
const SAVE_SLOT_COUNT: int = 3
const SAVE_FORMAT_VERSION: int = 10
var inventory: Dictionary = {
	"healing_potion": 2,
	"wolf_pelt": 0,
	"bone_fragment": 0,
	"spider_silk": 0,
	"bog_core": 0,
	"ash_essence": 0,
	"drake_scale": 0,
	"ancient_relic": 0,
	"bandit_insignia": 0
}
var opened_chest_ids: Array[String] = []
var defeated_creature_ids: Array[String] = []
var _loaded_save_data: Dictionary = {}
var _has_loaded_save: bool = false
var _auto_save_elapsed: float = 0.0
var _progress_dirty: bool = false
var army_order: String = "follow"
var army_formation: String = "line"
var _loaded_army: Array = []
var siege_manager: Variant = null
var kingdom_system: Variant = null
var settlement_manager: Variant = null
var quest_system: Variant = null
var world_life: Variant = null
var _campaign_tick_elapsed: float = 0.0
var pending_story_choice: Dictionary = {}
var skill_points: int = 0
var skill_levels: Dictionary = {"combat": 0, "leadership": 0, "survival": 0}
var _last_region_seen: String = ""
var _companion_heal_timer: float = 24.0
var _castle_capture_handled: bool = false
var graphics_quality: String = "balanced"
const MAX_ALLIES: int = 10
const RECRUIT_COSTS: Dictionary = {"infantry": 25, "archer": 35, "cavalry": 50, "shield_guard": 60, "crossbowman": 55}

func _ready() -> void:
	_rng.randomize()
	_load_active_slot()
	_load_save_file()
	graphics_quality = _load_graphics_quality()
	kingdom_system = KingdomSystemScript.new()
	kingdom_system.initialize(_get_saved_kingdom_state())
	var story_world_value: Variant = _loaded_save_data.get("world", {})
	var story_world: Dictionary = story_world_value if story_world_value is Dictionary else {}
	quest_system = QuestSystemScript.new()
	var saved_story_value: Variant = story_world.get("story", {})
	var saved_story: Dictionary = saved_story_value if saved_story_value is Dictionary else {}
	quest_system.initialize(saved_story)
	quest_system.name = "StoryQuestJournal"
	add_child(quest_system)
	var arena := ArenaScript.new()
	arena.name = "OpenWorld"
	add_child(arena)
	world_ref = arena
	_apply_graphics_quality(false)
	player_unit = PlayerScript.new()
	player_unit.game_ref = self
	var saved_player: Variant = _loaded_save_data.get("player", {})
	if saved_player is Dictionary and not saved_player.is_empty():
		var saved_position: Variant = saved_player.get("position", {})
		if saved_position is Dictionary:
			player_unit.position = Vector3(
				float(saved_position.get("x", 0.0)),
				float(saved_position.get("y", 0.0)),
				float(saved_position.get("z", 9.0))
			)
		else:
			player_unit.position = _ground_position(Vector3(0, 0, 9)) + Vector3(0, 0.12, 0)
		player_unit.max_health = maxf(1.0, float(saved_player.get("max_health", player_unit.max_health)))
		player_unit.health = clampf(float(saved_player.get("health", player_unit.max_health)), 1.0, player_unit.max_health)
		player_unit.attack_damage = maxf(1.0, float(saved_player.get("attack_damage", player_unit.attack_damage)))
		player_unit.move_speed = maxf(1.0, float(saved_player.get("move_speed", player_unit.move_speed)))
		weapon_type = str(saved_player.get("weapon_type", weapon_type))
		if weapon_type not in ["sword", "spear", "greatsword", "axe"]:
			weapon_type = "sword"
		player_unit.stamina = clampf(float(saved_player.get("stamina", player_unit.max_stamina)), 0.0, player_unit.max_stamina)
	else:
		player_unit.position = _ground_position(Vector3(0, 0, 9)) + Vector3(0, 0.12, 0)
	add_child(player_unit)
	player_unit.refresh_gear_visuals()
	hud = HUDScript.new()
	hud.name = "AdventureHUD"
	add_child(hud)
	hud.move_changed.connect(_on_move_changed)
	hud.attack_pressed.connect(_on_attack_pressed)
	hud.block_changed.connect(_on_block_changed)
	hud.troops_pressed.connect(_on_troops_pressed)
	hud.interact_pressed.connect(attempt_interaction)
	hud.save_pressed.connect(_on_save_pressed)
	hud.load_pressed.connect(_on_load_pressed)
	hud.inventory_pressed.connect(_on_inventory_pressed)
	hud.potion_pressed.connect(_on_potion_pressed)
	hud.save_slots_pressed.connect(_on_save_slots_pressed)
	hud.save_slot_selected.connect(_on_save_slot_selected)
	hud.save_slot_save_pressed.connect(_on_save_slot_save_pressed)
	hud.save_slot_load_pressed.connect(_on_save_slot_load_pressed)
	hud.crafting_pressed.connect(_on_crafting_pressed)
	hud.equipment_pressed.connect(_on_equipment_pressed)
	hud.army_panel_pressed.connect(_on_army_panel_pressed)
	hud.army_order_pressed.connect(_on_army_order_pressed)
	hud.army_formation_pressed.connect(_on_army_formation_pressed)
	hud.army_recruit_pressed.connect(_on_army_recruit_pressed)
	hud.kingdom_panel_pressed.connect(_on_kingdom_panel_pressed)
	hud.kingdom_pledge_pressed.connect(_on_kingdom_pledge_pressed)
	hud.settlement_panel_pressed.connect(_on_settlement_panel_pressed)
	hud.settlement_action_pressed.connect(_on_settlement_action_pressed)
	hud.quest_journal_pressed.connect(_on_quest_journal_pressed)
	hud.companion_panel_pressed.connect(_on_companion_panel_pressed)
	hud.skills_panel_pressed.connect(_on_skills_panel_pressed)
	hud.graphics_panel_pressed.connect(_on_graphics_panel_pressed)
	hud.graphics_quality_selected.connect(_on_graphics_quality_selected)
	hud.refresh_graphics_settings(graphics_quality)
	hud.skill_purchase_pressed.connect(_on_skill_purchase_pressed)
	hud.siege_command_pressed.connect(_on_siege_command_pressed)
	hud.weapon_cycle_pressed.connect(_on_weapon_cycle_pressed)
	hud.sprint_changed.connect(_on_sprint_changed)
	hud.craft_recipe_pressed.connect(craft_recipe)
	hud.modal_open_changed.connect(_on_modal_open_changed)
	hud.restart_pressed.connect(_on_restart_pressed)
	hud.story_choice_pressed.connect(_on_story_choice_pressed)
	_spawn_village_npcs()
	_spawn_wildlife()
	_spawn_treasure_chests()
	_spawn_gate_raiders()
	_spawn_bandit_camp()
	_spawn_saved_allies()
	siege_manager = SiegeScript.new()
	siege_manager.name = "CastleSiegeManager"
	add_child(siege_manager)
	var saved_world_state: Variant = _loaded_save_data.get("world", {})
	var safe_world_state: Dictionary = saved_world_state if saved_world_state is Dictionary else {}
	siege_manager.initialize(self, world_ref, safe_world_state)
	if is_instance_valid(siege_manager) and siege_manager.active_site_id == "frontier_castle" and siege_manager.castle_captured:
		kingdom_system.capture_frontier_castle()
		_castle_capture_handled = true
	settlement_manager = SettlementScript.new()
	settlement_manager.name = "SettlementManagement"
	add_child(settlement_manager)
	var saved_settlement: Variant = safe_world_state.get("settlement", {})
	var owns_frontier_castle := str(kingdom_system.territories.get("frontier_castle", "red_banner")) == "player"
	settlement_manager.initialize(self, world_ref, saved_settlement if saved_settlement is Dictionary else {}, owns_frontier_castle or (is_instance_valid(siege_manager) and siege_manager.active_site_id == "frontier_castle" and siege_manager.castle_captured))
	world_life = WorldLifeScript.new()
	world_life.name = "LivingWorldSimulation"
	add_child(world_life)
	var saved_living_value: Variant = safe_world_state.get("living_world", {})
	world_life.initialize(self, world_ref, saved_living_value if saved_living_value is Dictionary else {})
	selected_save_slot = active_save_slot
	hud.refresh_save_slots(_get_save_slot_summaries(), selected_save_slot)
	_refresh_progress_panels()
	_refresh_army_panel_if_open()
	_refresh_quest_panel_if_open()
	_refresh_companion_panel_if_open()
	_refresh_skills_panel_if_open()
	if _loaded_from_legacy and save_game(false):
		DirAccess.remove_absolute(ProjectSettings.globalize_path(LEGACY_SAVE_PATH))
		hud.refresh_save_slots(_get_save_slot_summaries(), selected_save_slot)
	if _has_loaded_save:
		hud.set_notice("Kayıt yuvası %d yüklendi. Macerana kaldığın yerden devam et." % active_save_slot)
	else:
		hud.set_notice("Karanlık Taç'a hoş geldin. Köyü bul, yaşlıyla konuş ve ilk görevini al.")

func _process(delta: float) -> void:
	if not is_instance_valid(player_unit):
		if not game_over:
			game_over = true
			if is_instance_valid(hud):
				hud.show_game_over(kills, level)
		return
	if game_over:
		return
	if is_instance_valid(siege_manager) and siege_manager.active_site_id == "frontier_castle" and siege_manager.castle_captured and not _castle_capture_handled:
		_record_story_event("castle_captured")
		if kingdom_system.capture_frontier_castle():
			gold += 250
			xp += 220
			show_notice("Sınır Kalesi fethedildi! +250 altın, +220 XP. Yerleşim yönetimi açıldı.")
			_mark_progress_dirty()
			_refresh_kingdom_panel_if_open()
		if is_instance_valid(settlement_manager):
			settlement_manager.set_castle_owned(true)
			_refresh_settlement_panel_if_open()
		_castle_capture_handled = true
	summon_cooldown = maxf(0.0, summon_cooldown - delta)
	_notice_timer = maxf(0.0, _notice_timer - delta)
	_auto_save_elapsed += delta
	_campaign_tick_elapsed += delta
	if _campaign_tick_elapsed >= 78.0:
		_campaign_tick_elapsed = 0.0
		if is_instance_valid(kingdom_system):
			var campaign_events: Array[String] = kingdom_system.advance_ai_turn()
			if not campaign_events.is_empty():
				show_notice(str(campaign_events[0]))
			_mark_progress_dirty()
			_refresh_kingdom_panel_if_open()
	var current_region := _region_name(player_unit.global_position)
	if _last_region_seen.is_empty():
		_last_region_seen = current_region
		if is_instance_valid(quest_system) and quest_system.record_region_visit(current_region):
			_mark_progress_dirty()
			_refresh_quest_panel_if_open()
	elif current_region != _last_region_seen:
		_last_region_seen = current_region
		if is_instance_valid(quest_system) and quest_system.record_region_visit(current_region):
			_mark_progress_dirty()
			_refresh_quest_panel_if_open()
	_companion_heal_timer -= delta
	if _companion_heal_timer <= 0.0:
		_companion_heal_timer = 24.0
		if _has_live_companion("runa") and player_unit.health < player_unit.max_health:
			player_unit.health = minf(player_unit.max_health, player_unit.health + 12.0)
			show_notice("Runa seni iyileştirdi: +12 can.")
	if (_progress_dirty and _auto_save_elapsed >= 10.0) or _auto_save_elapsed >= 60.0:
		save_game(false)
	var enemies := count_units(1)
	for creature in get_tree().get_nodes_in_group("wild_creatures"):
		if is_instance_valid(creature) and creature.health > 0.0:
			enemies += 1
	var allies := count_units(2)
	var xp_goal := _xp_for_next_level()
	var mission := _current_mission_text()
	hud.update_status(player_unit.health, player_unit.max_health, kills, level, enemies, allies, summon_cooldown, xp, xp_goal, gold, mission, weapon_level, armor_level, get_weapon_display_name(), player_unit.stamina, player_unit.max_stamina)
	var world_status: String = str(world_life.get_world_status_text()) if is_instance_valid(world_life) else "Hava: Açık"
	hud.update_world_info(player_unit.global_position, "%s  •  %s" % [_region_name(player_unit.global_position), world_status])
	if is_instance_valid(siege_manager) and hud.has_method("update_siege_status"):
		hud.update_siege_status(siege_manager.get_status_text(), siege_manager.catapult_cooldown, siege_manager.get_catapult_cost())
	if Input.is_key_pressed(KEY_F):
		if not _keyboard_interact_latch:
			_keyboard_interact_latch = true
			attempt_interaction()
	else:
		_keyboard_interact_latch = false

func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed:
			if event.position.x > get_viewport().get_visible_rect().size.x * 0.42 and not hud.is_ui_point(event.position):
				look_touch_index = event.index
		else:
			if event.index == look_touch_index:
				look_touch_index = -1
	elif event is InputEventScreenDrag:
		if event.index == look_touch_index and is_instance_valid(player_unit):
			player_unit.rotate_camera(event.relative.x * 0.006, event.relative.y * 0.0045)
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_RIGHT:
		mouse_look_active = event.pressed
		if mouse_look_active:
			Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
		else:
			Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	elif event is InputEventMouseMotion and mouse_look_active and is_instance_valid(player_unit):
		player_unit.rotate_camera(event.relative.x * 0.0038, event.relative.y * 0.003)
	elif event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_ESCAPE:
			Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
		elif event.keycode == KEY_F1:
			_issue_army_order("follow")
		elif event.keycode == KEY_F2:
			_issue_army_order("hold")
		elif event.keycode == KEY_F3:
			_issue_army_order("charge")
		elif event.keycode == KEY_F4:
			_issue_army_order("retreat")
		elif event.keycode == KEY_1:
			_set_army_formation("line")
		elif event.keycode == KEY_2:
			_set_army_formation("wedge")
		elif event.keycode == KEY_3:
			_set_army_formation("column")
		elif event.keycode == KEY_R:
			cycle_weapon_type()

func _spawn_village_npcs() -> void:
	_spawn_npc("Elder Eren", "elder", Vector3(77, 0, 27), "north_crown")
	_spawn_npc("Tüccar Mira", "merchant", Vector3(96, 0, 32), "aurel_empire")
	_spawn_npc("Demirci Boran", "blacksmith", Vector3(112, 0, 22), "north_crown")
	_spawn_npc("Otacı Lale", "herbalist", Vector3(66, 0, 38), "mountain_clans")
	_spawn_npc("Köy Muhafızı", "guard", Vector3(59, 0, 20), "north_crown")
	_spawn_npc("Nöbetçi Aras", "guard", Vector3(115, 0, 42), "north_crown")
	_spawn_npc("Köylü Elif", "villager", Vector3(84, 0, 15), "north_crown")
	_spawn_npc("Köylü Cem", "villager", Vector3(102, 0, 45), "north_crown")
	_spawn_npc("Gezgin Narin", "villager", Vector3(63, 0, 45), "aurel_empire")
	_spawn_npc("Oduncu Veli", "villager", Vector3(102, 0, 12), "mountain_clans")
	_spawn_npc("İzcibaşı Koral", "scout", Vector3(-242, 0, 116), "red_banner")
	_spawn_npc("Sınır Muhafızı Orven", "guard", Vector3(137, 0, -151), "north_crown")
	_spawn_npc("Darian · Eski Muhafız", "companion_guard", Vector3(22, 0, -66), "north_crown")
	_spawn_npc("Runa · Gezgin Şifacı", "companion_healer", Vector3(191, 0, 73), "mountain_clans")
	_spawn_npc("Taren · Sınır İzci", "companion_scout", Vector3(-337, 0, 51), "red_banner")
	_spawn_npc("Selka · Orman Avcısı", "companion_ranger", Vector3(-205, 0, 141), "north_crown")

func _ground_position(at: Vector3) -> Vector3:
	if is_instance_valid(world_ref) and world_ref.has_method("get_ground_height"):
		return Vector3(at.x, world_ref.get_ground_height(at.x, at.z), at.z)
	return at

func _spawn_npc(npc_name: String, npc_role: String, at: Vector3, faction_id: String = "north_crown") -> void:
	var npc: Variant = NPCScript.new()
	npc.display_name = npc_name
	npc.role = npc_role
	npc.faction_id = faction_id
	npc.game_ref = self
	npc.position = _ground_position(at)
	add_child(npc)

func _spawn_wildlife() -> void:
	# Wolves patrol the greenwood; skeletons guard ruins; harder monsters occupy remote regions.
	for p in [Vector3(-192, 0, 43), Vector3(-158, 0, 37), Vector3(-128, 0, 71), Vector3(-176, 0, 93), Vector3(-120, 0, 124), Vector3(-219, 0, 104), Vector3(-145, 0, 150)]:
		_spawn_creature("wolf", p)
	for p in [Vector3(129, 0, -203), Vector3(151, 0, -212), Vector3(169, 0, -177), Vector3(126, 0, -175), Vector3(160, 0, -196)]:
		_spawn_creature("skeleton", p)
	for p in [Vector3(155, 0, -195), Vector3(177, 0, -209), Vector3(134, 0, -221), Vector3(195, 0, -185)]:
		_spawn_creature("spider", p)
	for p in [Vector3(177, 0, 82), Vector3(221, 0, 112), Vector3(198, 0, 132)]:
		_spawn_creature("bog_troll" if p.x == 198.0 else "spider", p)
	_spawn_creature("wraith", Vector3(145, 0, -174))
	_spawn_creature("drake", Vector3(68, 0, -258))
	_spawn_creature("wolf", Vector3(-34, 0, 164))
	_spawn_creature("wolf", Vector3(24, 0, 176))

func _spawn_creature(kind: String, at: Vector3) -> void:
	var stable_id := "%s_%d_%d" % [kind, roundi(at.x), roundi(at.z)]
	if defeated_creature_ids.has(stable_id):
		return
	var creature: Variant = CreatureScript.new()
	creature.species = kind
	creature.world_id = stable_id
	creature.game_ref = self
	creature.position = _ground_position(at)
	add_child(creature)

func _spawn_treasure_chests() -> void:
	_spawn_chest("Kaçakçı Sandığı", Vector3(-181, 0, 72), 55, 25)
	_spawn_chest("Harabe Hazinesi", Vector3(148, 0, -178), 95, 55)
	_spawn_chest("Bataklık Kesesi", Vector3(215, 0, 94), 68, 30)
	_spawn_chest("Kum Tapınağı Sandığı", Vector3(-218, 0, -199), 125, 70)
	_spawn_chest("Göl Kenarı Sandığı", Vector3(-12, 0, 201), 42, 18)

func _spawn_chest(chest_name: String, at: Vector3, gold_reward: int, xp_reward: int) -> void:
	var chest: Variant = ChestScript.new()
	chest.game_ref = self
	chest.chest_name = chest_name
	chest.gold_reward = gold_reward
	chest.xp_reward = xp_reward
	chest.chest_id = chest_name
	chest.opened = opened_chest_ids.has(chest_name)
	chest.position = _ground_position(at)
	add_child(chest)

func _spawn_gate_raiders() -> void:
	var raider_x: Array[float] = [-16.0, 16.0, 0.0]
	var raider_z: Array[float] = [-27.0, -27.0, -42.0]
	for i in range(3):
		var raider: Variant = UnitScript.new()
		raider.team = 1
		raider.faction_id = "red_banner"
		raider.max_health = 74.0
		raider.health = raider.max_health
		raider.move_speed = 2.8
		raider.attack_damage = 12.0
		raider.attack_range = 1.8
		raider.game_ref = self
		raider.position = _ground_position(Vector3(raider_x[i], 0, raider_z[i]))
		add_child(raider)

func _spawn_bandit_camp() -> void:
	# Five named enemies form a persistent quest encounter. Defeated IDs are stored with world progress.
	var positions: Array[Vector3] = [Vector3(-263, 0, 111), Vector3(-249, 0, 111), Vector3(-273, 0, 124), Vector3(-252, 0, 130), Vector3(-238, 0, 122)]
	for i in range(positions.size()):
		var world_id := "bandit_camp_%02d" % i
		if defeated_creature_ids.has(world_id):
			continue
		var bandit: Variant = UnitScript.new()
		bandit.team = 1
		bandit.unit_class = "infantry"
		bandit.faction_id = "bandit"
		bandit.world_id = world_id
		bandit.max_health = 86.0 + float(i % 2) * 18.0
		bandit.health = bandit.max_health
		bandit.move_speed = 2.9 + float(i % 3) * 0.12
		bandit.attack_damage = 13.0 + float(i % 2) * 3.0
		bandit.attack_range = 1.9
		bandit.game_ref = self
		bandit.position = _ground_position(positions[i])
		add_child(bandit)

func count_units(team_id: int) -> int:
	var count := 0
	for unit in get_tree().get_nodes_in_group("battle_units"):
		if is_instance_valid(unit) and unit.team == team_id and unit.health > 0.0:
			count += 1
	return count

func is_faction_friendly_to_player(faction_id: String) -> bool:
	# A sworn faction treats the player and their army as allies. Unaffiliated bandits
	# remain hostile even though their kills affect Black Seal reputation.
	if not is_instance_valid(kingdom_system) or kingdom_system.player_oath.is_empty():
		return false
	return faction_id == kingdom_system.player_oath

func find_nearest_enemy(origin: Variant) -> Variant:
	# Target score blends distance, remaining health and threat; this avoids every soldier
	# blindly dogpiling the same nearest target when another enemy is almost as close.
	var result: Variant = null
	var best_score := INF
	for unit in get_tree().get_nodes_in_group("battle_units"):
		if not is_instance_valid(unit) or unit.team != 1 or unit.health <= 0.0:
			continue
		if is_faction_friendly_to_player(str(unit.faction_id)):
			continue
		var distance: float = origin.global_position.distance_to(unit.global_position)
		if distance > 72.0:
			continue
		var health_ratio := clampf(unit.health / maxf(1.0, unit.max_health), 0.0, 1.0)
		var role_bias := -1.8 if str(unit.unit_class) == "archer" else (0.4 if str(unit.unit_class) == "cavalry" else 0.0)
		var score: float = distance + health_ratio * 2.2 + role_bias
		if score < best_score:
			best_score = score
			result = unit
	for creature in get_tree().get_nodes_in_group("wild_creatures"):
		if not is_instance_valid(creature) or creature.health <= 0.0:
			continue
		var distance: float = origin.global_position.distance_to(creature.global_position)
		if distance > 72.0:
			continue
		var health_ratio := clampf(creature.health / maxf(1.0, creature.max_health), 0.0, 1.0)
		var score: float = distance + health_ratio * 2.5 + 1.2
		if score < best_score:
			best_score = score
			result = creature
	return result

func find_nearest_friendly(origin: Variant) -> Variant:
	if is_instance_valid(origin) and is_faction_friendly_to_player(str(origin.faction_id)):
		return null
	var result: Variant = null
	var best_distance := INF
	for unit in get_tree().get_nodes_in_group("battle_units"):
		if not is_instance_valid(unit) or (unit.team != 0 and unit.team != 2) or unit.health <= 0.0:
			continue
		var distance: float = origin.global_position.distance_squared_to(unit.global_position)
		if distance < best_distance:
			best_distance = distance
			result = unit
	return result

func attempt_interaction() -> void:
	if game_over or not is_instance_valid(player_unit):
		return
	var closest: Variant = null
	var closest_distance := 6.0
	for target in get_tree().get_nodes_in_group("interactables"):
		if not is_instance_valid(target):
			continue
		var distance: float = player_unit.global_position.distance_to(target.global_position)
		if distance < closest_distance:
			closest_distance = distance
			closest = target
	if closest == null:
		show_notice("Etkileşmek için bir NPC'ye veya sandığa yaklaş.")
	elif closest.has_method("interact"):
		closest.interact(self)

func interact_with_npc(npc: Variant) -> void:
	if not is_instance_valid(npc):
		return
	if is_instance_valid(kingdom_system) and kingdom_system.record_npc_meeting(str(npc.display_name), str(npc.faction_id)):
		_mark_progress_dirty()
		_refresh_kingdom_panel_if_open()
	_mark_progress_dirty()
	if str(npc.role) == "elder" and is_instance_valid(quest_system):
		if quest_system.activate_quest("main_01"):
			var prior_wolves := 0
			for defeated_id in defeated_creature_ids:
				if str(defeated_id).begins_with("wolf_"):
					prior_wolves += 1
			quest_system.seed_progress("main_01", prior_wolves)
	if str(npc.role) in ["companion_guard", "companion_healer", "companion_scout", "companion_ranger"]:
		_interact_with_companion(npc)
		return
	if str(npc.role) == "elder" and is_instance_valid(quest_system) and quest_system.story_branch.is_empty():
		var main_four_state: Dictionary = quest_system.quest_states.get("main_04", {})
		if str(main_four_state.get("state", "")) == "ready":
			pending_story_choice = {"type": "main"}
			hud.show_story_choices("TAHTIN YOLU", "Eski kayıt ilerlemen korunurken ana hikâyenin son kararı da açıldı. Halkı koru ya da gücü seç; karar finali ve krallık ilişkilerini değiştirir.", [{"id": "people_first", "label": "Halkı ve sınır köylerini koru", "description": "Daha güçlü dostluklar ve daha barışçıl bir son."}, {"id": "warlord", "label": "Gücü toplayıp korkuyla hükmet", "description": "Anında savaş avantajı ve daha sert bir son."}])
			return
	if is_instance_valid(quest_system) and quest_system.has_ready_quest_for_role(str(npc.role)):
		var quest_reward: Dictionary = quest_system.claim_next_for_role(str(npc.role))
		if bool(quest_reward.get("ok", false)):
			gold += int(quest_reward.get("gold", 0))
			_gain_xp(int(quest_reward.get("xp", 0)))
			show_notice("%s • +%d altın • +%d XP" % [str(quest_reward.get("message", "Görev tamamlandı")), int(quest_reward.get("gold", 0)), int(quest_reward.get("xp", 0))])
			match str(quest_reward.get("next_id", "")):
				"main_02":
					quest_system.seed_progress("main_02", bandit_quest_count)
				"main_03":
					quest_system.seed_progress("main_03", int(inventory.get("ancient_relic", 0)))
				"main_04":
					if is_instance_valid(siege_manager) and siege_manager.active_site_id == "frontier_castle" and siege_manager.castle_captured:
						_record_story_event("castle_captured")
			if str(quest_reward.get("id", "")) == "main_03" and quest_system.story_branch.is_empty():
				pending_story_choice = {"type": "main"}
				hud.show_story_choices("TAHTIN YOLU", "Kadim kalıntılar, taç için iki farklı gelecek gösteriyor. Seçimin son kuşatmanın ardından krallıkların tutumunu ve finali değiştirecek.", [{"id": "people_first", "label": "Halkı ve sınır köylerini koru", "description": "Daha güçlü dostluklar ve daha barışçıl bir son."}, {"id": "warlord", "label": "Gücü toplayıp korkuyla hükmet", "description": "Anında savaş avantajı ve daha sert bir son."}])
			if str(quest_reward.get("id", "")) == "main_04":
				var branch := str(quest_system.story_branch)
				if branch == "people_first":
					show_notice("FİNAL · SINIRLARDA BARIŞ: Köyler korunuyor; dost krallıklar yeni düzeni kabul ediyor.")
				else:
					show_notice("FİNAL · DEMİR TAÇ: Kaleyi aldın; komşu krallıklar gücünden çekiniyor ve yeni savaşlar kapıda.")
			_mark_progress_dirty()
			_refresh_quest_panel_if_open()
			_refresh_progress_panels()
			return
	if is_instance_valid(quest_system) and quest_system.has_active_main_quest_for_role(str(npc.role)):
		show_notice("%s: %s" % [str(npc.display_name), quest_system.get_primary_objective_text()])
		_refresh_quest_panel_if_open()
		return
	if is_instance_valid(kingdom_system) and kingdom_system.get_standing(str(npc.faction_id)) <= -50 and str(npc.role) in ["merchant", "blacksmith", "herbalist"]:
		show_notice("%s: İtibarın çok düşük. Önce krallığımızın güvenini yeniden kazan." % str(npc.display_name))
		return
	match npc.role:
		"elder":
			if wolf_quest_state == 0:
				wolf_quest_state = 1
				wolf_quest_count = 0
				show_notice("Eren: Ormanın kurtları köylüleri tehdit ediyor. 4 Kızıl Orman Kurdu avla!")
			elif wolf_quest_state == 1:
				show_notice("Eren: Kurt avı %d/4. Orman, köyün batısında." % wolf_quest_count)
			elif wolf_quest_state == 2:
				wolf_quest_state = 3
				gold += 120
				_gain_xp(160)
				show_notice("Görev tamamlandı! +120 altın, +160 XP.")
			else:
				show_notice("Eren: Krallık yollarını temiz tut. Daha büyük tehditler kuzeyde.")
		"merchant":
			var heal_cost := _faction_service_cost(20, str(npc.faction_id))
			if player_unit.health >= player_unit.max_health:
				show_notice("Mira: Canın zaten dolu. Şifa paketi %d altın." % heal_cost)
			elif gold >= heal_cost:
				gold -= heal_cost
				player_unit.health = minf(player_unit.max_health, player_unit.health + 75.0)
				_refresh_progress_panels()
				show_notice("Şifa paketi kullandın: +75 can, -%d altın. Kalan: %d." % [heal_cost, gold])
			else:
				show_notice("Mira: Şifa paketi için %d altın gerekiyor." % heal_cost)
		"blacksmith":
			var cost := _faction_service_cost(75 if weapon_level == 1 else 145, str(npc.faction_id))
			if weapon_level >= 3:
				show_notice("Boran: Kılıcın en iyi hâlinde.")
			elif gold >= cost:
				gold -= cost
				weapon_level += 1
				player_unit.attack_damage += 11.0
				_refresh_progress_panels()
				show_notice("Kılıcın geliştirildi! Seviye %d, hasar %.0f." % [weapon_level, player_unit.attack_damage])
			else:
				show_notice("Boran: Kılıç geliştirmesi %d altın. Savaşta ganimet topla." % cost)
		"herbalist":
			var herb_cost := _faction_service_cost(15, str(npc.faction_id))
			if player_unit.health < player_unit.max_health and gold >= herb_cost:
				gold -= herb_cost
				player_unit.health = minf(player_unit.max_health, player_unit.health + 48.0)
				_refresh_progress_panels()
				show_notice("Lale şifalı otlar verdi. +48 can, -%d altın." % herb_cost)
			elif gold < herb_cost:
				show_notice("Lale: Şifalı otlar için %d altın gerekiyor." % herb_cost)
			else:
				show_notice("Lale: Bataklıkta mavi ışıklı mantarlar ve kadim iksirler bulunur.")
		"guard":
			if ruin_quest_state == 0:
				ruin_quest_state = 1
				skeleton_quest_count = 0
				show_notice("Muhafız: Harabelerde 5 Kadim İskelet'i durdur. Sonra bana dön!")
			elif ruin_quest_state == 1:
				show_notice("Harabeler görevi: %d/5 iskelet." % skeleton_quest_count)
			elif ruin_quest_state == 2:
				ruin_quest_state = 3
				gold += 150
				_gain_xp(210)
				show_notice("Harabeler görevi tamamlandı! +150 altın, +210 XP.")
			else:
				show_notice("Muhafız: Ayaz Dişi'nde bir ejder yavrusu görüldü. Dikkatli ol!")
		"scout":
			if bandit_quest_state == 0:
				bandit_quest_state = 1
				if bandit_quest_count >= 5:
					bandit_quest_state = 2
					show_notice("Koral: Kamp zaten temizlenmiş! Ödülünü al.")
				else:
					show_notice("Koral: Kara Pençe haydutları ticaret yolunu kesti. Kamptaki 5 haydutu yen ve yolu aç! İlerleme: %d/5." % bandit_quest_count)
			elif bandit_quest_state == 1:
				show_notice("Koral: Haydut kampı %d/5. Kamp, batıdaki kara sancakların ardında." % bandit_quest_count)
			elif bandit_quest_state == 2:
				bandit_quest_state = 3
				gold += 180
				_gain_xp(240)
				inventory["bandit_insignia"] = int(inventory.get("bandit_insignia", 0)) + 1
				show_notice("Ticaret yolu açıldı! +180 altın, +240 XP ve Haydut Sancağı kazandın.")
			else:
				show_notice("Koral: Yol şimdilik güvenli. Kırık Mızrak Meydanı'nda eski bir savaşın izleri var.")
		"villager":
			var lines: Array[String] = ["Köyün batısındaki ormanda kurt ulumaları duyuluyor.", "Sis Bataklığı'na hazırlıksız girme; orada devler yaşar.", "Kuzey zirvelerinde karın altına gömülmüş bir tapınak var.", "Harabelerdeki mor kristaller karanlık ruhları çağırır.", "Demirci Boran altın karşılığında kılıcını güçlendirebilir."]
			show_notice("%s: %s" % [npc.display_name, lines[_rng.randi_range(0, lines.size() - 1)]])
		_:
			show_notice("Bu kişi şu anda konuşmak istemiyor.")
	_refresh_progress_panels()

func on_creature_died(creature: Variant) -> void:
	if not is_instance_valid(creature):
		return
	kills += 1
	var creature_event: String = str({"wolf":"wolf_kill", "spider":"spider_kill", "skeleton":"skeleton_kill", "bog_troll":"bog_troll_kill", "drake":"drake_kill"}.get(str(creature.species), "creature_kill"))
	_record_story_event(str(creature_event))
	if not creature.world_id.is_empty() and not defeated_creature_ids.has(creature.world_id):
		defeated_creature_ids.append(creature.world_id)
	var earned_gold: int = _rng.randi_range(creature.reward_gold_min, creature.reward_gold_max)
	gold += earned_gold
	var drop_name := _add_creature_drop(creature.species)
	_gain_xp(creature.reward_xp)
	_mark_progress_dirty()
	if creature.species == "wolf" and wolf_quest_state == 1:
		wolf_quest_count += 1
		if wolf_quest_count >= 4:
			wolf_quest_state = 2
			show_notice("Kurt görevi tamamlandı! Eren'e geri dön. +%d altın, +%d XP, +1 %s." % [earned_gold, creature.reward_xp, drop_name])
		else:
			show_notice("%s yenildi. +%d altın, +%d XP, +1 %s. Kurt görevi %d/4." % [creature.display_name, earned_gold, creature.reward_xp, drop_name, wolf_quest_count])
	elif creature.species == "skeleton" and ruin_quest_state == 1:
		skeleton_quest_count += 1
		if skeleton_quest_count >= 5:
			ruin_quest_state = 2
			show_notice("Harabeler temizlendi! Muhafıza dön. +%d altın, +%d XP, +1 %s." % [earned_gold, creature.reward_xp, drop_name])
		else:
			show_notice("İskelet yenildi. Harabeler görevi %d/5. +%d altın, +1 %s." % [skeleton_quest_count, earned_gold, drop_name])
	else:
		show_notice("%s yenildi. +%d altın, +%d XP, +1 %s." % [creature.display_name, earned_gold, creature.reward_xp, drop_name])
	_refresh_progress_panels()

func on_unit_died(unit: Variant) -> void:
	if not is_instance_valid(unit):
		return
	if unit.team == 0:
		game_over = true
		if is_instance_valid(hud):
			hud.show_game_over(kills, level)
		return
	if unit.team == 1:
		if is_instance_valid(kingdom_system):
			kingdom_system.record_hostile_kill(str(unit.faction_id))
			_refresh_kingdom_panel_if_open()
		kills += 1
		gold += 8
		_gain_xp(18)
		# World-event raiders use the red-banner faction for diplomacy, but still
		# count as bandits for the quest journal and Darian's personal story.
		var is_bandit_target := str(unit.faction_id) == "bandit" or str(unit.world_id).begins_with("world_event_bandit_")
		if is_bandit_target:
			_record_story_event("bandit_kill")
			if not str(unit.world_id).is_empty() and not defeated_creature_ids.has(str(unit.world_id)):
				defeated_creature_ids.append(str(unit.world_id))
			bandit_quest_count = mini(5, bandit_quest_count + 1)
			if bandit_quest_state == 1:
				if bandit_quest_count >= 5:
					bandit_quest_state = 2
					show_notice("Haydut kampı temizlendi! İzcibaşı Koral'a dön ve ödülünü al.")
				else:
					show_notice("Haydut yenildi: %d/5. +8 altın, +18 XP." % bandit_quest_count)
			else:
				show_notice("Haydut yenildi. Kamp ilerlemesi %d/5. +8 altın, +18 XP." % bandit_quest_count)
		else:
			show_notice("Akıncı yenildi. +8 altın, +18 XP.")
		_mark_progress_dirty()
		_refresh_progress_panels()
	elif unit.team == 2:
		_mark_progress_dirty()
		show_notice("Bir müttefik savaşta düştü. Ordu durumunu yeniden kontrol et.")
		_refresh_army_panel_if_open()

func open_loot_chest(chest: Variant) -> void:
	if not is_instance_valid(chest):
		return
	gold += chest.gold_reward
	_gain_xp(chest.xp_reward)
	var first_open := not opened_chest_ids.has(chest.chest_id)
	if first_open:
		opened_chest_ids.append(chest.chest_id)
		_record_story_event("chest_opened")
	var bonus_text := ""
	if first_open and chest.chest_id in ["Harabe Hazinesi", "Kum Tapınağı Sandığı"]:
		inventory["ancient_relic"] = int(inventory.get("ancient_relic", 0)) + 1
		_record_story_event("relic_found")
		bonus_text = " +1 Kadim Kalıntı"
	_mark_progress_dirty()
	_refresh_progress_panels()
	show_notice("Sandık açıldı! +%d altın, +%d XP.%s" % [chest.gold_reward, chest.xp_reward, bonus_text])

func _gain_xp(amount: int) -> void:
	xp += amount
	while xp >= _xp_for_next_level():
		xp -= _xp_for_next_level()
		level += 1
		skill_points += 1
		if is_instance_valid(player_unit):
			player_unit.max_health += 18.0
			player_unit.health = minf(player_unit.max_health, player_unit.health + 42.0)
			player_unit.attack_damage += 3.0
		show_notice("SEVİYE ATLADIN! Seviye %d • +18 azami can • +3 saldırı • +1 yetenek puanı." % level)
	_mark_progress_dirty()

func _xp_for_next_level() -> int:
	return 100 + (level - 1) * 45

func _current_mission_text() -> String:
	if is_instance_valid(quest_system):
		var story_objective: String = str(quest_system.get_primary_objective_text())
		if not story_objective.is_empty():
			return story_objective
	if bandit_quest_state == 1:
		return "HAYDUT KAMPI  %d/5" % bandit_quest_count
	if bandit_quest_state == 2:
		return "ÖDÜL İÇİN KORAL'A DÖN"
	if wolf_quest_state == 1:
		return "KURT AVI  %d/4" % wolf_quest_count
	if wolf_quest_state == 2:
		return "ÖDÜL İÇİN EREN'E DÖN"
	if ruin_quest_state == 1:
		return "HARABELER  %d/5" % skeleton_quest_count
	if ruin_quest_state == 2:
		return "ÖDÜL İÇİN MUHAFIZA DÖN"
	if wolf_quest_state == 3 and ruin_quest_state == 3:
		return "ANA GÖREV: AYAZ DİŞİ'Nİ KEŞFET"
	if wolf_quest_state == 3:
		return "KEŞİF: HARABELERDEKİ MUHAFIZI BUL"
	return "KEŞİF: YELDEĞİRMENİ KÖYÜ'NÜ BUL"

func _region_name(position_3d: Vector3) -> String:
	var p := Vector2(position_3d.x, position_3d.z)
	if p.distance_to(Vector2(-345, 42)) < 34.0:
		return "BATI GÖZETLEME KULESİ"
	if p.distance_to(Vector2(-292, -325)) < 42.0:
		return "KARAKIŞ MANASTIRI"
	if p.distance_to(Vector2(8, 350)) < 48.0:
		return "KÜL OVASI"
	if p.distance_to(Vector2(362, -20)) < 40.0:
		return "DOĞU SINIR GÖZETİMİ"
	if p.distance_to(Vector2(295, 298)) < 44.0:
		return "BATIK KERVAN DURAĞI"
	if p.distance_to(Vector2(0, -33)) < 52.0:
		return "KARANLIK TAÇ KALESİ"
	if p.distance_to(Vector2(88, 30)) < 50.0:
		return "YELDEĞİRMENİ KÖYÜ"
	if p.distance_to(Vector2(-255, 116)) < 72.0:
		return "KARA PENÇE HAYDUT KAMPI"
	if p.distance_to(Vector2(265, -72)) < 78.0:
		return "KIRIK MIZRAK MEYDANI"
	if p.distance_to(Vector2(108, -226)) < 32.0:
		return "AYAZ MAĞARASI"
	if p.distance_to(Vector2(-160, 70)) < 150.0 or p.distance_to(Vector2(-60, 170)) < 100.0:
		return "ESKİ YEŞİLORMAN"
	if p.distance_to(Vector2(0, -245)) < 128.0:
		return "AYAZ DİŞİ ZİNCİRİ"
	if p.distance_to(Vector2(188, 88)) < 120.0:
		return "SİS BATAKLIĞI"
	if p.distance_to(Vector2(-218, -160)) < 130.0:
		return "KIZIL KUM HARABELERİ"
	if p.distance_to(Vector2(145, -188)) < 105.0:
		return "KAYIP KRALLIĞIN HARABELERİ"
	if p.distance_to(Vector2(0, 220)) < 75.0:
		return "AY IŞIĞI GÖLÜ"
	if absf(p.x) > 340.0 or absf(p.y) > 340.0:
		return "DIŞ SINIR TOPRAKLARI"
	return "KRALLIK SINIRLARI"

func _faction_service_cost(base_cost: int, faction_id: String) -> int:
	if not is_instance_valid(kingdom_system):
		return base_cost
	var standing: int = int(kingdom_system.get_standing(faction_id))
	if standing >= 20:
		return maxi(1, floori(float(base_cost) * 0.85))
	if standing <= -20:
		return ceili(float(base_cost) * 1.25)
	return base_cost

func _get_saved_kingdom_state() -> Dictionary:
	var saved_world: Variant = _loaded_save_data.get("world", {})
	if saved_world is Dictionary:
		var saved_kingdoms: Variant = saved_world.get("kingdoms", {})
		if saved_kingdoms is Dictionary:
			return saved_kingdoms
	return {}

func _get_kingdom_summary() -> Dictionary:
	if not is_instance_valid(kingdom_system):
		return {"factions": [], "territories": [], "oath_name": "Bağımsız", "player_territory_count": 0}
	var factions: Array[Dictionary] = []
	for faction_id in kingdom_system.get_faction_ids():
		var data: Dictionary = kingdom_system.get_faction_data(faction_id)
		data["id"] = faction_id
		data["standing"] = kingdom_system.get_standing(faction_id)
		data["attitude"] = kingdom_system.get_attitude(faction_id)
		data["can_pledge"] = kingdom_system.can_pledge(faction_id)
		data["is_oath"] = kingdom_system.player_oath == faction_id
		factions.append(data)
	return {
		"factions": factions,
		"territories": kingdom_system.get_territory_rows(),
		"oath_name": kingdom_system.get_faction_name(kingdom_system.player_oath) if not kingdom_system.player_oath.is_empty() else "Bağımsız",
		"player_territory_count": kingdom_system.get_player_territory_count(),
		"campaign_text": kingdom_system.get_campaign_status_text()
	}

func _refresh_kingdom_panel_if_open() -> void:
	if is_instance_valid(hud) and hud.kingdom_open:
		hud.refresh_kingdom_panel(_get_kingdom_summary())

func _on_kingdom_panel_pressed() -> void:
	if is_instance_valid(hud):
		hud.toggle_kingdom_panel(_get_kingdom_summary())

func _on_kingdom_pledge_pressed(faction_id: String) -> void:
	if not is_instance_valid(kingdom_system):
		return
	var result: Dictionary = kingdom_system.pledge(faction_id)
	show_notice(str(result.get("message", "Diplomasi emri işlendi.")))
	if bool(result.get("ok", false)):
		# Newly pledged allies carry their current faction on saved and live troop records.
		if is_instance_valid(kingdom_system) and not kingdom_system.player_oath.is_empty():
			for ally in get_tree().get_nodes_in_group("battle_units"):
				if is_instance_valid(ally) and int(ally.get("team")) == 2:
					ally.faction_id = kingdom_system.player_oath
					if ally.has_method("_update_name_label"):
						ally._update_name_label()
		_mark_progress_dirty()
		_refresh_kingdom_panel_if_open()

func _on_story_choice_pressed(choice_id: String) -> void:
	if pending_story_choice.is_empty() or not is_instance_valid(quest_system):
		return
	var choice_type := str(pending_story_choice.get("type", ""))
	if choice_type == "main":
		if not quest_system.set_main_story_branch(choice_id):
			return
		if choice_id == "people_first":
			kingdom_system.change_standing("north_crown", 28)
			kingdom_system.change_standing("mountain_clans", 14)
			kingdom_system.change_standing("black_seal", -18)
			show_notice("Halkı koruma yolunu seçtin. Kuzey Tahtı ve Dağ Klanları itibarı arttı; finalin barışçıl yolu açıldı.")
		else:
			gold += 150
			if is_instance_valid(player_unit):
				player_unit.attack_damage += 8.0
			kingdom_system.change_standing("north_crown", -16)
			kingdom_system.change_standing("black_seal", -8)
			show_notice("Demir taç yolunu seçtin: +150 altın, +8 saldırı. Kuzey Tahtı sana daha az güveniyor.")
	elif choice_type == "companion":
		var companion_id := str(pending_story_choice.get("companion_id", ""))
		var result: Dictionary = quest_system.resolve_companion_story(companion_id, choice_id)
		if not bool(result.get("ok", false)):
			show_notice(str(result.get("message", "Karar uygulanamadı.")))
			return
		_apply_companion_choice_consequence(companion_id, choice_id)
		show_notice(str(result.get("message", "Yoldaş hikâyesi tamamlandı.")))
	else:
		return
	pending_story_choice.clear()
	if is_instance_valid(hud):
		hud.close_story_choices()
	_mark_progress_dirty()
	_refresh_progress_panels()
	_refresh_companion_panel_if_open()
	_refresh_kingdom_panel_if_open()

func _apply_companion_choice_consequence(companion_id: String, choice_id: String) -> void:
	match companion_id:
		"darian":
			if choice_id == "darian_mercy":
				gold += 65
				kingdom_system.change_standing("north_crown", 12)
			else:
				gold += 125
				kingdom_system.change_standing("north_crown", -8)
		"runa":
			if choice_id == "runa_share":
				inventory["healing_potion"] = int(inventory.get("healing_potion", 0)) + 3
				kingdom_system.change_standing("mountain_clans", 12)
			else:
				gold += 115
				kingdom_system.change_standing("mountain_clans", -5)
		"taren":
			if choice_id == "taren_warn":
				gold += 45
				kingdom_system.change_standing("aurel_empire", 12)
			else:
				gold += 120
				kingdom_system.change_standing("aurel_empire", -10)
		"selka":
			if choice_id == "selka_forgive":
				inventory["wolf_pelt"] = int(inventory.get("wolf_pelt", 0)) + 2
				kingdom_system.change_standing("north_crown", 8)
			else:
				gold += 130
				kingdom_system.change_standing("north_crown", -4)

func on_campaign_siege_captured(site_id: String) -> void:
	if not is_instance_valid(kingdom_system):
		return
	var territory_id := ""
	var territory_name := ""
	match site_id:
		"eastwatch_fort":
			territory_id = "eastern_watch"
			territory_name = "Doğu Sınır Gözetimi"
		"frost_hold":
			territory_id = "frost_monastery"
			territory_name = "Karakış Manastırı"
		_:
			return
	kingdom_system.territories[territory_id] = "player"
	if not kingdom_system.player_oath.is_empty():
		kingdom_system.change_standing(kingdom_system.player_oath, 8)
	gold += 180
	xp += 150
	show_notice("%s fethedildi! +180 altın, +150 XP. Bölge artık senin krallık kayıtlarında." % territory_name)
	_mark_progress_dirty()
	_refresh_progress_panels()
	_refresh_kingdom_panel_if_open()

func spawn_world_event_bandits(center: Vector3) -> void:
	for i in range(2):
		var bandit: Variant = UnitScript.new()
		bandit.team = 1
		bandit.faction_id = "red_banner"
		bandit.world_id = "world_event_bandit_%d_%d" % [int(world_life.world_day) if is_instance_valid(world_life) else 1, i]
		bandit.max_health = 62.0
		bandit.health = bandit.max_health
		bandit.move_speed = 3.0
		bandit.attack_damage = 10.0
		bandit.attack_range = 1.8
		bandit.game_ref = self
		bandit.position = _ground_position(center + Vector3(float(i) * 2.8 - 1.4, 0.0, float(i) * 1.3))
		add_child(bandit)

func spawn_world_event_cache(at: Vector3, day_value: int, cache_id: String = "") -> void:
	var safe_id := cache_id if not cache_id.is_empty() else "Kayıp Kervan Sandığı Gün %d" % day_value
	if opened_chest_ids.has(safe_id):
		return
	_spawn_chest(safe_id, at, 85, 100)

func interact_with_caravan(agent: Variant) -> void:
	if not is_instance_valid(agent) or not is_instance_valid(world_life):
		return
	var trade_items: Array[Dictionary] = [
		{"id": "drake_scale", "name": "Ejderha pulu", "price": 55},
		{"id": "ash_essence", "name": "Kül özü", "price": 28},
		{"id": "bog_core", "name": "Bataklık çekirdeği", "price": 24},
		{"id": "spider_silk", "name": "Örümcek ipeği", "price": 20},
		{"id": "wolf_pelt", "name": "Kurt postu", "price": 18},
		{"id": "bone_fragment", "name": "Kemik parçası", "price": 10}
	]
	for item in trade_items:
		var item_id := str(item["id"])
		if int(inventory.get(item_id, 0)) > 0:
			var sale_price: int = world_life.get_sell_price(int(item["price"]))
			inventory[item_id] = int(inventory[item_id]) - 1
			gold += sale_price
			show_notice("%s ile takas: 1 %s sattın, +%d altın." % [str(agent.caravan_name), str(item["name"]), sale_price])
			_mark_progress_dirty()
			_refresh_progress_panels()
			return
	var buy_price: int = world_life.get_buy_price(24)
	if gold < buy_price:
		show_notice("%s: İki şifa iksiri %d altın. Malzeme getirirsen satın alırım." % [str(agent.caravan_name), buy_price])
		return
	gold -= buy_price
	inventory["healing_potion"] = int(inventory.get("healing_potion", 0)) + 2
	show_notice("%s ile ticaret yaptın: +2 şifa iksiri, -%d altın." % [str(agent.caravan_name), buy_price])
	_mark_progress_dirty()
	_refresh_progress_panels()

func show_notice(message: String) -> void:
	_notice_timer = 5.5
	if is_instance_valid(hud):
		hud.set_notice(message)

func _on_move_changed(value: Vector2) -> void:
	if is_instance_valid(player_unit):
		player_unit.set_mobile_move(value)

func _on_attack_pressed() -> void:
	if is_instance_valid(player_unit) and not game_over:
		if is_instance_valid(siege_manager) and siege_manager.try_player_attack_gate():
			return
		player_unit.try_player_attack()

func _on_block_changed(value: bool) -> void:
	if is_instance_valid(player_unit):
		player_unit.set_blocking(value)

func _on_troops_pressed() -> void:
	try_summon_troops()

func try_summon_troops_from_keyboard() -> void:
	if Input.is_key_pressed(KEY_E):
		if not _keyboard_summon_latch:
			_keyboard_summon_latch = true
			try_summon_troops()
	else:
		_keyboard_summon_latch = false

func try_summon_troops() -> void:
	if game_over or not is_instance_valid(player_unit):
		return
	if summon_cooldown > 0.0:
		show_notice("Takviye emri için %d saniye bekle." % ceili(summon_cooldown))
		return
	var existing_allies := count_units(2)
	if existing_allies >= get_max_allies():
		show_notice("Birlik sınırına ulaştın: en fazla %d müttefik." % get_max_allies())
		return
	var to_spawn := mini(2, get_max_allies() - existing_allies)
	for index in range(to_spawn):
		var side := -1.0 if index % 2 == 0 else 1.0
		var spawn_position := _ground_position(player_unit.global_position + Vector3(side * (1.7 + existing_allies * 0.1), 0, 1.2 + float(index)))
		_spawn_ally("infantry", spawn_position, {}, existing_allies + index)
	summon_cooldown = 18.0
	_mark_progress_dirty()
	_refresh_army_panel_if_open()
	show_notice("Takviye geldi! %d/%d asker. Altınla yeni birlikler de toplayabilirsin: ORDU menüsü." % [count_units(2), get_max_allies()])

func _class_profile(class_id: String) -> Dictionary:
	match class_id:
		"archer":
			return {"max_health": 78.0, "move_speed": 3.25, "attack_damage": 14.0 + float(level - 1), "attack_range": 12.0}
		"crossbowman":
			return {"max_health": 92.0, "move_speed": 2.8, "attack_damage": 24.0 + float(level - 1) * 1.15, "attack_range": 16.0}
		"cavalry":
			return {"max_health": 132.0, "move_speed": 5.0, "attack_damage": 25.0 + float(level - 1) * 1.3, "attack_range": 2.25}
		"shield_guard":
			return {"max_health": 168.0, "move_speed": 2.7, "attack_damage": 20.0 + float(level - 1), "attack_range": 1.85}
		_:
			return {"max_health": 110.0, "move_speed": 3.6, "attack_damage": 18.0 + float(level - 1), "attack_range": 1.9}

func _spawn_ally(class_id: String, at: Vector3, saved_data: Dictionary = {}, order_index: int = -1) -> Variant:
	if count_units(2) >= get_max_allies():
		return null
	var safe_class := class_id if class_id in ["infantry", "archer", "cavalry", "shield_guard", "crossbowman"] else "infantry"
	var profile := _class_profile(safe_class)
	var ally: Variant = UnitScript.new()
	ally.team = 2
	ally.unit_class = safe_class
	ally.max_health = maxf(1.0, float(saved_data.get("max_health", profile.get("max_health", 100.0))))
	ally.health = clampf(float(saved_data.get("health", ally.max_health)), 1.0, ally.max_health)
	ally.move_speed = maxf(1.0, float(saved_data.get("move_speed", profile.get("move_speed", 3.5))))
	ally.attack_damage = maxf(1.0, float(saved_data.get("attack_damage", profile.get("attack_damage", 18.0))))
	ally.attack_range = maxf(1.0, float(saved_data.get("attack_range", profile.get("attack_range", 1.9))))
	ally.game_ref = self
	ally.faction_id = str(saved_data.get("faction_id", kingdom_system.player_oath if is_instance_valid(kingdom_system) and not kingdom_system.player_oath.is_empty() else "player"))
	ally.companion_id = str(saved_data.get("companion_id", ""))
	ally.companion_name = str(saved_data.get("companion_name", ""))
	ally.army_order = str(saved_data.get("order", army_order))
	ally.formation_index = clampi(int(saved_data.get("formation_index", order_index if order_index >= 0 else count_units(2))), 0, get_max_allies() - 1)
	var position_value: Variant = saved_data.get("position", {})
	if position_value is Dictionary and not position_value.is_empty():
		at = Vector3(float(position_value.get("x", at.x)), float(position_value.get("y", at.y)), float(position_value.get("z", at.z)))
	ally.position = at
	var anchor_value: Variant = saved_data.get("order_position", {})
	if anchor_value is Dictionary and not anchor_value.is_empty():
		ally.order_position = Vector3(float(anchor_value.get("x", at.x)), float(anchor_value.get("y", at.y)), float(anchor_value.get("z", at.z)))
	else:
		ally.order_position = at
	add_child(ally)
	return ally

func _spawn_saved_allies() -> void:
	var spawned := 0
	for entry in _loaded_army:
		if spawned >= get_max_allies():
			break
		if not entry is Dictionary:
			continue
		var class_id := str(entry.get("class", "infantry"))
		var fallback := _ground_position(player_unit.global_position + Vector3(float(spawned % 3) * 1.8 - 1.8, 0, 2.5 + float(spawned / 3) * 1.6))
		if _spawn_ally(class_id, fallback, entry, spawned) != null:
			spawned += 1
	if spawned > 0:
		show_notice("Kayıttan %d müttefik asker geri yüklendi." % spawned)

func _serialize_army() -> Array[Dictionary]:
	var saved: Array[Dictionary] = []
	var allies: Array = get_tree().get_nodes_in_group("battle_units")
	allies_sort_by_formation(allies)
	for unit in allies:
		if not is_instance_valid(unit) or unit.team != 2 or unit.health <= 0.0:
			continue
		saved.append({
			"class": unit.unit_class,
			"companion_id": str(unit.companion_id),
			"companion_name": str(unit.companion_name),
			"faction_id": unit.faction_id,
			"health": unit.health,
			"max_health": unit.max_health,
			"move_speed": unit.move_speed,
			"attack_damage": unit.attack_damage,
			"attack_range": unit.attack_range,
			"order": unit.army_order,
			"formation_index": unit.formation_index,
			"position": {"x": unit.global_position.x, "y": unit.global_position.y, "z": unit.global_position.z},
			"order_position": {"x": unit.order_position.x, "y": unit.order_position.y, "z": unit.order_position.z}
		})
	return saved

func allies_sort_by_formation(allies: Array) -> void:
	allies.sort_custom(func(a: Variant, b: Variant) -> bool:
		if not is_instance_valid(a):
			return false
		if not is_instance_valid(b):
			return true
		return int(a.formation_index) < int(b.formation_index)
	)

func launch_arrow(origin: Vector3, target: Variant, damage: float, attacker: Variant) -> void:
	if not is_instance_valid(target):
		return
	var arrow: Variant = ArrowScript.new()
	arrow.target = target
	arrow.damage = damage
	arrow.attacker = attacker
	arrow.global_position = origin
	add_child(arrow)

func _get_recruitment_cost(class_id: String) -> int:
	var base_cost := int(RECRUIT_COSTS.get(class_id, 999999))
	if not is_instance_valid(kingdom_system) or kingdom_system.player_oath.is_empty():
		return base_cost
	var discount := 0
	match str(kingdom_system.player_oath):
		"north_crown":
			if class_id == "shield_guard": discount = 15
		"aurel_empire":
			if class_id == "crossbowman": discount = 15
		"red_banner":
			if class_id == "cavalry": discount = 15
		"mountain_clans":
			if class_id == "infantry" or class_id == "archer": discount = 8
		"black_seal":
			discount = 5
	return maxi(10, base_cost - discount)

func _get_army_summary() -> Dictionary:
	var counts := {"infantry": 0, "archer": 0, "cavalry": 0, "shield_guard": 0, "crossbowman": 0}
	for unit in get_tree().get_nodes_in_group("battle_units"):
		if is_instance_valid(unit) and unit.team == 2 and unit.health > 0.0:
			var class_key := str(unit.unit_class)
			counts[class_key] = int(counts.get(class_key, 0)) + 1
	var order_names := {"follow": "Takip", "hold": "Mevzi tut", "charge": "Hücum", "retreat": "Geri çekil"}
	var formation_names := {"line": "Hat düzeni", "wedge": "Kama", "column": "Sütun"}
	var costs: Dictionary = {}
	for class_id in RECRUIT_COSTS.keys():
		costs[class_id] = _get_recruitment_cost(str(class_id))
	return {"count": count_units(2), "capacity": get_max_allies(), "infantry": counts.get("infantry", 0), "archer": counts.get("archer", 0), "cavalry": counts.get("cavalry", 0), "shield_guard": counts.get("shield_guard", 0), "crossbowman": counts.get("crossbowman", 0), "order_name": order_names.get(army_order, "Takip"), "formation_name": formation_names.get(army_formation, "Hat düzeni"), "gold": gold, "costs": costs, "oath": kingdom_system.player_oath if is_instance_valid(kingdom_system) else ""}

func _refresh_army_panel_if_open() -> void:
	if is_instance_valid(hud) and hud.army_open:
		hud.refresh_army_panel(_get_army_summary())

func _record_story_event(event_id: String, amount: int = 1) -> void:
	if not is_instance_valid(quest_system):
		return
	if quest_system.record_event(event_id, amount):
		_mark_progress_dirty()
		_refresh_quest_panel_if_open()

func _refresh_quest_panel_if_open() -> void:
	if is_instance_valid(hud) and hud.quest_open and is_instance_valid(quest_system):
		hud.refresh_quest_journal(quest_system.get_journal_text())

func _on_quest_journal_pressed() -> void:
	if is_instance_valid(hud) and is_instance_valid(quest_system):
		hud.toggle_quest_journal(quest_system.get_journal_text())

func _get_companion_definitions() -> Array[Dictionary]:
	return [
		{"id":"darian", "role":"companion_guard", "name":"Darian", "title":"Eski Muhafız", "class":"shield_guard", "cost":180, "max_health":205.0, "attack_damage":23.0, "move_speed":2.8, "attack_range":1.9, "ability":"Koruyucu: komutanın aldığı hasarı %8 azaltır."},
		{"id":"runa", "role":"companion_healer", "name":"Runa", "title":"Gezgin Şifacı", "class":"crossbowman", "cost":220, "max_health":112.0, "attack_damage":17.0, "move_speed":3.0, "attack_range":14.0, "ability":"Şifacı: her 24 saniyede komutana 12 can yeniler."},
		{"id":"taren", "role":"companion_scout", "name":"Taren", "title":"Sınır İzci", "class":"cavalry", "cost":190, "max_health":142.0, "attack_damage":22.0, "move_speed":4.8, "attack_range":2.2, "ability":"Öncü: komutanın hareket hızını %8 artırır."},
		{"id":"selka", "role":"companion_ranger", "name":"Selka", "title":"Orman Avcısı", "class":"archer", "cost":170, "max_health":98.0, "attack_damage":19.0, "move_speed":3.8, "attack_range":13.0, "ability":"Avcı: komutanın saldırı hasarını %10 artırır."}
	]

func _get_companion_definition_by_role(role: String) -> Dictionary:
	for entry in _get_companion_definitions():
		if str(entry.get("role", "")) == role:
			return entry
	return {}

func _has_live_companion(companion_id: String) -> bool:
	for ally in get_tree().get_nodes_in_group("battle_units"):
		if is_instance_valid(ally) and ally.team == 2 and ally.health > 0.0 and str(ally.companion_id) == companion_id:
			return true
	return false

func _load_graphics_quality() -> String:
	var config := ConfigFile.new()
	if config.load(GRAPHICS_CONFIG_PATH) != OK:
		return "balanced"
	var saved_quality := str(config.get_value("graphics", "quality", "balanced"))
	return saved_quality if saved_quality in ["low", "balanced", "high"] else "balanced"

func _apply_graphics_quality(show_message: bool = true) -> void:
	if graphics_quality not in ["low", "balanced", "high"]:
		graphics_quality = "balanced"
	Engine.max_fps = 30 if graphics_quality == "low" else (45 if graphics_quality == "balanced" else 60)
	if is_instance_valid(world_ref) and world_ref.has_method("apply_graphics_quality"):
		world_ref.apply_graphics_quality(graphics_quality)
	var config := ConfigFile.new()
	config.set_value("graphics", "quality", graphics_quality)
	var save_error := config.save(GRAPHICS_CONFIG_PATH)
	if save_error != OK:
		push_warning("Grafik tercihi kaydedilemedi: %s" % error_string(save_error))
	if is_instance_valid(hud):
		hud.refresh_graphics_settings(graphics_quality)
	if show_message:
		var display_names := {"low": "DÜŞÜK", "balanced": "DENGELİ", "high": "YÜKSEK"}
		show_notice("Grafik ayarı: %s. Değişiklik hemen uygulandı." % str(display_names.get(graphics_quality, "DENGELİ")))

func _on_graphics_panel_pressed() -> void:
	if is_instance_valid(hud):
		hud.toggle_graphics_panel()

func _on_graphics_quality_selected(quality_id: String) -> void:
	if quality_id not in ["low", "balanced", "high"]:
		return
	if graphics_quality == quality_id:
		return
	graphics_quality = quality_id
	_apply_graphics_quality(true)

func _interact_with_companion(npc: Variant) -> void:
	var profile := _get_companion_definition_by_role(str(npc.role))
	if profile.is_empty():
		show_notice("Bu yol arkadaşı şu anda gruba katılamıyor.")
		return
	var companion_id := str(profile.get("id", ""))
	if _has_live_companion(companion_id):
		_handle_companion_story_interaction(companion_id, profile)
		return
	if count_units(2) >= get_max_allies():
		show_notice("Ordu dolu (%d/%d). Birlik kapasitesini artır veya yer aç." % [count_units(2), get_max_allies()])
		return
	var cost := int(profile.get("cost", 9999))
	if gold < cost:
		show_notice("%s: Yolculuğa katılmam için %d altın gerekiyor." % [str(profile.get("name", "Yoldaş")), cost])
		return
	if not is_instance_valid(player_unit):
		return
	var index := count_units(2)
	var spawn_position := _ground_position(player_unit.global_position + Vector3(-1.8 if index % 2 == 0 else 1.8, 0, 2.2 + float(index % 3) * 0.6))
	var saved_profile := profile.duplicate(true)
	saved_profile["faction_id"] = kingdom_system.player_oath if is_instance_valid(kingdom_system) and not kingdom_system.player_oath.is_empty() else "player"
	saved_profile["order"] = army_order
	var ally: Variant = _spawn_ally(str(profile.get("class", "infantry")), spawn_position, saved_profile, index)
	if ally == null:
		show_notice("Yoldaş gruba katılamadı. Ordu kapasitesini kontrol et.")
		return
	ally.companion_id = companion_id
	ally.companion_name = str(profile.get("name", "Yoldaş"))
	ally.army_order = army_order
	ally._update_name_label()
	gold -= cost
	if is_instance_valid(quest_system):
		quest_system.start_companion_story(companion_id)
		_mark_progress_dirty()
	_refresh_progress_panels()
	_refresh_army_panel_if_open()
	_refresh_companion_panel_if_open()
	show_notice("%s sana katıldı! -%d altın. Kişisel hikâyesi açıldı: %s" % [str(profile.get("name", "Yoldaş")), cost, str(quest_system.get_companion_story(companion_id).get("title", "Yoldaş görevi"))])

func _handle_companion_story_interaction(companion_id: String, profile: Dictionary) -> void:
	if not is_instance_valid(quest_system):
		show_notice("%s seninle yolculuk ediyor. Yeteneği etkin." % str(profile.get("name", "Yoldaş")))
		return
	var story: Dictionary = quest_system.get_companion_story(companion_id)
	var state := str(story.get("state", "inactive"))
	if state == "inactive":
		quest_system.start_companion_story(companion_id)
		story = quest_system.get_companion_story(companion_id)
		state = str(story.get("state", "active"))
	if state == "complete":
		show_notice("%s: %s tamamlandı. Sadakat %d/100. Kararım: %s." % [str(profile.get("name", companion_id)), str(story.get("title", "Kişisel görev")), int(story.get("loyalty", 50)), str(story.get("choice", "—"))])
		return
	if state == "active":
		show_notice("%s · %s: %d/%d. %s" % [str(profile.get("name", companion_id)), str(story.get("objective", "Hedef")), int(story.get("progress", 0)), int(story.get("target", 1)), str(story.get("description", ""))])
		return
	if state == "ready":
		pending_story_choice = {"type": "companion", "companion_id": companion_id}
		var choices: Array[Dictionary] = []
		match companion_id:
			"darian":
				choices = [{"id": "darian_mercy", "label": "Eski askerlere merhamet", "description": "Darian'ın geçmişini kapat; sadakat ve Kuzey Tahtı itibarı artar."}, {"id": "darian_vengeance", "label": "İntikam yeminini sürdür", "description": "Daha çok ganimet al; Darian'ın sadakati düşebilir."}]
			"runa":
				choices = [{"id": "runa_share", "label": "İksirleri köyle paylaş", "description": "Şifa stoğu kazan; Dağ Klanları seni daha çok takdir eder."}, {"id": "runa_sell", "label": "İksirleri tüccara sat", "description": "Altın kazan; Runa'nın sadakati azalabilir."}]
			"taren":
				choices = [{"id": "taren_warn", "label": "Kervanları önceden uyar", "description": "Ticaret yolunu koru; halkın itibarı artar."}, {"id": "taren_ambush", "label": "Pusu kurup ganimet al", "description": "Ek altın kazan; diplomatik bedeli var."}]
			"selka":
				choices = [{"id": "selka_forgive", "label": "Doğanın dengesini koru", "description": "Selka'nın güvenini kazan; hayatta kalan avcıları bağışla."}, {"id": "selka_hunt", "label": "Sürüyü tamamen dağıt", "description": "Daha büyük ödül al; Selka'nın sadakati daha az artar."}]
		hud.show_story_choices(str(story.get("title", "Yoldaş hikâyesi")), str(story.get("description", "Görevin son kararını ver.")), choices)

func _get_companion_summary() -> Dictionary:
	var rows: Array[String] = []
	var active_names: Array[String] = []
	for entry in _get_companion_definitions():
		var recruited := _has_live_companion(str(entry.get("id", "")))
		if recruited:
			active_names.append(str(entry.get("name", "Yoldaş")))
		var story: Dictionary = quest_system.get_companion_story(str(entry.get("id", ""))) if is_instance_valid(quest_system) else {}
		var story_state := str(story.get("state", "inactive"))
		var story_status := "Kişisel görev tamamlandı" if story_state == "complete" else ("Kişisel görev teslim kararı bekliyor" if story_state == "ready" else ("Kişisel görev %d/%d" % [int(story.get("progress", 0)), int(story.get("target", 1))] if story_state == "active" else "Kişisel görev kilitli"))
		rows.append("%s — %s\n%s\n%s • Sadakat %d/100\nDurum: %s • Katılım: %d altın" % [str(entry.get("name", "Yoldaş")), str(entry.get("title", "")), str(entry.get("ability", "")), story_status, int(story.get("loyalty", 50)), "GRUPTA / AKTİF" if recruited else "DÜNYADA BULUNABİLİR", int(entry.get("cost", 0))])
	return {"count": active_names.size(), "army_count": count_units(2), "capacity": get_max_allies(), "gold": gold, "active_names": active_names, "text": "\n\n".join(PackedStringArray(rows))}

func _refresh_companion_panel_if_open() -> void:
	if is_instance_valid(hud) and hud.companion_open:
		hud.refresh_companions(_get_companion_summary())

func _on_companion_panel_pressed() -> void:
	if is_instance_valid(hud):
		hud.toggle_companion_panel(_get_companion_summary())

func _get_skills_summary() -> Dictionary:
	return {"points": skill_points, "levels": skill_levels.duplicate(true), "max_level": 3, "player_level": level, "army_capacity": get_max_allies()}

func _refresh_skills_panel_if_open() -> void:
	if is_instance_valid(hud) and hud.skills_open:
		hud.refresh_skills(_get_skills_summary())

func _on_skills_panel_pressed() -> void:
	if is_instance_valid(hud):
		hud.toggle_skills_panel(_get_skills_summary())

func _on_skill_purchase_pressed(skill_id: String) -> void:
	if skill_id not in ["combat", "leadership", "survival"]:
		return
	if skill_points <= 0:
		show_notice("Yetenek geliştirmek için önce seviye atlayıp puan kazanmalısın.")
		return
	var current_level := int(skill_levels.get(skill_id, 0))
	if current_level >= 3:
		show_notice("Bu yetenek en yüksek seviyede.")
		return
	skill_levels[skill_id] = current_level + 1
	skill_points -= 1
	match skill_id:
		"survival":
			if is_instance_valid(player_unit):
				player_unit.max_health += 15.0
				player_unit.health = minf(player_unit.max_health, player_unit.health + 15.0)
			show_notice("Hayatta kalma %d/3: +15 azami can ve hasara karşı daha fazla direnç." % (current_level + 1))
		"leadership":
			show_notice("Liderlik %d/3: ordu kapasitesi %d oldu." % [current_level + 1, get_max_allies()])
		_:
			show_notice("Savaş ustalığı %d/3: komutanın saldırı hasarı %%%d arttı." % [current_level + 1, (current_level + 1) * 8])
	_mark_progress_dirty()
	_refresh_progress_panels()
	_refresh_army_panel_if_open()
	_refresh_skills_panel_if_open()

func get_max_allies() -> int:
	return MAX_ALLIES + int(skill_levels.get("leadership", 0)) * 2

func _companion_loyalty_scale(companion_id: String) -> float:
	if not is_instance_valid(quest_system):
		return 1.0
	var story: Dictionary = quest_system.get_companion_story(companion_id)
	# Loyalty 50 is normal; 0 halves and 100 raises a passive's effect by 50%.
	return clampf(float(story.get("loyalty", 50)) / 50.0, 0.5, 1.5)

func get_companion_outgoing_damage_multiplier() -> float:
	var multiplier := 1.0 + float(skill_levels.get("combat", 0)) * 0.08
	if _has_live_companion("selka"):
		multiplier *= 1.0 + 0.10 * _companion_loyalty_scale("selka")
	return multiplier

func get_companion_incoming_damage_multiplier() -> float:
	var multiplier := 1.0 - float(skill_levels.get("survival", 0)) * 0.04
	if _has_live_companion("darian"):
		multiplier *= 1.0 - 0.08 * _companion_loyalty_scale("darian")
	return clampf(multiplier, 0.72, 1.0)

func get_companion_move_multiplier() -> float:
	if _has_live_companion("taren"):
		return 1.0 + 0.08 * _companion_loyalty_scale("taren")
	return 1.0

func _on_siege_command_pressed(command_id: String) -> void:
	if is_instance_valid(siege_manager):
		siege_manager.request_command(command_id)
		if is_instance_valid(hud) and hud.has_method("update_siege_status"):
			hud.update_siege_status(siege_manager.get_status_text(), siege_manager.catapult_cooldown, siege_manager.get_catapult_cost())

func get_settlement_defense_multiplier(position: Vector3) -> float:
	if not is_instance_valid(settlement_manager) or not settlement_manager.castle_owned:
		return 1.0
	# The fortification/garrison bonus applies only inside the captured inner courtyard.
	if absf(position.x) > 10.5 or position.z < -55.5 or position.z > -39.5:
		return 1.0
	var wall_reduction := float(settlement_manager.get_building_level("walls")) * 0.04
	var garrison_reduction := minf(float(settlement_manager.garrison_units), 10.0) * 0.005
	return clampf(1.0 - wall_reduction - garrison_reduction, 0.78, 1.0)

func _get_settlement_summary() -> Dictionary:
	if not is_instance_valid(settlement_manager):
		return {"castle_owned": false, "gold": gold}
	var summary: Dictionary = settlement_manager.get_summary()
	summary["gold"] = gold
	return summary

func _refresh_settlement_panel_if_open() -> void:
	if is_instance_valid(hud) and hud.settlement_open:
		hud.refresh_settlement_panel(_get_settlement_summary())

func _on_settlement_panel_pressed() -> void:
	if is_instance_valid(hud):
		hud.toggle_settlement_panel(_get_settlement_summary())

func _on_settlement_action_pressed(action_id: String) -> void:
	if not is_instance_valid(settlement_manager):
		return
	var result: Dictionary = {}
	match action_id:
		"upgrade_barracks":
			result = settlement_manager.upgrade_building("barracks", gold)
		"upgrade_walls":
			result = settlement_manager.upgrade_building("walls", gold)
		"upgrade_market":
			result = settlement_manager.upgrade_building("market", gold)
		"recruit_garrison":
			result = settlement_manager.recruit_garrison(gold)
		"collect_taxes":
			result = settlement_manager.collect_taxes(gold)
		_:
			show_notice("Bilinmeyen yerleşim emri.")
			return
	if bool(result.get("ok", false)):
		gold = maxi(0, int(result.get("gold", gold)))
		_mark_progress_dirty()
	_show_settlement_result(str(result.get("message", "İşlem tamamlandı.")))
	_refresh_progress_panels()
	_refresh_settlement_panel_if_open()

func _show_settlement_result(message: String) -> void:
	show_notice(message)

func _issue_army_order(order_id: String) -> void:
	if order_id not in ["follow", "hold", "charge", "retreat"]:
		return
	army_order = order_id
	var index := 0
	for unit in get_tree().get_nodes_in_group("battle_units"):
		if not is_instance_valid(unit) or unit.team != 2 or unit.health <= 0.0:
			continue
		unit.set_army_order(order_id, index)
		index += 1
	_mark_progress_dirty()
	_refresh_army_panel_if_open()
	var labels := {"follow": "Birlik sana yakın formasyonda dönüyor.", "hold": "Birlik bulunduğu mevzide kalacak.", "charge": "HÜCUM! Birlik yakındaki düşmanlara saldıracak.", "retreat": "Geri çekilme emri verildi."}
	show_notice(str(labels.get(order_id, "Emir verildi.")))

func _set_army_formation(formation_id: String) -> void:
	if formation_id not in ["line", "wedge", "column"]:
		return
	army_formation = formation_id
	var index := 0
	for unit in get_tree().get_nodes_in_group("battle_units"):
		if not is_instance_valid(unit) or unit.team != 2 or unit.health <= 0.0:
			continue
		unit.set_formation_index(index)
		index += 1
	_mark_progress_dirty()
	_refresh_army_panel_if_open()
	var labels := {"line": "Hat düzeni: birlik geniş cephe kuracak.", "wedge": "Kama düzeni: birlik mızrak ucu gibi ilerleyecek.", "column": "Sütun düzeni: dar yollarda daha sıkı yürüyecek."}
	show_notice(str(labels.get(formation_id, "Formasyon değiştirildi.")))

func _recruit_troop(class_id: String) -> void:
	if class_id not in ["infantry", "archer", "cavalry", "shield_guard", "crossbowman"]:
		return
	if count_units(2) >= get_max_allies():
		show_notice("Ordu tam kadro: en fazla %d asker." % get_max_allies())
		return
	var cost := _get_recruitment_cost(class_id)
	if gold < cost:
		show_notice("Bu asker için %d altın gerekiyor." % cost)
		return
	if not is_instance_valid(player_unit):
		return
	var index := count_units(2)
	var lateral := -1.0 if index % 2 == 0 else 1.0
	var spawn_position := _ground_position(player_unit.global_position + Vector3(lateral * (1.8 + float(index / 2) * 0.3), 0, 2.0 + float(index % 3) * 0.7))
	var ally: Variant = _spawn_ally(class_id, spawn_position, {}, index)
	if ally == null:
		return
	ally.army_order = army_order
	ally._update_name_label()
	gold -= cost
	_mark_progress_dirty()
	_refresh_progress_panels()
	_refresh_army_panel_if_open()
	var names := {"infantry": "Piyade", "archer": "Okçu", "cavalry": "Süvari", "shield_guard": "Kalkanlı muhafız", "crossbowman": "Arbaletçi"}
	show_notice("%s birliğe katıldı. -%d altın. Ordu: %d/%d." % [str(names.get(class_id, "Asker")), cost, count_units(2), get_max_allies()])

func _slot_save_path(slot_id: int) -> String:
	return "user://karanlik_tac_slot_%d.json" % clampi(slot_id, 1, SAVE_SLOT_COUNT)

func _load_active_slot() -> void:
	active_save_slot = 1
	if not FileAccess.file_exists(ACTIVE_SLOT_PATH):
		selected_save_slot = active_save_slot
		return
	var file := FileAccess.open(ACTIVE_SLOT_PATH, FileAccess.READ)
	if file != null:
		active_save_slot = clampi(file.get_as_text().strip_edges().to_int(), 1, SAVE_SLOT_COUNT)
		file.close()
	selected_save_slot = active_save_slot

func _write_active_slot() -> void:
	var file := FileAccess.open(ACTIVE_SLOT_PATH, FileAccess.WRITE)
	if file == null:
		return
	file.store_string(str(clampi(active_save_slot, 1, SAVE_SLOT_COUNT)))
	file.close()

func _load_save_file() -> void:
	var path := _slot_save_path(active_save_slot)
	_loaded_from_legacy = false
	if not FileAccess.file_exists(path) and active_save_slot == 1 and FileAccess.file_exists(LEGACY_SAVE_PATH):
		path = LEGACY_SAVE_PATH
		_loaded_from_legacy = true
	if not FileAccess.file_exists(path):
		return
	var file := FileAccess.open(path, FileAccess.READ)
	if file == null:
		return
	var parsed: Variant = JSON.parse_string(file.get_as_text())
	file.close()
	if not parsed is Dictionary:
		return
	var save_data: Dictionary = parsed
	var stored_version := int(save_data.get("save_format_version", 0))
	if stored_version < 1 or stored_version > SAVE_FORMAT_VERSION:
		return
	_loaded_save_data = save_data
	_has_loaded_save = true
	army_order = str(save_data.get("army_order", "follow"))
	if army_order not in ["follow", "hold", "charge", "retreat"]:
		army_order = "follow"
	army_formation = str(save_data.get("army_formation", "line"))
	if army_formation not in ["line", "wedge", "column"]:
		army_formation = "line"
	var army_value: Variant = save_data.get("army", [])
	_loaded_army = army_value if army_value is Array else []
	var progress: Variant = save_data.get("progress", {})
	if progress is Dictionary:
		gold = maxi(0, int(progress.get("gold", gold)))
		xp = maxi(0, int(progress.get("xp", xp)))
		level = maxi(1, int(progress.get("level", level)))
		skill_points = maxi(0, int(progress.get("skill_points", skill_points)))
		var loaded_skill_levels: Variant = progress.get("skill_levels", {})
		if loaded_skill_levels is Dictionary:
			for skill_id in ["combat", "leadership", "survival"]:
				skill_levels[skill_id] = clampi(int(loaded_skill_levels.get(skill_id, skill_levels[skill_id])), 0, 3)
		weapon_level = clampi(int(progress.get("weapon_level", weapon_level)), 1, 3)
		weapon_type = str(progress.get("weapon_type", weapon_type))
		if weapon_type not in ["sword", "spear", "greatsword", "axe"]:
			weapon_type = "sword"
		armor_level = clampi(int(progress.get("armor_level", armor_level)), 0, 3)
		boots_level = clampi(int(progress.get("boots_level", boots_level)), 0, 2)
		ring_level = clampi(int(progress.get("ring_level", ring_level)), 0, 2)
		kills = maxi(0, int(progress.get("kills", kills)))
		wolf_quest_state = clampi(int(progress.get("wolf_quest_state", wolf_quest_state)), 0, 3)
		wolf_quest_count = clampi(int(progress.get("wolf_quest_count", wolf_quest_count)), 0, 4)
		ruin_quest_state = clampi(int(progress.get("ruin_quest_state", ruin_quest_state)), 0, 3)
		skeleton_quest_count = clampi(int(progress.get("skeleton_quest_count", skeleton_quest_count)), 0, 5)
		bandit_quest_state = clampi(int(progress.get("bandit_quest_state", bandit_quest_state)), 0, 3)
		bandit_quest_count = clampi(int(progress.get("bandit_quest_count", bandit_quest_count)), 0, 5)
	var loaded_inventory: Variant = save_data.get("inventory", {})
	if loaded_inventory is Dictionary:
		for item_key in inventory.keys():
			inventory[item_key] = maxi(0, int(loaded_inventory.get(item_key, inventory[item_key])))
	var world_state: Variant = save_data.get("world", {})
	if world_state is Dictionary:
		opened_chest_ids = _string_array_from_variant(world_state.get("opened_chests", []))
		defeated_creature_ids = _string_array_from_variant(world_state.get("defeated_creatures", []))

func _get_save_slot_summaries() -> Array[Dictionary]:
	var summaries: Array[Dictionary] = []
	for slot_id in range(1, SAVE_SLOT_COUNT + 1):
		var path := _slot_save_path(slot_id)
		var legacy_for_first := slot_id == 1 and not FileAccess.file_exists(path) and FileAccess.file_exists(LEGACY_SAVE_PATH)
		if legacy_for_first:
			path = LEGACY_SAVE_PATH
		var summary: Dictionary = {"slot": slot_id, "exists": false, "valid": true, "level": 1, "gold": 0, "saved_at": "", "weapon_level": 1, "armor_level": 0}
		if FileAccess.file_exists(path):
			var file := FileAccess.open(path, FileAccess.READ)
			if file != null:
				var parsed: Variant = JSON.parse_string(file.get_as_text())
				file.close()
				if parsed is Dictionary and parsed.get("progress", {}) is Dictionary:
					var progress: Dictionary = parsed.get("progress", {})
					summary["exists"] = true
					summary["level"] = maxi(1, int(progress.get("level", 1)))
					summary["gold"] = maxi(0, int(progress.get("gold", 0)))
					summary["weapon_level"] = clampi(int(progress.get("weapon_level", 1)), 1, 3)
					summary["armor_level"] = clampi(int(progress.get("armor_level", 0)), 0, 3)
					summary["saved_at"] = str(parsed.get("saved_at", ""))
					summary["valid"] = int(parsed.get("save_format_version", 0)) >= 1 and int(parsed.get("save_format_version", 0)) <= SAVE_FORMAT_VERSION
				else:
					summary["exists"] = true
					summary["valid"] = false
		summaries.append(summary)
	return summaries

func _string_array_from_variant(value: Variant) -> Array[String]:
	var result: Array[String] = []
	if value is Array:
		for entry in value:
			var id := str(entry)
			if not id.is_empty() and not result.has(id):
				result.append(id)
	return result

func save_game(show_message: bool = true) -> bool:
	if not is_instance_valid(player_unit):
		return false
	var position_data := {
		"x": snappedf(player_unit.global_position.x, 0.01),
		"y": snappedf(player_unit.global_position.y, 0.01),
		"z": snappedf(player_unit.global_position.z, 0.01)
	}
	var payload := {
		"save_format_version": SAVE_FORMAT_VERSION,
		"game_version": "0.15.0",
		"save_slot": active_save_slot,
		"saved_at": Time.get_datetime_string_from_system(),
		"player": {
			"position": position_data,
			"health": player_unit.health,
			"max_health": player_unit.max_health,
			"attack_damage": player_unit.attack_damage,
			"move_speed": player_unit.move_speed,
			"weapon_type": weapon_type,
			"stamina": player_unit.stamina
		},
		"progress": {
			"gold": gold,
			"xp": xp,
			"level": level,
			"skill_points": skill_points,
			"skill_levels": skill_levels.duplicate(true),
			"weapon_level": weapon_level,
			"armor_level": armor_level,
			"boots_level": boots_level,
			"ring_level": ring_level,
			"kills": kills,
			"wolf_quest_state": wolf_quest_state,
			"wolf_quest_count": wolf_quest_count,
			"ruin_quest_state": ruin_quest_state,
			"skeleton_quest_count": skeleton_quest_count,
			"bandit_quest_state": bandit_quest_state,
			"bandit_quest_count": bandit_quest_count,
			"weapon_type": weapon_type
		},
		"inventory": inventory.duplicate(true),
		"army_order": army_order,
		"army_formation": army_formation,
		"army": _serialize_army(),
		"world": {
			"opened_chests": opened_chest_ids.duplicate(),
			"defeated_creatures": defeated_creature_ids.duplicate(),
			"gate_health": siege_manager.gate_health if is_instance_valid(siege_manager) else 900.0,
			"castle_captured": siege_manager.castle_captured if is_instance_valid(siege_manager) else false,
			"siege_started": siege_manager.siege_started if is_instance_valid(siege_manager) else false,
			"gate_assault_active": siege_manager.gate_assault_active if is_instance_valid(siege_manager) else false,
			"capture_attempt_active": siege_manager.capture_attempt_active if is_instance_valid(siege_manager) else false,
			"capture_progress": siege_manager.capture_progress if is_instance_valid(siege_manager) else 0.0,
			"sieges": siege_manager.get_save_state() if is_instance_valid(siege_manager) else {},
			"kingdoms": kingdom_system.to_dict() if is_instance_valid(kingdom_system) else {},
			"settlement": settlement_manager.to_dict() if is_instance_valid(settlement_manager) else {},
			"story": quest_system.to_dict() if is_instance_valid(quest_system) else {},
			"living_world": world_life.get_save_state() if is_instance_valid(world_life) else {}
		}
	}
	var file := FileAccess.open(_slot_save_path(active_save_slot), FileAccess.WRITE)
	if file == null:
		if show_message:
			show_notice("Kayıt yazılamadı. Cihaz depolama alanını kontrol et.")
		return false
	file.store_string(JSON.stringify(payload, "\t"))
	file.close()
	_write_active_slot()
	_progress_dirty = false
	_auto_save_elapsed = 0.0
	if show_message:
		show_notice("Yuva %d kaydedildi. İlerleme ve ekipman saklandı." % active_save_slot)
	if is_instance_valid(hud):
		hud.refresh_save_slots(_get_save_slot_summaries(), selected_save_slot)
	return true

func _mark_progress_dirty() -> void:
	_progress_dirty = true

func _weapon_profile(weapon_id: String = "") -> Dictionary:
	var selected := weapon_type if weapon_id.is_empty() else weapon_id
	match selected:
		"spear":
			return {"id": "spear", "name": "Uzun Mızrak", "damage": 0.88, "range": 3.05, "cooldown": 1.03, "stamina": 10.0}
		"greatsword":
			return {"id": "greatsword", "name": "Ağır Kılıç", "damage": 1.32, "range": 2.55, "cooldown": 1.12, "stamina": 18.0}
		"axe":
			return {"id": "axe", "name": "Savaş Baltası", "damage": 1.18, "range": 2.12, "cooldown": 0.96, "stamina": 14.0}
		_:
			return {"id": "sword", "name": "Uzun Kılıç", "damage": 1.0, "range": 2.25, "cooldown": 0.78, "stamina": 12.0}

func get_weapon_display_name() -> String:
	return str(_weapon_profile().get("name", "Uzun Kılıç"))

func get_weapon_damage_multiplier() -> float:
	var profile := _weapon_profile()
	var level_bonus := 1.0 + float(maxi(0, weapon_level - 1)) * 0.1
	return float(profile.get("damage", 1.0)) * level_bonus

func cycle_weapon_type() -> void:
	if not is_instance_valid(player_unit) or game_over:
		return
	var choices: Array[String] = ["sword", "spear", "greatsword", "axe"]
	var index := choices.find(weapon_type)
	weapon_type = choices[(index + 1) % choices.size()]
	var profile := _weapon_profile()
	player_unit.attack_range = float(profile.get("range", 2.25))
	player_unit.refresh_gear_visuals()
	_mark_progress_dirty()
	_refresh_progress_panels()
	show_notice("Silah değişti: %s • Hasar x%.2f • Menzil %.1f" % [get_weapon_display_name(), get_weapon_damage_multiplier(), player_unit.attack_range])

func _on_weapon_cycle_pressed() -> void:
	cycle_weapon_type()

func _on_sprint_changed(value: bool) -> void:
	if is_instance_valid(player_unit):
		player_unit.set_mobile_sprint(value)

func use_healing_potion() -> void:
	if not is_instance_valid(player_unit) or game_over:
		return
	var potion_count := int(inventory.get("healing_potion", 0))
	if potion_count <= 0:
		show_notice("Çantanda şifa iksiri kalmadı. Köy tüccarını ziyaret et.")
		return
	if player_unit.health >= player_unit.max_health:
		show_notice("Canın dolu; şifa iksirini daha sonra kullan.")
		return
	inventory["healing_potion"] = potion_count - 1
	var before: float = float(player_unit.health)
	player_unit.health = minf(player_unit.max_health, player_unit.health + 85.0)
	var restored := roundi(player_unit.health - before)
	_mark_progress_dirty()
	_refresh_progress_panels()
	show_notice("Şifa iksiri kullanıldı: +%d can. İksir: %d" % [restored, int(inventory["healing_potion"])])

func _add_creature_drop(species: String) -> String:
	var item_key := "wolf_pelt"
	var item_label := "Kurt Postu"
	match species:
		"wolf":
			item_key = "wolf_pelt"
			item_label = "Kurt Postu"
		"skeleton":
			item_key = "bone_fragment"
			item_label = "Kemik Parçası"
		"spider":
			item_key = "spider_silk"
			item_label = "Örümcek İpeği"
		"bog_troll":
			item_key = "bog_core"
			item_label = "Bataklık Özü"
		"wraith":
			item_key = "ash_essence"
			item_label = "Kül Özü"
		"drake":
			item_key = "drake_scale"
			item_label = "Ejder Pulu"
	inventory[item_key] = int(inventory.get(item_key, 0)) + 1
	_refresh_progress_panels()
	return item_label

func _get_recipe_data(recipe_id: String) -> Dictionary:
	match recipe_id:
		"potion_bundle":
			return {"id": recipe_id, "title": "Simya: 2 Şifa İksiri", "description": "1 Kurt Postu + 1 Örümcek İpeği • 8 altın", "materials": {"wolf_pelt": 1, "spider_silk": 1}, "gold": 8, "maxed": false}
		"armor":
			if armor_level == 0:
				return {"id": recipe_id, "title": "Deri Zırh I", "description": "3 Kurt Postu + 2 Kemik Parçası • 35 altın", "materials": {"wolf_pelt": 3, "bone_fragment": 2}, "gold": 35, "maxed": false}
			if armor_level == 1:
				return {"id": recipe_id, "title": "Takviyeli Zırh II", "description": "4 Kemik Parçası + 2 Bataklık Özü • 80 altın", "materials": {"bone_fragment": 4, "bog_core": 2}, "gold": 80, "maxed": false}
			if armor_level == 2:
				return {"id": recipe_id, "title": "Ejderpulları Zırhı III", "description": "3 Ejder Pulu + 2 Kül Özü • 160 altın", "materials": {"drake_scale": 3, "ash_essence": 2}, "gold": 160, "maxed": false}
			return {"id": recipe_id, "title": "Zırh ustalığı tamamlandı", "description": "Bu zırh yuvasının en yüksek seviyesi.", "materials": {}, "gold": 0, "maxed": true}
		"boots":
			if boots_level == 0:
				return {"id": recipe_id, "title": "Gezgin Çizmeleri I", "description": "3 Örümcek İpeği + 1 Kurt Postu • 30 altın", "materials": {"spider_silk": 3, "wolf_pelt": 1}, "gold": 30, "maxed": false}
			if boots_level == 1:
				return {"id": recipe_id, "title": "Gölge Çizmeleri II", "description": "4 Örümcek İpeği + 1 Kül Özü • 75 altın", "materials": {"spider_silk": 4, "ash_essence": 1}, "gold": 75, "maxed": false}
			return {"id": recipe_id, "title": "Çizme ustalığı tamamlandı", "description": "Hareket hızı için daha fazla yükseltme yok.", "materials": {}, "gold": 0, "maxed": true}
		"ring":
			if ring_level == 0:
				return {"id": recipe_id, "title": "Koruyucu Rün Yüzüğü I", "description": "2 Kül Özü + 2 Örümcek İpeği • 55 altın", "materials": {"ash_essence": 2, "spider_silk": 2}, "gold": 55, "maxed": false}
			if ring_level == 1:
				return {"id": recipe_id, "title": "Ejder Rünü Yüzüğü II", "description": "1 Bataklık Özü + 2 Ejder Pulu • 130 altın", "materials": {"bog_core": 1, "drake_scale": 2}, "gold": 130, "maxed": false}
			return {"id": recipe_id, "title": "Rün yüzüğü ustalığı tamamlandı", "description": "Bu aksesuar yuvasının en yüksek seviyesi.", "materials": {}, "gold": 0, "maxed": true}
		"sword":
			if weapon_level == 1:
				return {"id": recipe_id, "title": "Çelik Kılıç II", "description": "3 Kemik Parçası + 1 Ejder Pulu • 95 altın", "materials": {"bone_fragment": 3, "drake_scale": 1}, "gold": 95, "maxed": false}
			if weapon_level == 2:
				return {"id": recipe_id, "title": "Kadim Kılıç III", "description": "2 Ejder Pulu + 2 Kül Özü • 160 altın", "materials": {"drake_scale": 2, "ash_essence": 2}, "gold": 160, "maxed": false}
			return {"id": recipe_id, "title": "Kılıç ustalığı tamamlandı", "description": "Kılıcın en yüksek seviyeye ulaştı.", "materials": {}, "gold": 0, "maxed": true}
	return {}

func _can_afford_recipe(recipe: Dictionary) -> bool:
	if bool(recipe.get("maxed", false)) or gold < int(recipe.get("gold", 0)):
		return false
	var materials: Variant = recipe.get("materials", {})
	if not materials is Dictionary:
		return false
	for item_key in materials.keys():
		if int(inventory.get(str(item_key), 0)) < int(materials[item_key]):
			return false
	return true

func _get_crafting_options() -> Array[Dictionary]:
	var options: Array[Dictionary] = []
	for recipe_id in ["potion_bundle", "armor", "boots", "ring", "sword"]:
		var recipe := _get_recipe_data(recipe_id)
		if recipe.is_empty():
			continue
		recipe["ready"] = _can_afford_recipe(recipe)
		options.append(recipe)
	return options

func craft_recipe(recipe_id: String) -> void:
	if game_over or not is_instance_valid(player_unit):
		return
	var recipe := _get_recipe_data(recipe_id)
	if recipe.is_empty():
		show_notice("Bu üretim tarifi bulunamadı.")
		return
	if bool(recipe.get("maxed", false)):
		show_notice("Bu ekipman zaten en yüksek seviyede.")
		return
	if not _can_afford_recipe(recipe):
		show_notice("Üretim için gereken malzemeler veya altın eksik.")
		return
	var materials: Dictionary = recipe.get("materials", {})
	for item_key in materials.keys():
		inventory[str(item_key)] = int(inventory.get(str(item_key), 0)) - int(materials[item_key])
	gold -= int(recipe.get("gold", 0))
	match recipe_id:
		"potion_bundle":
			inventory["healing_potion"] = int(inventory.get("healing_potion", 0)) + 2
		"armor":
			armor_level = mini(3, armor_level + 1)
		"boots":
			boots_level = mini(2, boots_level + 1)
			player_unit.move_speed += 0.4
		"ring":
			ring_level = mini(2, ring_level + 1)
		"sword":
			weapon_level = mini(3, weapon_level + 1)
			player_unit.attack_damage += 11.0
	_refresh_player_gear_visuals()
	_mark_progress_dirty()
	_refresh_progress_panels()
	show_notice("Üretim başarılı: %s. Malzemeler tüketildi." % str(recipe.get("title", "Eşya")))

func get_player_damage_multiplier() -> float:
	var reduction := float(armor_level) * 0.07 + float(ring_level) * 0.04
	return clampf(1.0 - reduction, 0.5, 1.0)

func _get_equipment_summary() -> Dictionary:
	var armor_names := ["Gezgin Giysisi", "Deri Zırh I", "Takviyeli Zırh II", "Ejderpulları Zırhı III"]
	var boot_names := ["Yıpranmış Çizmeler", "Gezgin Çizmeleri I", "Gölge Çizmeleri II"]
	var ring_names := ["Yüzük yok", "Koruyucu Rün Yüzüğü I", "Ejder Rünü Yüzüğü II"]
	var speed := 5.0
	var damage := 34.0
	if is_instance_valid(player_unit):
		speed = player_unit.move_speed
		damage = player_unit.attack_damage
	return {
		"armor_name": armor_names[clampi(armor_level, 0, armor_names.size() - 1)],
		"boots_name": boot_names[clampi(boots_level, 0, boot_names.size() - 1)],
		"ring_name": ring_names[clampi(ring_level, 0, ring_names.size() - 1)],
		"armor_level": armor_level,
		"boots_level": boots_level,
		"ring_level": ring_level,
		"weapon_level": weapon_level,
		"weapon_name": get_weapon_display_name(),
		"weapon_type": weapon_type,
		"damage_reduction_percent": roundi((1.0 - get_player_damage_multiplier()) * 100.0),
		"move_speed": speed,
		"attack_damage": damage
	}

func _refresh_player_gear_visuals() -> void:
	if is_instance_valid(player_unit) and player_unit.has_method("refresh_gear_visuals"):
		player_unit.refresh_gear_visuals()

func _refresh_progress_panels() -> void:
	if not is_instance_valid(hud):
		return
	hud.refresh_inventory(inventory, gold, weapon_level, armor_level, boots_level, ring_level)
	hud.refresh_crafting(_get_crafting_options())
	hud.refresh_equipment(_get_equipment_summary())

func _on_modal_open_changed(is_open: bool) -> void:
	get_tree().paused = is_open

func _on_save_pressed() -> void:
	save_game(true)

func _on_load_pressed() -> void:
	var path := _slot_save_path(active_save_slot)
	var has_legacy := active_save_slot == 1 and not FileAccess.file_exists(path) and FileAccess.file_exists(LEGACY_SAVE_PATH)
	if not FileAccess.file_exists(path) and not has_legacy:
		show_notice("Yuva %d boş. YUVALAR menüsünden başka kayıt seç veya yeni yolculuk başlat." % active_save_slot)
		return
	get_tree().paused = false
	get_tree().reload_current_scene()

func _on_inventory_pressed() -> void:
	if is_instance_valid(hud):
		hud.toggle_inventory(inventory, gold, weapon_level, armor_level, boots_level, ring_level)

func _on_potion_pressed() -> void:
	use_healing_potion()

func _on_save_slots_pressed() -> void:
	selected_save_slot = active_save_slot
	if is_instance_valid(hud):
		hud.toggle_save_slots(_get_save_slot_summaries(), selected_save_slot)

func _on_save_slot_selected(slot_id: int) -> void:
	selected_save_slot = clampi(slot_id, 1, SAVE_SLOT_COUNT)
	if is_instance_valid(hud):
		hud.refresh_save_slots(_get_save_slot_summaries(), selected_save_slot)

func _on_save_slot_save_pressed() -> void:
	active_save_slot = clampi(selected_save_slot, 1, SAVE_SLOT_COUNT)
	_write_active_slot()
	save_game(true)

func _on_save_slot_load_pressed() -> void:
	active_save_slot = clampi(selected_save_slot, 1, SAVE_SLOT_COUNT)
	var path := _slot_save_path(active_save_slot)
	var has_legacy := active_save_slot == 1 and not FileAccess.file_exists(path) and FileAccess.file_exists(LEGACY_SAVE_PATH)
	if not FileAccess.file_exists(path) and not has_legacy:
		_write_active_slot()
		show_notice("Yuva %d boş. Yeni bir yolculuk başlatılıyor." % active_save_slot)
	else:
		_write_active_slot()
	get_tree().paused = false
	get_tree().reload_current_scene()

func _on_crafting_pressed() -> void:
	if is_instance_valid(hud):
		hud.toggle_crafting(_get_crafting_options())

func _on_equipment_pressed() -> void:
	if is_instance_valid(hud):
		hud.toggle_equipment(_get_equipment_summary())

func _on_army_panel_pressed() -> void:
	if is_instance_valid(hud):
		hud.toggle_army_panel(_get_army_summary())

func _on_army_order_pressed(order_id: String) -> void:
	_issue_army_order(order_id)

func _on_army_formation_pressed(formation_id: String) -> void:
	_set_army_formation(formation_id)

func _on_army_recruit_pressed(class_id: String) -> void:
	_recruit_troop(class_id)

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_CLOSE_REQUEST or what == NOTIFICATION_APPLICATION_PAUSED:
		if is_instance_valid(player_unit):
			save_game(false)

func _on_restart_pressed() -> void:
	# A game-over restart resets only the currently active save slot.
	var active_path := _slot_save_path(active_save_slot)
	if FileAccess.file_exists(active_path):
		DirAccess.remove_absolute(ProjectSettings.globalize_path(active_path))
	if active_save_slot == 1 and FileAccess.file_exists(LEGACY_SAVE_PATH):
		DirAccess.remove_absolute(ProjectSettings.globalize_path(LEGACY_SAVE_PATH))
	get_tree().paused = false
	get_tree().reload_current_scene()
