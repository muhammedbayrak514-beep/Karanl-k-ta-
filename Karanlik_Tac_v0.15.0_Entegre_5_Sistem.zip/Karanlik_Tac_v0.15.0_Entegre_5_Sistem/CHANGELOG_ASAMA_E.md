# Aşama E — Hikâye, Görevler, Yoldaşlar ve Karakter Gelişimi

## v0.13.0 değişiklikleri

- Veri odaklı görev defteri eklendi: 4 ana hikâye görevi ve 8 yan görev.
- Görev ilerlemesi yaratık avı, haydut yenme, sandık açma, kadim kalıntı bulma, farklı bölgelere girme ve kale fethetme olaylarından beslenir.
- Ana hikâye görevleri sırayla açılır; hazır görevler ilgili NPC'ye dönülerek teslim edilir.
- Darian, Runa, Taren ve Selka adlı dört yoldaş dünyaya eklendi; etkileşimle ücret karşılığında gruba alınabilir.
- Yoldaşlar orduya gerçek müttefik birim olarak katılır ve kayıt dosyasında kimlikleri korunur.
- Darian hasar azaltma, Runa zamanlı iyileştirme, Taren hareket hızı ve Selka saldırı hasarı pasifi sağlar.
- Seviye atlama başına bir yetenek puanı verilir. Savaş Ustalığı, Liderlik ve Hayatta Kalma üç seviyeye kadar geliştirilebilir.
- Görev, yoldaş ve yetenek ekranları mobil HUD'a bağlandı.
- Liderlik yeteneği ordu kapasitesini 10'dan 16'ya çıkarabilir; her formasyona 16 farklı konum eklendi. Yoldaş panelindeki ordu sayısı artık isimli yoldaşları değil tüm müttefikleri sayar.
- Eski kayıt ilerlemesini yeni ana görevlere aktaran yardımcı eklendi; başlangıç bölgesi keşif görevine yazılır.
- Kayıt formatı v9'a ve Android sürüm kodu 13'e yükseltildi; eski v8 ve daha eski kayıtlar için varsayılanlar korunur.

## Doğrulama sınırı

Bu pakette Python tabanlı yapısal testler bulunur. Godot motoru çalıştırılmadan GDScript parse/oynanış testinin geçtiği ileri sürülmez. Android APK, GitHub Actions'ta gerçek Godot başsız açılış testiyle üretilmelidir.
