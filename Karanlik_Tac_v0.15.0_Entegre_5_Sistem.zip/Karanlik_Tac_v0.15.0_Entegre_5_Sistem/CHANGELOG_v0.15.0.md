# Karanlık Taç: Sınır Savaşı — v0.15.0

## Beş sistem entegrasyonu

### 1. Krallık yapay zekâsı
- Beş krallık ilişkilerini takip eder.
- Kampanya turlarında savaş başlatabilir, barış yapabilir veya ittifak kurabilir.
- Aktif savaşlarda NPC krallıkların kontrol ettiği bölgeler değişebilir.
- Oyuncunun sahip olduğu bölgeler otomatik savaş simülasyonunda ele geçirilmez.
- Savaş, ittifak, ilişki, bölge ve kampanya günü kayıt edilir.

### 2. Üç ayrı kuşatma sahası
- Karanlık Taç Kalesi, Doğu Gözetleme Kalesi ve Karakış Kal'ası ayrı kapı ve fetih durumları tutar.
- Oyuncu sahaya yaklaştığında ilgili kuşatma seçilir.
- İlerlemenin ve kapı dayanıklılığının her sahası ayrı kaydedilir.
- Kapı yaklaşma yerleri 16 birliğe kadar genişletildi.

### 3. Kararlarla dallanan hikâye
- Ana hikâyede iki seçenekli karar penceresi açılır: halkı koruma veya demir taç yolunu seçme.
- Seçim krallık itibarını ve ödülleri değiştirir; son görevde farklı final mesajı gösterilir.
- Hikâye dalı ve karar bayrakları kaydedilir.

### 4. Yoldaş kişisel görevleri ve sadakat
- Darian, Runa, Taren ve Selka için ayrı kişisel görevler.
- Görev hedefleri savaş/keşif olaylarıyla ilerler.
- Görev sonunda seçimler sadakati ve oyun ödüllerini etkiler.
- Sadakat, ilgili yoldaşın pasif yetenek etkisinin gücünü ayarlar.
- Görev ve sadakat durumu kaydedilir.

### 5. Yaşayan dünya
- Açık hava, yağmur, sis ve kar atmosferi değişimleri.
- Hasat şenliği, ticaret hareketliliği, haydut akını ve kayıp sandık gibi süreli olaylar.
- Üç hareketli ve etkileşilebilir kervan rotası.
- Aktif olay, süreler, dünya günü, kervanların rotası/konumu ve kayıp sandık kimliği kaydedilir.

## Doğrulama

Şu komutlar yerel ortamda başarıyla çalıştırıldı:

```bash
python3 tools/validate_project.py
python3 -m unittest discover -s tests -v
```

Sonuç: proje yapısal doğrulaması başarılı ve 34 Python yapısal testi geçti.

**Sınır:** Test ortamında Godot çalıştırıcısı bulunmadığından Godot script parse/startup testi, gerçek oynanış veya APK derlemesi burada çalıştırılmadı. Bunlar `.github/workflows/build-android.yml` üzerinden GitHub Actions'ta doğrulanmalıdır. Python testleri motor testinin yerine geçmez.
