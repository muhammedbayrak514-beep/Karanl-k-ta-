# Karanlık Taç v0.14.0 — Aşama F

- GRAFİK paneli: Düşük, Dengeli ve Yüksek kalite profilleri.
- Android cihazda ayrı config dosyasına saklanan grafik tercihi.
- Gölge mesafesi, fog/glow ve dekor öğelerinin görünürlük mesafeleri kalite seviyesine göre değişir.
- FPS göstergesi ile cihaz platformu bilgisi.
- Android CI: Godot import/parse + 180 kare açılış kontrolü + APK bütünlük testi + tanılama artefaktı.
- Proje sürümü 0.14.0, Android version code 14; save format v9 ile geriye dönük kayıt uyumluluğu korunur.
