#!/usr/bin/env python3
"""Dependency-free structural checks for Karanlık Taç v0.15.0 + Aşamalar A-F."""
from __future__ import annotations
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ERRORS: list[str] = []


def require(condition: bool, message: str) -> None:
    if not condition:
        ERRORS.append(message)


def read(relative: str) -> str:
    path = ROOT / relative
    if not path.is_file():
        ERRORS.append(f"Missing required file: {relative}")
        return ""
    return path.read_text(encoding="utf-8")


def main() -> int:
    project = read("project.godot")
    main_scene = read("scenes/main.tscn")
    game = read("scripts/game.gd")
    hud = read("scripts/hud.gd")
    player = read("scripts/player.gd")
    unit = read("scripts/battle_unit.gd")
    visuals = read("scripts/unit_visuals.gd")
    arrow = read("scripts/arrow_projectile.gd")
    export = read("export_presets.cfg")
    workflow = read(".github/workflows/build-android.yml")
    readme = read("README_TR.md")
    changelog = read("CHANGELOG_v0.8.0.md")
    army_doc = read("docs/ORDU_KOMUTANLIGI_v1.md")
    navigation = read("scripts/world_navigation.gd")
    nav_doc = read("docs/ASTAR_YOL_BULMA_v1.md")
    siege_manager = read("scripts/siege_manager.gd")
    siege_projectile = read("scripts/siege_projectile.gd")
    siege_doc = read("docs/KUSATMA_SISTEMI_v1.md")
    general_doc = read("docs/GENEL_GELISTIRMELER_v0.9.0.md")
    v09_changelog = read("CHANGELOG_v0.9.0.md")
    arena = read("scripts/arena.gd")
    radar = read("scripts/world_radar.gd")
    phase_b_doc = read("docs/ASAMA_B_ACIK_DUNYA.md")
    phase_c_doc = read("docs/ASAMA_C_KRALLIKLAR_ORDULAR.md")
    kingdoms = read("scripts/kingdom_system.gd")

    require('config/version="0.15.0"' in project, "project.godot version must be 0.15.0")
    require('run/main_scene="res://scenes/main.tscn"' in project, "main scene setting is missing or incorrect")
    require('path="res://scripts/game.gd"' in main_scene, "main scene must use scripts/game.gd")
    require('version/name="0.15.0"' in export and "version/code=15" in export,
            "Android export version must match v0.15.0 (code 15)")
    require('platform="Android"' in export and "architectures/arm64-v8a=true" in export,
            "Android ARM64 export preset must be present")

    hud_signals = (
        "save_pressed", "load_pressed", "inventory_pressed", "potion_pressed",
        "save_slots_pressed", "save_slot_selected", "save_slot_save_pressed",
        "save_slot_load_pressed", "crafting_pressed", "equipment_pressed",
        "craft_recipe_pressed", "modal_open_changed", "army_panel_pressed",
        "army_order_pressed", "army_formation_pressed", "army_recruit_pressed",
        "kingdom_panel_pressed", "kingdom_pledge_pressed", "settlement_panel_pressed", "settlement_action_pressed",
    )
    for signal_name in hud_signals:
        require(f"signal {signal_name}" in hud, f"HUD signal missing: {signal_name}")
        require(f"hud.{signal_name}.connect" in game, f"Game signal connection missing: {signal_name}")

    game_methods = (
        "save_game", "_load_save_file", "_load_active_slot", "_write_active_slot",
        "_get_save_slot_summaries", "_slot_save_path", "_get_recipe_data",
        "_get_crafting_options", "craft_recipe", "get_player_damage_multiplier",
        "_get_equipment_summary", "_refresh_progress_panels", "_spawn_ally",
        "_spawn_saved_allies", "_serialize_army", "launch_arrow", "_get_army_summary",
        "_issue_army_order", "_set_army_formation", "_recruit_troop",
        "_get_saved_kingdom_state", "_get_kingdom_summary", "_get_recruitment_cost",
        "_on_kingdom_panel_pressed", "_on_kingdom_pledge_pressed", "_on_settlement_panel_pressed", "_on_settlement_action_pressed",
    )
    for method_name in game_methods:
        require(f"func {method_name}" in game, f"Game method missing: {method_name}")

    require("SAVE_SLOT_COUNT: int = 3" in game, "Three save slots must remain configured")
    require("SAVE_FORMAT_VERSION: int = 10" in game, "Save format must be v10")
    require('"save_format_version": SAVE_FORMAT_VERSION' in game, "Save payload must carry format version")
    require('"game_version": "0.15.0"' in game, "Save payload must identify v0.15.0")
    for saved_key in (
        "position", "max_health", "attack_damage", "gold", "weapon_level", "armor_level",
        "boots_level", "ring_level", "wolf_quest_state", "ruin_quest_state",
        "opened_chests", "defeated_creatures", "army_order", "army_formation", "army",
        "formation_index", "order_position",
    ):
        require(f'"{saved_key}"' in game, f"Save payload or load path is missing: {saved_key}")

    for recipe_id in ("potion_bundle", "armor", "boots", "ring", "sword"):
        require(f'"{recipe_id}"' in game and f'"{recipe_id}"' in hud,
                f"Crafting recipe {recipe_id} must remain connected to gameplay UI")
    require("SAVE_FORMAT_VERSION" in game and "stored_version > SAVE_FORMAT_VERSION" in game,
            "Legacy save-format compatibility guard is missing")
    require("get_player_damage_multiplier" in unit, "Player armour must affect incoming damage")
    require("set_equipment_appearance" in player and "refresh_gear_visuals" in player,
            "Player must refresh visible gear after crafting")
    require("CraftedChestplate" in visuals and "RuneRingGlow" in visuals,
            "Crafted equipment visuals are missing")

    for class_id in ("infantry", "archer", "cavalry", "shield_guard", "crossbowman"):
        require(f'"{class_id}"' in game and f'"{class_id}"' in unit,
                f"Unit class {class_id} must be supported in game and AI code")
        require(f'"{class_id}"' in hud, f"Recruitment UI is missing class {class_id}")
    for order_id in ("follow", "hold", "charge", "retreat"):
        require(f'"{order_id}"' in game and f'"{order_id}"' in unit and f'"{order_id}"' in hud,
                f"Army order {order_id} is not connected across game, unit AI and HUD")
    for formation_id in ("line", "wedge", "column"):
        require(f'"{formation_id}"' in game and f'"{formation_id}"' in unit and f'"{formation_id}"' in hud,
                f"Formation {formation_id} is not connected across game, unit AI and HUD")
    require("MAX_ALLIES: int = 10" in game, "Ten-allied-unit limit is missing")
    require("launch_arrow" in unit and "ArrowScript" in game and "ArrowShaft" in arrow,
            "Archer arrow projectile path is missing")
    require("_steering_direction" in unit and "PhysicsRayQueryParameters3D" in unit,
            "AI obstacle steering is missing")
    require("_get_cached_allied_target" in unit and "_get_cached_hostile_target" in unit,
            "AI target reacquisition cache is missing")
    require("best_score" in game and "role_bias" in game,
            "Threat-aware enemy target selection is missing")
    require("SAVE_FORMAT_VERSION: int = 10" in game and '"game_version": "0.15.0"' in game,
            "current save format/version metadata is not aligned")
    require("AStarGrid2D" in navigation and "func find_path" in navigation,
            "A* navigation grid/path search is missing")
    require("func register_obstacle" in navigation and "grid.set_point_solid" in navigation,
            "Static obstacle registration in the navigation grid is missing")
    require("NavigationScript" in read("scripts/arena.gd") and "get_navigation_path" in read("scripts/arena.gd"),
            "Arena navigation initialization or route API is missing")
    require("_navigation_path" in unit and "get_navigation_path" in unit,
            "Battle units are not consuming A* route waypoints")
    require("_combat_approach_position" in unit,
            "Unique close-combat approach points are missing")
    require("v0.7" in nav_doc and "AStarGrid2D" in nav_doc,
            "A* navigation design documentation is missing")
    require("WarhorseBody" in visuals and "LanceShaft" in visuals,
            "Cavalry mount/lance visual path is missing")
    require('signal siege_command_pressed(command_id: String)' in hud,
            "Siege command signal is missing from the HUD")
    require('hud.siege_command_pressed.connect(_on_siege_command_pressed)' in game,
            "Siege commands are not connected to the game controller")
    for command_id in ("start", "assault", "catapult", "capture"):
        require(f'"{command_id}"' in hud and f'"{command_id}"' in siege_manager,
                f"Siege command {command_id} is not connected between HUD and siege manager")
    require("func apply_gate_damage" in siege_manager and "GATE_MAX_HEALTH" in siege_manager,
            "Destructible gate durability system is missing")
    require("func _fire_catapult" in siege_manager and "ProjectileScript" in siege_manager,
            "Catapult firing logic is missing")
    require("func on_catapult_impact" in siege_manager and "func _process" in siege_projectile,
            "Ballistic catapult impact handling is missing")
    require("func _fire_defensive_towers" in siege_manager and "launch_arrow" in siege_manager,
            "Castle tower defensive fire is missing")
    require("func _update_capture_progress" in siege_manager and "castle_captured = true" in siege_manager,
            "Castle capture progress/completion is missing")
    require("is_unit_assaulting_gate" in unit and "get_gate_approach_position" in unit,
            "Allied unit AI is not connected to gate assault orders")
    require('"gate_health"' in game and '"castle_captured"' in game and '"siege_started"' in game,
            "Siege progress is not preserved by the save system")
    require("_make_siege_engine" in read("scripts/arena.gd"), "Catapult visual is missing from the world")
    require("KUŞATMA" in siege_doc.upper() and "v0.8.0" in siege_doc,
            "Siege design documentation is missing")
    require("get_tree().paused = modal_active" in hud and "or army_open" in hud,
            "Army panel should pause gameplay consistently with other modal panels")
    # v0.9: gear, stamina/parry combat, moving NPC routines, new regions, quest and day-night cycle.
    require("func cycle_weapon_type" in game and "get_weapon_damage_multiplier" in game,
            "Weapon switching/stat profiles are missing")
    for weapon_id in ("sword", "spear", "greatsword", "axe"):
        require(f'"{weapon_id}"' in game and f'"{weapon_id}"' in visuals,
                f"Weapon {weapon_id} is not connected to visuals and combat")
    require("stamina" in player and "parry_window_left" in player and "ZAMANLAMALI SAVUNMA" in player,
            "Stamina and timed parry systems are missing")
    require("weapon_cycle_pressed" in hud and "hud.weapon_cycle_pressed.connect" in game,
            "Mobile weapon-switch UI is not connected")
    require("sprint_changed" in hud and "hud.sprint_changed.connect" in game and "set_mobile_sprint" in player,
            "Touchscreen sprint control is not connected")
    require("_update_daily_routine" in read("scripts/world_npc.gd") and '"scout"' in read("scripts/world_npc.gd"),
            "NPC daily routine/scout role is missing")
    require("_make_v09_landmarks" in read("scripts/arena.gd") and "KIRIK MIZRAK MEYDANI" in read("scripts/arena.gd"),
            "New detailed exploration locations are missing")
    require("DAY_CYCLE_SECONDS" in read("scripts/arena.gd") and "sun_light.light_energy" in read("scripts/arena.gd"),
            "Dynamic day-night lighting is missing")
    require("_spawn_bandit_camp" in game and "bandit_quest_state" in game and "bandit_camp_%02d" in game,
            "Bandit camp quest encounter is missing")
    require("FloatingDamageNumber" in unit and "KRİTİK VURUŞ" in player,
            "Combat feedback/critical hits are missing")
    require("Kadim Kalıntı" in game or "ancient_relic" in game, "Relic treasure reward is missing")
    require("role == \"scout\"" in read("scripts/world_npc.gd") and "QuestMarker" in read("scripts/world_npc.gd"),
            "Scout NPC role and quest marker are missing")
    require("v0.9.0" in general_doc and "gündüz/gece" in general_doc.lower() and "Uzun mızrak" in general_doc,
            "Detailed v0.9 feature report is missing required systems")
    require("v0.9.0" in v09_changelog and "SAVE_FORMAT_VERSION" in game, "v0.9 changelog or save version is missing")
    require('"weapon_type": weapon_type' in game and '"stamina": player_unit.stamina' in game,
            "Weapon and stamina states are not saved")
    require('version/name="0.4.0"' not in export, "Stale Android export version remains")
    require('config/version="0.4.0"' not in project, "Stale project version remains")
    require('config/version="0.7.0"' not in project, "Stale v0.7 project version remains")
    require('version/name="0.7.0"' not in export, "Stale v0.7 Android version remains")
    require("0.9.0" in readme and "v0.9.0" in v09_changelog, "v0.9 documentation missing")
    require("v0.8.0" in changelog, "v0.8 changelog missing")
    require("Army" in army_doc or "Ordu" in army_doc, "Army design document is missing meaningful content")
    require("python3 tools/validate_project.py" in workflow, "Android workflow must run structural checks")
    require("godotengine/godot-builds/releases/download" in workflow, "Android workflow must download official engine binaries from godot-builds")
    require("--quit-after 180" in workflow, "Android workflow must include a longer headless startup smoke test")
    require("godot-import.log" in workflow and "godot-startup.log" in workflow, "Godot import/startup logs must be checked for script/resource errors")
    require("SCRIPT ERROR:" in workflow and "Failed loading resource" in workflow, "Godot runtime error checks are missing from the workflow")
    require("android_debug.apk" in workflow and "version.txt" in workflow, "Android export templates should be installed and checked before export")
    require("Karanlik-Tac-Android-APK" in workflow, "Android workflow artifact step is missing")
    require("ORDU" in hud and "KAYDET" in hud and "YÜKLE" in hud and "YUVALAR" in hud and "ÇANTA" in hud,
            "Main HUD utility controls are missing")
    # Phase B: expanded exploration footprint, routes, biome colours, landmarks and radar.
    require("const WORLD_SIZE := 900.0" in arena and "const GRID_CELLS := 180" in arena,
            "Phase B world must be 900x900 metres while keeping 5m terrain cells")
    require("const DEFAULT_WORLD_SIZE: float = 900.0" in navigation,
            "Navigation default size must match the expanded world")
    require("_make_v10_landmarks()" in arena and "func _make_v10_landmarks()" in arena,
            "Phase B landmark builder is missing or not called")
    for landmark in ("BATI GÖZETLEME KULESİ", "KARAKIŞ MANASTIRI", "KÜL OVASI", "DOĞU SINIR GÖZETİMİ", "BATIK KERVAN DURAĞI"):
        require(landmark in arena and landmark in game,
                f"Phase B landmark needs both visible world label and region name: {landmark}")
    require("for index in range(ROAD_SEGMENTS.size())" in arena and "Vector2(362, -20)" in arena,
            "Phase B roads must render from shared route data and reach the eastern zone")
    require("var map_scale: float = 0.14" in radar and "AÇIK DÜNYA • 900 m" in radar,
            "Expanded world radar scale and destination footer are missing")
    require("900 × 900" in phase_b_doc and "Karakış Manastırı" in phase_b_doc,
            "Phase B world-expansion notes are incomplete")

    # Phase C: five factions, diplomacy persistence, troop types and ten-unit army command.
    require('"north_crown"' in kingdoms and '"aurel_empire"' in kingdoms and '"red_banner"' in kingdoms and '"mountain_clans"' in kingdoms and '"black_seal"' in kingdoms,
            "Phase C needs all five playable-world factions")
    require("func pledge" in kingdoms and "func change_standing" in kingdoms and "func record_hostile_kill" in kingdoms,
            "Phase C diplomacy/reputation actions are missing")
    require("func capture_frontier_castle" in kingdoms and "func get_territory_rows" in kingdoms,
            "Phase C territory ownership system is missing")
    require("KingdomSystemScript" in game and "kingdom_system.to_dict()" in game,
            "Kingdom state must be initialized and saved")
    require('signal kingdom_panel_pressed' in hud and 'signal kingdom_pledge_pressed' in hud and 'func refresh_kingdom_panel' in hud,
            "Diplomacy panel is not connected to the HUD")
    require('"shield_guard"' in game and '"crossbowman"' in game and '"crossbowman"' in unit and 'CrossbowStock' in visuals,
            "Phase C army needs shield-guard and ranged crossbowman classes")
    require("_get_recruitment_cost" in game and "player_oath" in game,
            "Faction oath recruitment bonus is missing")
    require("func is_faction_friendly_to_player" in game and "is_faction_friendly_to_player(str(unit.faction_id))" in game,
            "Sworn-faction combat target filtering is missing")
    require("unit.team == 2" in player and "is_faction_friendly_to_player(str(unit.get(\"faction_id\")))" in player,
            "Player attack must avoid allied troops and sworn-faction units")
    require("is_faction_friendly_to_player(str(faction_id))" in unit,
            "Hostile AI must stop targeting the player when oath makes it friendly")
    require('"kingdoms": kingdom_system.to_dict()' in game,
            "Faction reputation/oath/territory state is not saved")
    require("0.11.0" in phase_c_doc and "Kuzey Tahtı" in phase_c_doc and "ARBAL" in phase_c_doc.upper(),
            "Phase C design documentation is incomplete")

    # Phase D: siege phase clarity, sixteen attack slots, settlement upgrades and persistence.
    settlement = read("scripts/settlement_manager.gd")
    require("func upgrade_building" in settlement and "func recruit_garrison" in settlement and "func collect_taxes" in settlement,
            "Phase D settlement management actions are missing")
    require('"barracks"' in settlement and '"walls"' in settlement and '"market"' in settlement,
            "Phase D needs barracks, fortification and market upgrade tracks")
    require("func get_garrison_capacity" in settlement and "func get_defense_rating" in settlement and "func get_settlement_defense_multiplier" in game and "get_settlement_defense_multiplier(global_position)" in player,
            "Phase D settlement army capacity / defense rating is missing")
    require('"settlement": settlement_manager.to_dict()' in game and "SAVE_FORMAT_VERSION: int = 10" in game,
            "Phase D settlement state must persist in save format v10")
    require("SettlementScript" in game and "settlement_action_pressed.connect" in game and "_on_settlement_action_pressed" in game,
            "Phase D settlement management actions are not wired to the game")
    require('signal settlement_panel_pressed' in hud and "func refresh_settlement_panel" in hud and "func toggle_settlement_panel" in hud,
            "Phase D settlement panel is missing or not wired")
    require("func apply_settlement_visual_state" in arena and "BarracksBody" in arena and "MarketAwning" in arena,
            "Phase D upgrade visuals are missing from the castle")
    require("func get_current_phase_name" in siege_manager and "capture_progress" in siege_manager and '"gate_assault_active": siege_manager.gate_assault_active' in game and "-8.4, -7.28, -6.16, -5.04, -3.92, -2.8, -1.68, -0.56, 0.56, 1.68, 2.8, 3.92, 5.04, 6.16, 7.28, 8.4" in siege_manager,
            "Phase D siege progression, capture persistence or 16 attack positions are missing")
    require('config/version="0.15.0"' in project and 'version/name="0.15.0"' in export and "version/code=15" in export,
            "Current project and Android versions must align to v0.15.0")

    # Check all local res:// paths referenced by Godot text files.
    local_files = list(ROOT.rglob("*.gd")) + list(ROOT.rglob("*.tscn")) + [ROOT / "project.godot", ROOT / "export_presets.cfg"]
    resource_pattern = re.compile(r"res://([^\"'\s)]+)")
    for source in local_files:
        content = source.read_text(encoding="utf-8")
        for match in resource_pattern.finditer(content):
            relative = match.group(1)
            if "::" in relative:
                relative = relative.split("::", 1)[0]
            if not (ROOT / relative).exists():
                ERRORS.append(f"Broken res:// reference in {source.relative_to(ROOT)}: res://{relative}")

    # Phase E: data-driven story quest journal, companions and skill tree.
    quest_system = read("scripts/quest_system.gd")
    require("const QUEST_DEFINITIONS" in quest_system, "Data-driven quest definitions are missing")
    require(quest_system.count('"id":"main_') >= 4, "Four main story chapters must be defined")
    require(quest_system.count('"id":"side_') >= 8, "Eight side quests must be defined")
    for event_name in ("wolf_kill", "bandit_kill", "relic_found", "castle_captured", "region_visit", "chest_opened", "spider_kill", "skeleton_kill", "bog_troll_kill", "drake_kill"):
        require(event_name in quest_system, f"Quest progression event is missing: {event_name}")
    for method_name in ("record_event", "record_region_visit", "claim_next_for_role", "get_journal_text", "to_dict", "seed_progress", "has_active_main_quest_for_role"):
        require(f"func {method_name}" in quest_system, f"Quest manager method missing: {method_name}")
    for role in ("companion_guard", "companion_healer", "companion_scout", "companion_ranger"):
        require(role in game and role in read("scripts/world_npc.gd"), f"Companion role is not wired: {role}")
    for companion_id in ("darian", "runa", "taren", "selka"):
        require(companion_id in game, f"Companion profile is missing: {companion_id}")
    require("companion_id" in unit and "companion_name" in unit, "Companion identities are missing from battle units")
    require('"skill_points": skill_points' in game and '"skill_levels": skill_levels.duplicate(true)' in game, "Skill progress is not saved")
    for skill_id in ("combat", "leadership", "survival"):
        require(skill_id in game and skill_id in hud, f"Skill tree branch missing from game/HUD: {skill_id}")
    for signal_name in ("quest_journal_pressed", "companion_panel_pressed", "skills_panel_pressed", "skill_purchase_pressed"):
        require(f"signal {signal_name}" in hud and f"hud.{signal_name}.connect" in game, f"Phase E HUD signal is not wired: {signal_name}")
    require('"story": quest_system.to_dict()' in game, "Quest journal state is not saved")
    require("get_companion_outgoing_damage_multiplier" in player and "get_companion_incoming_damage_multiplier" in player, "Companion/skill combat passives are missing from player logic")
    require("get_companion_move_multiplier" in player, "Scout companion speed passive is missing from player logic")


    # Phase F: mobile graphics profiles, persistence, diagnostics, Android packaging and QA docs.
    require('signal graphics_panel_pressed' in hud and 'signal graphics_quality_selected(quality_id: String)' in hud,
            "Graphics settings panel is missing or disconnected")
    require('hud.graphics_panel_pressed.connect(_on_graphics_panel_pressed)' in game and 'hud.graphics_quality_selected.connect(_on_graphics_quality_selected)' in game,
            "Graphics settings actions are not wired to the game")
    require('func _load_graphics_quality()' in game and 'func _apply_graphics_quality(' in game and 'GRAPHICS_CONFIG_PATH' in game,
            "Device graphics settings are not persisted")
    require('Engine.max_fps = 30 if graphics_quality == "low"' in game,
            "Graphics profile must configure device frame-rate cap")
    require('func apply_graphics_quality(quality_id: String)' in arena and 'quality_foliage' in arena and 'quality_foliage_cluster' in arena and 'quality_rocks' in arena,
            "World quality profiles must change lighting and decor visibility ranges")
    require('"GRAFİK"' in hud and 'GraphicsPerformanceWindow' in hud and 'Engine.get_frames_per_second()' in hud,
            "Mobile graphics panel must include quality controls and live FPS readout")
    require('config/version="0.15.0"' in project and 'version/name="0.15.0"' in export and 'version/code=15' in export,
            "v0.15.0 project and Android build versions must align")
    require('Verify exported APK' in workflow and 'unzip -t build/KaranlikTac-debug.apk' in workflow,
            "Android workflow must validate the exported APK and collect diagnostics")
    require('PHASE_F' in readme or 'Aşama F' in readme, "Phase F documentation must be present in README")



    # v0.15.0: integrations for diplomacy simulation, three siege sites, branching story,
    # companion personal stories, and persistent living-world simulation.
    kingdoms_script = kingdoms
    quest_system = read("scripts/quest_system.gd")
    world_life = read("scripts/world_life.gd")
    caravan_agent = read("scripts/caravan_agent.gd")
    require("func advance_ai_turn()" in kingdoms_script and "func declare_war(" in kingdoms_script and "func form_alliance(" in kingdoms_script and "func make_peace(" in kingdoms_script, "Autonomous kingdom diplomacy actions are missing")
    require('"frontier_castle"' in siege_manager and '"eastwatch_fort"' in siege_manager and '"frost_hold"' in siege_manager, "Three separate siege sites must be defined")
    require('"GateEastWatch"' in arena and '"GateFrostHold"' in arena and "func set_weather(" in arena, "Additional siege gates/weather rendering are missing")
    require("func show_story_choices(" in hud and "story_choice_pressed" in game and "func set_main_story_branch(" in quest_system, "Branching story choice UI is not connected")
    for companion_story_id in ("darian", "runa", "taren", "selka"):
        require(companion_story_id in quest_system and f'"{companion_story_id}"' in game, f"Personal companion story not connected: {companion_story_id}")
    require('"living_world": world_life.get_save_state()' in game and "func get_save_state()" in world_life, "Living-world state is not saved")
    require("func _create_caravans(" in world_life and "func get_buy_price(" in world_life and "func get_sell_price(" in world_life, "Moving caravans and dynamic trade are missing")
    require("func interact_with_caravan(" in game and 'add_to_group("traveling_caravans")' in caravan_agent, "Caravan interaction is not connected")

    if ERRORS:
        print("PROJECT VALIDATION FAILED")
        for issue in ERRORS:
            print(f" - {issue}")
        return 1

    print("PROJECT VALIDATION PASSED")
    print(" - Main scene and all local res:// references exist")
    print(" - v0.15.0 Android ARM64 export preset is aligned (version code 15)")
    print(" - Save format v10 stores player progress, diplomacy, army state, siege progress, settlements, story quests and skills")
    print(" - Five troop classes, four orders, and three formation options are connected across scripts")
    print(" - AI target scoring, cached reacquisition and collision-ray steering are present")
    print(" - AStarGrid2D pathing, static architecture obstacle marking and unit waypoint caching are present")
    print(" - Archer projectile and cavalry model assets are referenced by the project")
    print(" - Siege gate durability, catapult projectile, tower defence and capture commands are connected")
    print(" - Siege gate health and castle ownership persist through save slots")
    print(" - v0.9 weapons, stamina/parry, day-night cycle, NPC routines, new regions and bandit quest are connected")
    print(" - Phase B expands the world to 900x900m, adds five landmark zones, route connections and matching radar markers")
    print(" - Phase C adds five factions, saved diplomacy, oath-based combat relations, territory capture and five troop classes; Phase E leadership can raise capacity from 10 to 16")
    print(" - Phase D adds save-safe settlement upgrades, garrison, taxes, visual improvements, explicit siege phases, and sixteen gate-attack slots")
    print(" - Phase E adds 12 story/side quests, four recruitable companions, companion passives, three skill branches and save format v10")
    print(" - Phase F adds persisted low/balanced/high graphics, scene decor visibility ranges, FPS display and APK diagnostics")
    print(" - v0.15.0 integrates autonomous kingdom diplomacy, three independent siege sites, branching story, companion personal quests and caravans/weather/world events")

    print(" - Android workflow uses the official Godot builds source, checks export templates, scans import/startup logs, and runs longer headless startup checks before APK export")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
