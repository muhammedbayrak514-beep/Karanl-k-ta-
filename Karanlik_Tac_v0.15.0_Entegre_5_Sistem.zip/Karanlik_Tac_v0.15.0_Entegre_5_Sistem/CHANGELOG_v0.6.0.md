# Karanlık Taç v0.6.0 — Savaş Yapay Zekâsı ve Hareket

## Yeni özellikler
- Birlikler için kısa menzilli fizik ışınlarıyla engel fark etme ve yön değiştirme.
- Yakın müttefiklerden uzaklaşmaya çalışan basit ayrışma davranışı; birliklerin tek noktada yığılmasını azaltır.
- Takip hedefi yenileme aralığı; her karede hedef listesini taramak yerine hedefi kısa aralıklarla günceller.
- Düşman hedef seçiminde mesafe, kalan can ve sınıf tehdidini birleştiren skor.
- Uzun süre ilerleyemeyen birimler için daha geniş yan kaçınma denemesi.
- Android sürüm kodu 6 ve kayıt formatı v4. Önceki kayıt alanları yükleme yolunda korunur; yeni kayıtlar v4 olarak yazılır.

## Bilinen sınırlar
- Bu, tam navmesh/A* yol bulma sistemi değildir. Işın tabanlı yerel kaçınma; karmaşık kale içlerinde veya dar kapılarda her zaman yol bulmayı garanti etmez.
- Animasyonlar hâlâ prototip seviyesindedir. İleri seviye motion-capture veya dış model paketi eklenmemiştir.
- Godot motor testi ve APK üretimi bu geliştirme ortamında çalıştırılmadı; GitHub Actions ile doğrulanmalıdır.

## Doğrulama
`python3 tools/validate_project.py` kaynak yapısı, sürüm ayarları ve AI özelliklerinin varlığını kontrol eder. Bu kontrol Godot'un gerçek script ayrıştırma testinin yerini tutmaz.
