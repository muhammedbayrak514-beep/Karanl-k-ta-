# Karanlık Taç — v0.5.0 Değişiklik Günlüğü

## Ordu komutanlığı ve taktik birlik savaşı

### Birlik emirleri
- Takip et: birlikler komutanın arkasındaki formasyon hedeflerine döner ve sınırlı alanda çatışır.
- Mevzi tut: her asker kendi konumunu savunma çapası olarak kaydeder; yakın tehditlerle savaşır, uzak hedefi peşinden sürüklemez.
- Hücum: birlikler 68 oyun birimine kadar hedef arayıp hedefe doğru ilerler.
- Geri çekil: birlikler saldırmayı bırakır, komutana yönelir ve yakındaki düşmanlardan uzaklaşmaya çalışır.
- Birliğin isim etiketinde sınıfı ve son emir görünür.

### Asker sınıfları ve toplama
- Piyade (25 altın): 110 sağlık, 3.6 hız, yakın dövüşte 18 temel hasar.
- Okçu (35 altın): 78 sağlık, 3.25 hız, 12 birim menzil ve hedefe hareket eden ok mermisi.
- Süvari (50 altın): 132 sağlık, 5.0 hız, 25 temel hasar, mızrak ve kodla oluşturulmuş stilize at modeli.
- Ordu panelinde sınıf sayıları, toplam asker, emir, formasyon ve altın bilgisi gösterilir.
- Altı canlı müttefik üst sınırı korunur. Toplama düğmeleri altın ve birlik kapasitesine göre devre dışı bırakılır.
- Ücretsiz DESTEK/E takviyesi korunur; iki piyadeye kadar çağırır ve 18 saniye bekler.

### Formasyon sistemi
- Hat: geniş cephe ve iki sıra.
- Kama: öne daralan, arkaya genişleyen şekil.
- Sütun: dar yürüyüş düzeni.
- Formasyon komutanın yönüne göre hesaplanır.
- Masaüstü kısayolları: F1 takip, F2 mevzi, F3 hücum, F4 çekil; 1 hat, 2 kama, 3 sütun.

### Kayıt formatı v3
- Kayıt şeması v3'e yükseltildi; v0.4 format v2 ve eski v0.3 legacy kayıtlarını okuma yolu korunur.
- Askerlerin sınıfı, sağlık ve temel değerleri, dünyadaki konumu, emri, formasyon indeksi ve mevzi konumu kaydedilir.
- Genel ordu emri ve formasyonu kalıcıdır.
- Kayıt yüklenirken en fazla altı canlı müttefik geri oluşturulur.

### Proje / Android
- Godot proje sürümü 0.5.0; Android version code 5.
- Yeni `arrow_projectile.gd` ok mermisi görselliği ve hedefe varınca hasar uygulamasını yönetir.
- HUD'da ordu komutanlığı paneli, sınıf toplama butonları, emirler ve formasyonlar bulunur.
- Bağımsız proje doğrulama betiği v0.5 bağlantılarını denetleyecek şekilde güncellendi.
- GitHub Actions Godot parse/startup testleri ve Android APK üretimini sürdürür.

### Bilinen sınırlar
- Godot çalıştırıcısı bu geliştirme ortamında mevcut değil; motor parse/startup veya APK derlemesi yerelde çalıştırılamadı.
- Birim hareketi navmesh/pathfinding kullanmaz. Karmaşık engellerde takılma mümkündür.
- Süvari görseli stilize prosedürel modeldir; gerçek at rig'i ve koşma/saldırı animasyonları sonraki aşamaya bırakıldı.
