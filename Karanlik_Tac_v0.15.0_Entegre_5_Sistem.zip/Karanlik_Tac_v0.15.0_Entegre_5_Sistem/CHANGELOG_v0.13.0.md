# Karanlık Taç v0.13.0 — Tahtın Gölgesi

Aşama E, ana hikâye/yan görevler, özel yoldaşlar ve seviye tabanlı yetenek gelişimi ekler.

- 12 veri odaklı görev; sıralı ana hikâye ve tekrar ödül vermeyen teslim durumları.
- 4 paralı, özel pasif etkili savaş yoldaşı.
- Savaş Ustalığı, Liderlik ve Hayatta Kalma yetenekleri.
- Görev defteri, yoldaş rehberi ve yetenek ağacı ekranları.
- Liderlik yeteneğiyle ordu kapasitesi 10’dan 16’ya çıkabilir; üç formasyon için 16 ayrı konum tanımlandı.
- Ana görevlerin teslim konuşmaları eski yan görev mesajlarıyla çakışmayacak şekilde düzenlendi; başlangıç bölgesi keşfi kaydediliyor.
- Kayıt biçimi v9, Android sürüm kodu 13.

Not: Motor içi doğrulama için Godot Android workflow çalıştırılmalıdır.
