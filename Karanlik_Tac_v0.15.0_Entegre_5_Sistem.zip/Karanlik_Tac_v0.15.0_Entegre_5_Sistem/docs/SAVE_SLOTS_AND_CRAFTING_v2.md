# v0.4 Kayıt, Üretim ve Ekipman Teknik Notları

## Kayıt dosyaları

- `user://karanlik_tac_slot_1.json`
- `user://karanlik_tac_slot_2.json`
- `user://karanlik_tac_slot_3.json`
- `user://karanlik_tac_active_slot.cfg`
- v0.3 geçiş kaynağı: `user://karanlik_tac_save.json`

Yeni kayıt şeması `save_format_version: 2` ve `game_version: 0.4.0` alanlarını kullanır. v0.3 dosyası ilk yuvada bulunursa okunur; yükleme sırasında ekipman alanları sıfır varsayılanıyla doldurulur ve yeni formata yazılır. Eski dosya yeni kaydın başarıyla yazılmasından sonra silinir.

## Üretim tarifleri

| Tarif | Malzemeler | Altın | Sonuç |
|---|---|---:|---|
| Simya: 2 Şifa İksiri | 1 Kurt Postu + 1 Örümcek İpeği | 8 | +2 iksir |
| Deri Zırh I | 3 Kurt Postu + 2 Kemik Parçası | 35 | Zırh seviyesi 1 |
| Takviyeli Zırh II | 4 Kemik Parçası + 2 Bataklık Özü | 80 | Zırh seviyesi 2 |
| Ejderpulları Zırhı III | 3 Ejder Pulu + 2 Kül Özü | 160 | Zırh seviyesi 3 |
| Gezgin Çizmeleri I | 3 Örümcek İpeği + 1 Kurt Postu | 30 | Hareket hızı +0.4 |
| Gölge Çizmeleri II | 4 Örümcek İpeği + 1 Kül Özü | 75 | Hareket hızı +0.4 |
| Koruyucu Rün Yüzüğü I | 2 Kül Özü + 2 Örümcek İpeği | 55 | Gelen hasar azaltma +%4 |
| Ejder Rünü Yüzüğü II | 1 Bataklık Özü + 2 Ejder Pulu | 130 | Gelen hasar azaltma +%4 |
| Çelik Kılıç II | 3 Kemik Parçası + 1 Ejder Pulu | 95 | Saldırı hasarı +11 |
| Kadim Kılıç III | 2 Ejder Pulu + 2 Kül Özü | 160 | Saldırı hasarı +11 |

Zırh seviyesinin her biri gelen hasarı %7 azaltır. Zırh ve yüzük etkileri toplanır; nihai çarpan güvenlik amacıyla 0.5–1.0 aralığına sınırlandırılır. Savunma tuşunun azaltımı bundan sonra uygulanır.

## Kayıt yuvası işlemleri

- **KAYDET:** aktif yuvaya yazar.
- **YÜKLE:** aktif dolu yuvayı yeniden yükler.
- **YUVALAR:** yuvayı seçme, seçili yuvaya kaydetme veya seçili yuvayı yükleme/yeni yolculuk başlatma ekranını açar.
- Yuva seçimi tek başına aktif yuvayı değiştirmez; **YUVA KAYDET** veya **YÜKLE / YENİ OYUN** işlemiyle aktif hâle gelir.

## Test sınırı

`tools/validate_project.py` yalnızca proje yapısı ve bağlantıları üzerinde bağımsız kontroller yapar. Gerçek GDScript derlemesi ve sahne başlatma doğrulaması `.github/workflows/build-android.yml` içindeki Godot adımlarında yapılmalıdır.
