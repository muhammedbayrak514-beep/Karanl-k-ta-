# Aşama F — Grafik, performans ve Android doğrulama planı

## Oyun içi grafik profilleri

| Profil | FPS hedef sınırı | Gölge | Sis | Glow | Dekor görünürlük aralığı |
|---|---:|---|---|---|---|
| Düşük | 30 | Kapalı | Kapalı | Kapalı | Ağaçların %25’i gizli; kalan ağaçlar 125 m, kayaların %25’i gizli; kalan kayalar 175 m, ufuk 340 m |
| Dengeli | 45 | Açık, 68 m | Açık | Kapalı | Ağaç 255 m, kaya 310 m |
| Yüksek | 60 | Açık, 105 m | Açık | Açık | Sınır yok |

Ayar `user://karanlik_tac_graphics.cfg` içinde saklanır; grafik seçimi oyunun ilerleme kaydını veya save format v9'u değiştirmez. FPS sayacı cihaz üzerinde gözlem sağlar; otomatik benchmark veya performans garantisi değildir.

## Android/GitHub Actions kalite kapısı

1. Godot 4.7.2 ve eşleşen Android export templates indirilir ve doğrulanır.
2. `tools/validate_project.py` ve `tests/` altındaki Python testleri çalıştırılır.
3. `godot --headless --editor --path . --quit` ile kaynak/sahne içe aktarma ve script parse testi yapılır.
4. `godot --headless --path . --quit-after 180` ile açılış smoke testi yapılır.
5. Android debug APK dışa aktarılır, dosya varlığı ve ZIP bütünlüğü kontrol edilir.
6. APK artefaktı ve motor günlükleri + sürüm bilgisi + SHA-256 tanılama artefaktı yüklenir.

## Gerçek Android tablet test listesi

- [ ] APK kuruluyor ve ilk açılışta kapanmıyor.
- [ ] Yeni oyun 2 dakika boyunca oynanabiliyor.
- [ ] Düşük/Dengeli/Yüksek profilleri uygulandıktan sonra görsel değişim görülüyor.
- [ ] Ayar uygulama kapatılıp açıldıktan sonra korunuyor.
- [ ] GRAFİK paneli açıkken oyun hareketi duruyor; kapatınca devam ediyor.
- [ ] Joystick, saldırı, savunma, koşma, etkileşim ve kamera dokunmaları çalışıyor.
- [ ] 10 müttefik + düşman dalgası/kuşatma yakınında FPS ve ısınma gözleniyor.
- [ ] Yeni kayıt, yükleme ve eski v0.13.0 kaydı yükleme deneniyor.
- [ ] Ekran görüntüleri düşük ve yüksek profillerde kaydediliyor.

## Bilinen sınırlar

Bu profiller görünür çizim yükünü azaltır ama tüm düğümleri bellekten silmez ve AI simülasyon sıklığını düşürmez. Ölçülmüş cihaz FPS değerleri ve bellek profili olmadan belirli bir FPS garantisi verilmez. Her cihazda gerçek performans testi gereklidir.
