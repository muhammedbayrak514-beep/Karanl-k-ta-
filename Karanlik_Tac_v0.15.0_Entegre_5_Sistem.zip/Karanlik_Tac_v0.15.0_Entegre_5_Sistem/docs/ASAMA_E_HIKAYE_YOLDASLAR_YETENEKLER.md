# Aşama E Teknik Tasarımı

## Görev sistemi
`quest_system.gd` görev tanımlarını ve `locked/active/ready/complete` durumlarını merkezi olarak yönetir. Oyun sistemi olayları (wolf_kill, bandit_kill, spider_kill, skeleton_kill, bog_troll_kill, drake_kill, chest_opened, relic_found, region_visit, castle_captured) yayınlar. Her görev bir hedef NPC rolüne teslim edilir. Ana görevler `main_01`–`main_04` sırasında açılır; yan görevler bağımsız ilerler. Eski kayıtlardaki av, haydut ve kalıntı ilerlemesi ana bölüm açıldığında yeni görev durumuna aktarılır; ana görev hedefleri için eski görev mesajlarıyla çakışma engellenir. İlk ziyaret edilen bölge de keşif listesine yazılır. Farklı bölge görevi ziyaret edilen benzersiz bölge adlarını sayar.

## Yoldaşlar
Dört yoldaş `battle_units` grubu içindeki mevcut müttefik AI'ını kullanır, böylece takip/hücum/mevzi komutları ve formasyonlar desteklenir. Her yoldaşın `companion_id` / `companion_name` alanı ordu kaydında tutulur.

- Darian: %8 alınan hasar azaltma.
- Runa: 24 saniyede bir komutana 12 can iyileştirme.
- Taren: %8 hareket hızı.
- Selka: %10 komutan saldırı hasarı.

Bu pasifler yalnızca ilgili yoldaş hayattaysa aktif sayılır.

## Yetenek ağacı
Her seviye atlamada 1 puan verilir. Her yetenek en fazla 3 seviyedir: Savaş Ustalığı (+%8 saldırı hasarı/seviye), Liderlik (+2 ordu kapasitesi/seviye), Hayatta Kalma (+15 azami can ve %4 hasar azaltma/seviye). Yetenek puanı ve seviyeler kayıt dosyasına yazılır. Liderlik, 10 kişilik temel sınırı 16 kişiye çıkarabildiğinden üç formasyon için de 16 ayrı konum tanımlanmıştır.

## Kayıt uyumluluğu
Kayıt formatı v9'dur. `world.story` alanı görev durumu ve benzersiz ziyaretleri tutar. Önceki kayıtlarda `story` veya `skill_levels` bulunmazsa güvenli varsayılanlar yüklenir. Yoldaş kimlikleri `army` kayıtlarında tutulur; ayrı roster kopyası olmadığından yükleme çift yoldaş üretmez.

## Test sınırı
Python testleri dosya yapısı ve entegrasyon noktalarını doğrular; gerçek GDScript motor derlemesi için workflow'daki Godot import/startup adımları zorunludur.
