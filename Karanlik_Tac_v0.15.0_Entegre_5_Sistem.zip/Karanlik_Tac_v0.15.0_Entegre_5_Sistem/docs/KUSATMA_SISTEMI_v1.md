# Kale Kuşatması v1 — v0.8.0

## Akış

1. Oyuncu kaleye yaklaşır ve HUD'daki **KUŞAT** panelinden kuşatmayı başlatır.
2. **Askerleri kapıya gönder** komutu aktifken müttefik AI, altı ayrı kapı yaklaşma noktasına yönelir. Yakınlaşan askerler düzenli aralıklarla kapıya hasar verir.
3. Oyuncu kapıya yakınken saldırı düğmesiyle kendi hasarını da uygular.
4. Mancınık komutu 25 altın harcayarak taş mermi fırlatır. Mermi sabit hedef noktasına balistik yörüngeyle ilerler; kapıya yeterince yakın düşerse kapıya, aksi hâlde yakın düşmanlara alan hasarı verir. Bekleme süresi 12 saniyedir.
5. Kapı dururken iki savunma kulesi kuşatma alanındaki oyuncu veya dost birliği hedefleyebilir.
6. Kapı sıfır dayanıklılığa ulaşınca görsel kapı kaldırılır ve müttefiklerin otomatik kapı saldırısı durur.
7. Oyuncu **Fetih emri ver** komutunu başlatır. İç avluya girdikten sonra avlunun yakınındaki düşmanlar temizlenmiş olmalı ve oyuncu 10 saniye alanda kalmalıdır.
8. Fetih tamamlandığında kale sahipliği kaydedilir ve kulelerin saldırısı durur.

## Teknik tasarım

- `scripts/siege_manager.gd`: kuşatma durumu, kapı canı, birlik saldırı sayımı, mancınık maliyeti/bekleme süresi, kule savunması ve fetih ilerlemesi.
- `scripts/siege_projectile.gd`: görsel taş mermisi ve basit balistik hareket.
- `scripts/arena.gd`: mancınığın prosedürel görsel modeli.
- `scripts/hud.gd`: KUŞAT paneli, komut düğmeleri ve durum metni.
- `scripts/battle_unit.gd`: kuşatma emri etkin olduğunda birliklerin kapı yaklaşma noktalarına gitmesi.
- `scripts/game.gd`: sistem bağlantıları, oyuncu saldırı geçişi ve kayıt entegrasyonu.

## Kayıt biçimi

Kayıt formatı v5 alanları: `world.gate_health`, `world.siege_started`, `world.castle_captured`. Alanlar yoksa güvenli varsayılanlar kullanılır. Eski kayıtlar yeni şema için dönüştürülmeden yüklenmeye devam eder.

## Sınırlar

Mancınığın isabeti, kuleler ve kapı hasarı oyun kurallarına göre simüle edilir; mermi fizik gövdesiyle gerçek çarpışma yerine belirli uçuş süresi sonunda hedef noktasında etki üretir. Kale kontrolü bu prototipte tek kaleye uygulanır. Kuleleri ayrı ayrı yıkma, kuşatma merdivenleri, kapı animasyonu ve kalıcı krallık haritası sonraki sürümler için bırakılmıştır.
