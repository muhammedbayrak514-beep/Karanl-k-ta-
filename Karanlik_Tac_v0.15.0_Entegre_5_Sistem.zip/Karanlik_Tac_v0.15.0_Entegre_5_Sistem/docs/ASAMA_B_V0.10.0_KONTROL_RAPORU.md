# Karanlık Taç v0.10.0 — Aşama B Kontrol Raporu

## İşlenen değişiklikler

- Açık dünya alanı 720 × 720 m'den 900 × 900 m'ye genişletildi.
- Arazi ızgarası 180 × 180 hücreye ayarlandı; hücre boyutu 5 m olarak kaldı.
- A* navigasyon alanı 900 m dünyaya uyarlandı; navigasyon hücresi 2.5 m olarak korundu.
- Beş yeni keşif yeri eklendi: Batı Gözetleme Kulesi, Karakış Manastırı, Kül Ovası, Doğu Sınır Gözetimi ve Batık Kervan Durağı.
- Ana yollar uzatıldı; arazi düzleştirmesi ve görünür yol üretimi ortak ROAD_SEGMENTS verisini kullanıyor.
- Yeni biyom renkleri, genişletilmiş çevre nesneleri, doğu lagünü ve ufuk sırtları eklendi.
- Mini harita ölçeği ve yeni bölge isimleri ayarlandı.
- Android güncelleme sürüm kodu 9'dan 10'a çıkarıldı; sürüm adı 0.10.0 oldu.
- Kayıt biçimi v6 korundu; yeni kayıt metadata sürümü 0.10.0 olarak yazılır.
- GitHub Actions'a bağımsız Aşama B birim testleri eklendi.

## Yerel doğrulama sonuçları

- `python3 -m py_compile tools/validate_project.py tests/test_phase_b_map.py` — başarılı.
- `python3 tools/validate_project.py` — başarılı.
- `python3 -m unittest discover -s tests -v` — 5 test başarılı.
- Ana yol koordinatlarının ±450 m sınırı içinde olduğu statik olarak kontrol edildi.
- Beş yeni landmarkın sahne oluşturucusunda ve HUD bölge adı kontrolünde yer aldığı doğrulandı.
- Bu testler Godot GDScript parser veya gerçek oynanış çalıştırması değildir.

## Henüz yapılmayan doğrulama

Bu çalışma konteynerinde Godot çalıştırılabilir dosyası kurulu değil ve GitHub indirme sunucusuna doğrudan bağlantı kurulamadı. Bu nedenle Godot içe aktarma, başsız açılış, Android APK dışa aktarma ve gerçek Android cihaz performans testleri burada çalıştırılmadı. GitHub Actions iş akışı bu testleri proje deposuna yüklendiğinde çalıştırmak üzere düzenlenmiştir.

Harita genişlediği için gerçek tablette FPS/bellek ölçümü yapılmadan performansın hedefe ulaştığı iddia edilmemelidir.
