# Aşama B — Açık Dünya Genişletmesi

**Geliştirme sürümü:** Karanlık Taç: Sınır Savaşı v0.10.0 (Aşama B)
**Önceki temel:** v0.9.0  
**Durum:** Kaynak koduna işlendi; statik kontroller çalıştırılabilir. Godot içinde açılış/oynanış testi ve Android cihaz testi henüz yapılmış sayılmaz.

## 1. Harita alanı ve ızgara

- Oynanabilir arazi `720 × 720 m` ölçüsünden `900 × 900 m` ölçüsüne genişletildi.
- Arazi ağı `GRID_CELLS = 180` olarak ayarlandı; her arazi hücresi yaklaşık `5 × 5 m` kalır.
- A* birim navigasyonu 2.5 m hücre adımını korur ve 900 m dünya sınırına göre yapılandırılır.
- Dış sınır duvarları ve ufuk sırtları yeni alanla eşleştirildi; dekor dağılımı yaklaşık ±410 m alana genişletildi.

## 2. Yeni keşif noktaları

| Bölge | Koordinat (X, Z) | Çevre içeriği |
|---|---:|---|
| Batı Gözetleme Kulesi | (-345, 42) | Taş kule, sancak, eski köprü kalıntısı |
| Karakış Manastırı | (-292, -325) | Yıkık revak, taş sunak, mavi rün |
| Kül Ovası | (8, 350) | Yanmış ağaçlar, kararmış taş çemberi, kırık araba |
| Doğu Sınır Gözetimi | (362, -20) | Gözetleme kulesi, yön levhası, iskele |
| Batık Kervan Durağı | (295, 298) | Kırık kervan arabaları, gölgelik, yol taşı |

Bu bölgeler stilize, kodla oluşturulmuş geometri kullanır. Fotogerçekçi harici modeller veya doku paketleri eklenmedi.

## 3. Yollar ve arazi renkleri

- Yol segmentleri tek bir `ROAD_SEGMENTS` listesinde tutulur; arazi yükseklik düzleştirme ve görünür yol üretimi aynı veriyi kullanır. Mini haritadaki çizgiler sadeleştirilmiş görsel eşlemedir ve yeni ana bağlantıları işaretler.
- Ana yollar kale/köy merkezinden batı, kuzeybatı, güney, doğu ve güneydoğu hedeflerine bağlanır.
- Biyom renk listesi beş yeni dış bölgeyi kapsar: koyu çam ormanı, karakış bölgesi, kül arazisi, doğu lagünü/kıyı kuşağı ve kervan arazisi.
- Bitki ve taş üretimi genişletildi; yeni önemli yapılara yakın bölgelerde görsel kalabalığı azaltmak için boş alan bırakılır.

## 4. Mini harita ve bölge bilgisi

- Radar ölçeği `0.17` değerinden `0.14` değerine çekildi; 900 m alanın uç noktaları mini harita sınırları içinde kalır.
- Yeni bölge siluetleri ve yol bağlantıları radar çizimine eklendi.
- Oyuncu yeni bir hedefin yakınındayken HUD bölge adı ilgili yeni konumu gösterir.

## 5. Doğrulama

Aşama B sonrası yürütülen yerel kontroller:

1. `python3 -m py_compile tools/validate_project.py` — kontrol betiğinin Python sözdizimi.
2. `python3 tools/validate_project.py` — proje dosyaları, `res://` referansları, Aşama B harita ölçüsü, beş landmark, yol verisi ve radar bağlantıları.
3. ZIP bütünlüğü kontrolü — teslim paketi üretildiğinde ayrıca uygulanacak.

Bu kontroller Godot GDScript derlemesini **yerine geçmez**. Nihai doğrulama sırası GitHub Actions'ta Godot içe aktarma/başlangıç testi, Android APK dışa aktarma, ardından tablette açılış ve dolaşma testidir.

## 6. Bilinen kapsam sınırları

- Yeni noktalar şu aşamada çoğunlukla çevre/keşif alanlarıdır; her biri için görev, düşman kampı, sandık, iç mekân veya özel diyalog eklenmiş değildir.
- Yolların yakınında dekoratif taşlar ve bitki boşlukları görsel yerleşim sağlar; her dekor nesnesi A* çarpışma engeli olarak kaydedilmez.
- Dünya büyüdükçe daha fazla arazi yüzeyi ve çevre nesnesi üretilir. Bu nedenle düşük donanımlı Android cihazda kare hızı ve bellek ölçümü zorunludur.
- Ekran görüntüleri veya oynanış videosu alınmadı; bu paketin gerçek motor çalıştırması olarak sunulması doğru olmaz.

## 7. Sonraki adım

Aşama B statik kontrolden sonra Godot motor testine alınmalı. Hata yoksa cihazda köyden dış sınırlara kadar şu güzergâhlar denenmeli: Batı Gözetleme Kulesi, Karakış Manastırı, Kül Ovası, Doğu Sınır Gözetimi ve Batık Kervan Durağı. Oyuncu ve askerler yol kenarlarında takılmamalı; mini harita ve bölge adı oyuncu ile birlikte doğru güncellenmelidir.
