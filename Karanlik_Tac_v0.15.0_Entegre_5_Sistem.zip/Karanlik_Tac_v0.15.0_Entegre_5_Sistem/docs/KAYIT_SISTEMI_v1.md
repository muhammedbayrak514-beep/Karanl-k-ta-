# Kayıt Sistemi — Biçim v1

Dosya adı: `user://karanlik_tac_save.json`

Godot `user://` yolu, masaüstünde ve Android'de uygulamanın kullanıcı verisi için ayrılmış dizini ifade eder. Oyun kaydının Android dosya yöneticisinde normal bir dosya olarak görünmesi beklenmemelidir.

## Saklanan alanlar

- `save_format_version`: kayıt şemasının sürümü. İleride alanlar değişirse dönüşüm bu sürüme göre yapılmalıdır.
- `player`: x/y/z dünya konumu, can, azami can, saldırı gücü ve hareket hızı.
- `progress`: altın, XP, seviye, kılıç seviyesi, yenilen düşman sayısı ve kurt/harabe görevlerinin durumları.
- `inventory`: iksirler ve yaratık malzemesi miktarları.
- `world.opened_chests`: adı sabit olan açılmış sandıklar.
- `world.defeated_creatures`: başlangıç konumundan türetilen sabit kimlikli yaratıklar.
- `saved_at` ve `game_version`: hata ayıklama ve kullanıcıya sürüm gösterimi için bilgi alanları.

## Kayıt güvenliği ve gelecek adım

Bu dosya tek kayıt yuvasıdır. v0.3 kaydetme/yükleme temelini sağlar ancak bozuk dosyalar için yedek slot, yazma-sonrası checksum ve kullanıcıya kayıt yuvası seçme özelliği henüz yoktur. Gelecek sürümde kaydı geçici dosyaya yazıp atomik yenileme, eski şema dönüştürme ve birden fazla kayıt yuvası eklenebilir.

Aktif düşmanların/askerlerin tüm geçici sağlık ve konumları saklanmaz. Dünya, sabit yerleşimli yaratıklar ve sandık durumları üzerinden kısmen kalıcıdır.
