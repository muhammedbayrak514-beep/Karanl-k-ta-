# Aşama D Teknik Notları — Kuşatma ve Yerleşim

## Kuşatma akışı

1. Hazırlık: oyuncu kaleye yaklaşır ve kuşatmayı başlatır.
2. Kapı muhasarası: oyuncu kapıya vurur, birlikleri hücum emriyle yaklaşır ve mancınık kullanılabilir.
3. İç avlu/fetih: ana kapı yıkıldıktan sonra savunmacılar temizlenir; oyuncu iç avluda 10 saniye tutulursa kale el değiştirir.

Kapı dayanıklılığı, kuşatma durumu, devam eden kapı saldırısı, fetih girişimi ve fetih ilerlemesi kayıtlıdır. Eski kayıtlarda bu yeni alanlar yoksa güvenli varsayılanlarla başlatılır.

## Yerleşim yönetimi

- **Kışla (0–3):** garnizon kapasitesi 8 + seviye × 4. Yükseltme maliyetleri sırasıyla 220, 380 ve 600 altın.
- **Taş surlar (0–3):** savunma puanını artırır ve sahip olunan kalenin iç avlusunda her seviye %4 hasar azaltır; yükseltme maliyetleri 200, 360 ve 580 altın.
- **Pazar (0–3):** vergi gelirini 20 + seviye × 18 altına çıkarır; yükseltme maliyetleri 180, 320 ve 500 altın.
- **Garnizon:** her muhafız 40 altın; kapasite kışla seviyesine bağlıdır. İlk 10 garnizon muhafızı iç avludayken kişi başı %0,5 hasar azaltma sağlar. Garnizon verisi kalıcıdır.
- **Vergi:** tahsilat başına gelir toplanır ve yeni tahsilat için 180 saniye beklenir.
- **Görsel yükseltmeler:** kışla, pazar ve sur merlonları kale avlusunda seviye ile birlikte görünür. Bu aşamada bunlar görseldir; henüz ayrı bina iç mekânı, NPC işçi simülasyonu veya kuşatma sırasında garnizonun ayrı bir savaş dalgası yoktur.

## Mobil/performance

Görsel yükseltmeler düşük poligonlu `BoxMesh` parçalarıdır; karmaşık shader veya yüksek maliyetli animasyon eklemez. UI, Android yatay ekran hedefinde yeniden kullanılabilir panel düğmeleriyle uygulanmıştır. Küçük ekran ve gerçek cihaz performansı ayrıca test edilmelidir.

## Bu aşamada kapsam dışında

- Bu pakette etkileşimli ve fethedilebilir kuşatma alanı hâlâ Karanlık Taç Kalesi ile sınırlıdır. Üç farklı kale mimarisi ve ayrı bölgelerde kalıcı sahiplik akışı henüz tamamlanmış sayılmaz; bunu ayrıca geliştirmek ve sınamak gerekir.
- Garnizon mevcut aşamada yönetilen bir sayı ve savunma puanıdır; garnizon askerleri ayrı bir canlı AI grubu olarak sahnede oluşturulmaz.

## Doğrulama sınırı

`tools/validate_project.py` kaynak referansları ve kritik bağlantıları doğrular; `tests/test_phase_d_siege_settlement.py` kaynak kodda sözleşme seviyesinde kontroller yapar. Godot motor testi ve APK dışa aktarımı `.github/workflows/build-android.yml` üzerinden yapılmalıdır.
