# v0.6 — Savaş yapay zekâsı

## Hedef seçimi
Birlikler en yakın geçerli düşmanı bulurken mesafeyi, hedefin kalan can oranını ve sınıf önceliğini değerlendirir. Okçular biraz daha yüksek öncelik alır; böylece oyuncu birimleri tehdit oluşturan menzilli düşmanları daha sık seçebilir. Skor sistemi kesin bir taktik simülasyonu değil, yakın hedefler arasında daha çeşitli seçim üretmek için tasarlanmıştır.

## Hareket ve yerel kaçınma
- Birimlerin önünden kısa fizik ışınları gönderilir.
- Yol engelliyse sol ve sağ yönler ayrı ayrı test edilir.
- Birimlerin birbirinin üstüne yığılmasını azaltmak için yakın dost birimlerden uzaklaşma vektörü eklenir.
- İlerleme çok uzun süre az kalırsa daha geniş bir kaçınma dönüşü denenir.

## Performans
Hedef araması her fizik karesinde değil, kısa ve hafif rastgeleleştirilmiş aralıklarla yenilenir. Bu yaklaşım kalabalık savaşlarda tekrarlanan arama maliyetini azaltmayı amaçlar.

## Sonraki adım
v0.7 için gerçek NavigationRegion3D/navmesh veya grid tabanlı A* düşünülmeli; kapı geçişleri, engel çevresinden uzun rota, birim seçimi ve grup taktikleri test senaryolarıyla doğrulanmalıdır.
