# Karanlık Taç v0.11.0 — Aşama C Kontrol Raporu

## Kontrol edilen kapsam

- Beş fraksiyon için lider/açıklama verileri ve başlangıç ilişkileri.
- Oyuncu itibarı, bir kez verilen NPC tanışma itibarı, düşman birim yenme etkisi, yemin/bağlılık değiştirme koşulları.
- Yedi bölgenin sahiplik verisi ve Sınır Kalesi'nin fetihten sonra oyuncu kontrolüne yazılması.
- Krallık paneli, yemin düğmeleri ve kayıt/yükleme bağlantıları.
- Beş asker sınıfı: piyade, okçu, süvari, kalkanlı muhafız ve arbaletçi.
- On müttefik kapasitesi, 10 farklı formasyon konumu, emir ve sınıf bazlı toplama maliyetleri.
- Save format v7 ve Android version code 11 / game version 0.11.0 eşleşmesi.

## Offline kontroller

- `python3 tools/validate_project.py` — geçti.
- `python3 -m unittest discover -s tests -v` — 10 test geçti.
- `res://` kaynak yolları ve ana sahne referansları yapısal olarak kontrol edildi.
- ZIP bütünlüğü paketleme sonrasında ayrıca test edilmelidir.

## Gerçek motor testi durumu

Bu çalışma ortamında Godot çalıştırılabilir dosyası bulunmadığından GDScript parse işlemi, sahnenin Godot içinde açılması, gerçek oynanış, Android APK dışa aktarımı ve tablet performansı burada doğrulanamadı. Bunlar `.github/workflows/build-android.yml` üzerinden GitHub Actions'ta çalıştırılmalıdır. Yeşil Python testleri Godot motor testinin yerine geçmez.

## Bilinen tasarım sınırları

- Fraksiyonlar, itibar ve yemin kaydedilebilir kampanya verileridir. Krallıklar arası büyük ölçekli gerçek zamanlı savaş simülasyonu, dinamik diplomatik AI ve her fraksiyon için ayrı sefer orduları bu aşamanın kapsamına dahil değildir.
- Bölge sahipliği listesi yedi kayıt içerir; şu an fetih ile oyuncuya geçirilen özel bölge Sınır Kalesi'dir.
- Mobil performans, HUD taşmaları, 10 kişilik birlik davranışı, kayıt göçü ve kuşatma sonrası sahiplik gerçek Android cihazında ayrıca sınanmalıdır.
