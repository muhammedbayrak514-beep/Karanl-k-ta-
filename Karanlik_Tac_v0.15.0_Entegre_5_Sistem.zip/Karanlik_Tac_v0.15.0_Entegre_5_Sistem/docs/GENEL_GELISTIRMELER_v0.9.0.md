# v0.9.0 — Genel geliştirmeler teknik raporu

## Sürüm amacı

v0.9.0 tek bir mekanik yerine keşif, savaş, kullanıcı arayüzü ve görev deneyimini aynı güncellemede iyileştirir. Kodla üretilen varlık yaklaşımı korunur; proje harici model indirmeden açılabilsin diye yeni çevre ve silah görselleri mevcut procedural mesh yardımcılarıyla oluşturulur.

## 1. Harita ve atmosfer

Harita yaklaşık 720 × 720 metrelik alanı ve mevcut biyomları korur. Üç yeni bölge farklı görsel kimlik alır:

- **Kara Pençe Haydut Kampı:** çitli giriş, kumaş çadırlar, silah rafı, kırmızı sancak ve kamp ateşi ışığı. Beş sabit haydut bu görev karşılaşmasını oluşturur.
- **Kırık Mızrak Meydanı:** hendek izleri, kırık mızraklar, savaş mezarları ve eski sancak kalıntısı. Alan, çatışma sonrası savaş alanı hissi için tasarlanmıştır.
- **Ayaz Mağarası:** buzlu taş çerçeve, karanlık giriş ve ışık yayan kristaller ile kuzey bölgesinde yeni bir hedef işareti oluşturur.

`arena.gd` içindeki 360 saniyelik döngü yönlü ışığın açısını ve enerjisini, ışık rengini, ortam ışığını ve sis yoğunluğunu değiştirir. Bu görsel bir gündüz/gece döngüsüdür; NPC görevlerinin saatlere göre dallanması anlamına gelmez.

## 2. Silah profilleri

| Silah | Hasar çarpanı | Menzil | Saldırı aralığı | Dayanıklılık tüketimi |
|---|---:|---:|---:|---:|
| Uzun kılıç | 1.00× | 2.25 | 0.78 sn bekleme | 12 |
| Uzun mızrak | 0.88× | 3.05 | 1.03 sn bekleme | 10 |
| Ağır kılıç | 1.32× | 2.55 | 1.12 sn bekleme | 18 |
| Savaş baltası | 1.18× | 2.12 | 0.96 sn bekleme | 14 |

Profiller `game.gd::_weapon_profile()` içinde tanımlanır. `R` kısayolu veya HUD sinyali silah tipini değiştirir; `player.gd` menzili günceller, `unit_visuals.gd` modelde kılıç, mızrak veya balta biçimini gösterir. Silah seviyesi, temel profile ilave yüzde 10'luk adım bonusu uygular. Profil değerleri dengeleme başlangıcıdır; motor içi test ile yeniden ayarlanmalıdır.

## 3. Dayanıklılık ve savunma

Oyuncunun dayanıklılığı 100 puandır. Koşma saniyede 22, aktif savunma saniyede 8,5 puan tüketir; normal dinlenme sırasında saniyede 19, koşu devam ederken saniyede 12 puana kadar yenilenir. Saldırı bedeli seçili silaha göre 10–18 aralığındadır. Yeterli dayanıklılık yoksa saldırı başlatılmaz ve kullanıcıya bildirim gösterilir.

Savunma ilk açıldığında 0,22 saniyelik zamanlama penceresi başlatılır. Bu pencereye denk gelen darbe normal hasarın yüzde 18'i olarak uygulanır; ayrıca 10 dayanıklılık gider. Pencere dışında mevcut blok sistemi normal hasarı azaltır. Bu sistemin gerçek zamanlama hissi, Godot çalıştırıcısı olan cihazda oynanarak değerlendirilmelidir.

Kritik vuruş olasılığı yüzde 10'dan başlar ve yüzük seviyesiyle artar. Kritik hasar 1,65 çarpanı uygular. `battle_unit.gd` her isabet için kısa süreli 3D hasar yazısı üretir; 30 ve üzeri hasar farklı vurguyla gösterilir.

## 4. NPC ve görev akışı

Köylüler, muhafızlar ve izci kendi başlangıç konumlarının birkaç metre çevresinde hedefler seçer ve hedefe yavaşça yürür. Bu bilinçli olarak küçük ve sınırlandırılmış bir rutin; kompleks navigasyon veya tam günlük simülasyon değildir.

İzcibaşı Koral, Kara Pençe bölgesinde yer alır. Görev akışı:

1. Koral ile etkileşime girerek görevi başlat.
2. Kamptaki beş haydudu yen.
3. Koral'a geri dönüp ödülünü al: 180 altın, 240 XP ve bir Haydut Sancağı.

Haydutların sabit dünya kimlikleri yenilmiş düşman kayıtlarına eklenir. Bu sayede yükleme sırasında aynı kamp haydutları yeniden doğmaz. Görev sayacı ve durumu kayıt alanına yazılır. Harabe Hazinesi ile Kum Tapınağı Sandığı açıldığında birer Kadim Kalıntı da verir; bu eşya envanter ve kayıt verisinde tutulur.

## 5. Kayıt, HUD ve önceki mekanikler

Kayıt sürümü v6'dır. Oyuncunun silah tipi/dayanıklılığı ve haydut görev durumu eklenmiştir. Önceki v1–v5 kayıtlarından yeni alanlar yoksa güvenli varsayılanlar kullanılır. HUD dayanıklılığı ve seçili silahı gösterir; mobilde silah geçişi için ayrı düğme vardır.

Aşağıdaki sistemler kaldırılmadı: A* ızgara yol bulma, engel çevresinde asker hareketi, piyade/okçu/süvari, dört ordu emri, üç formasyon, üç kayıt yuvası, üretim/ekipman, sandıklar ve yaratık görevleri, yıkılabilir ana kale kapısı, mancınık, savunma kuleleri ve kale fethi.

## 6. Kontrol ve sınırlar

- Masaüstü: WASD/oklar hareket; Shift koşu; Space saldırı; Q/Ctrl savunma; R silah değiştir; F etkileşim; ordu emirleri F1–F4 ve formasyonlar 1–3.
- Dokunmatik: joystick, saldırı, savunma, etkileşim ve araç çubuğundaki SİLAH düğmesi.
- Görseller stilize procedural mesh kullanır. Silahların profesyonel animasyonları, hareket yakalama, fizik tabanlı kılıç çarpışması, tam günlük NPC takvimi, dinamik krallık ekonomisi ve çevrimiçi çok oyuncu bu sürümde yoktur.
- Yapısal kontroller Godot'un gerçek GDScript derlemesiyle aynı şey değildir. Godot 4.7.2 bulunan ortamda proje içe aktarılmalı, ana sahne açılmalı, yakın dövüş/koşma/savuşturma/quest/kayıt kontrolleri oynanmalı ve sonra Android APK alınmalıdır.
