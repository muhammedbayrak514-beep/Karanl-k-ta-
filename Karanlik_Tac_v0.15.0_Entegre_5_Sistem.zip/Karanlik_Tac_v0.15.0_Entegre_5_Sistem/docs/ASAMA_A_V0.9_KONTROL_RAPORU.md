# Karanlık Taç v0.9 — Aşama A kontrol raporu

**Tarih:** 26 Ekim 2026  
**Çalışmanın amacı:** v0.9 projesini bir sonraki büyük güncellemeden önce sağlamlaştırmak ve Android CI hattındaki doğrulama adımlarını iyileştirmek.

## Bu turda tamamlanan işler

1. Projenin ZIP içeriği açılarak ana sahne, scriptler, export preset ve GitHub Actions dosyası incelendi.
2. `tools/validate_project.py` yapısal doğrulayıcısı çalıştırıldı; geçti.
3. GDScript dosyalarında yinelenen `func` bildirimleri ve dengelenmemiş parantez/köşeli/kaşlı parantezler için ek bir kaynak taraması yapıldı; geçti. Bu, gerçek GDScript derleyicisi değildir.
4. Android iş akışındaki Godot indirme kaynağı `godotengine/godot-builds` olarak düzeltildi.
5. Godot motoru ve Android export template indirmelerine geçici ağ hataları için yeniden deneme eklendi.
6. Dışa aktarmadan önce Godot ikilisi, Android debug şablonu ve `version.txt` dosyasının varlığı denetleniyor.
7. Godot içe aktarma ve başsız açılış çıktıları kontrol edilerek script/kaynak hatalarının CI işini başarısız kılması sağlandı.
8. Başsız açılış testi 10 kareden 180 kareye uzatıldı.
9. Yapısal doğrulayıcı ve README yeni iş akışına göre güncellendi.
10. ZIP arşiv bütünlüğü, çıkarılan proje ve yeniden çalıştırılan yapısal doğrulayıcı test edildi; geçti.
11. GitHub Actions YAML dosyası YAML ayrıştırıcısı ile kontrol edildi; geçti.

## Sonuç tablosu

| Kontrol | Sonuç |
|---|---|
| ZIP bütünlüğü | Geçti |
| Çıkarılan proje için yapısal doğrulayıcı | Geçti |
| `res://` yerel kaynak referansları | Geçti |
| GDScript temel kaynak taraması | Geçti |
| GitHub Actions YAML ayrıştırması | Geçti |
| Godot gerçek script parse testi | Henüz yapılmadı |
| Godot başsız sahne başlangıcı | Henüz yapılmadı |
| Android APK dışa aktarma | Henüz yapılmadı |
| APK'yı gerçek tablette çalıştırma | Henüz yapılmadı |

## Neden motor testi henüz tamamlanmadı?

Bu çalışma ortamında Godot çalıştırıcısı yüklü değil ve dış ağ üzerinden motor ikilisi indirilemedi. Bu nedenle Godot'un kendi script derleyicisi, gerçek sahne başlangıcı ve Android dışa aktarması burada çalıştırılamadı. Düzeltilen GitHub Actions iş akışı bu adımları proje GitHub'a yüklendikten sonra çalıştırmak üzere hazırlandı; başarı sonucu gelmeden APK'nın test edildiği söylenemez.

## Android tablet üzerinden sonraki adım

1. Yukarıdaki düzeltilmiş ZIP'i indir ve çıkar.
2. İçindeki `karanlik_tac_v0.9.0_AstageA` klasörünün **içeriğini** (özellikle `project.godot`, `scripts/`, `scenes/`, `.github/` ve `tools/`) oyunun GitHub deposunun köküne yükle.
3. GitHub deposunda **Actions → Build Android APK → Run workflow** seç.
4. İş başarısızsa ilk kırmızı adımdaki hata ve `Godot import` / `Headless startup` günlükleri incelenmeli.
5. İş başarılıysa `Karanlik-Tac-Android-APK` artifact'ini indir, tablette kur ve hareket, kamera, savaş, kayıt/yükleme ile uzun süreli çalışmayı gerçek cihazda dene.

## Gerçek cihazda test listesi

- [ ] Proje Godot 4.7.2 Standard ile açılıyor.
- [ ] Ana sahne başlangıçta çökmeden yükleniyor.
- [ ] Oyuncu hareketi, kamera ve dokunmatik kontroller çalışıyor.
- [ ] Temel çatışma, düşman davranışları ve görev ilerlemesi çalışıyor.
- [ ] Ordu komutları ve kale kuşatması HUD üzerinden uygulanıyor.
- [ ] Üç kayıt yuvası ayrı ayrı kayıt/yükleme yapıyor.
- [ ] Oyunu kapatıp yeniden açınca ilerleme korunuyor.
- [ ] APK Android tablette kurulup açılıyor.
- [ ] En az 10 dakikalık denemede çökme veya ciddi performans sorunu görülmüyor.
