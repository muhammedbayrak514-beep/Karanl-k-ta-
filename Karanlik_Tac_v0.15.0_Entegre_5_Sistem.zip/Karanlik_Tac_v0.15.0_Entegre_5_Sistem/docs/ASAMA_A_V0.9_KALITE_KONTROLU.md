# Aşama A — v0.9 sağlamlaştırma ve kalite kontrol planı

**Hedef sürüm:** Karanlık Taç: Sınır Savaşı v0.9.0  
**Durum:** Statik dosya denetimi geçti; Godot motor içi testleri bu çalışma ortamında henüz çalıştırılamadı.

## Bu turda yapılan düzeltmeler

1. Android iş akışındaki Godot indirme kaynağı, resmî çalıştırılabilir derlemelerin yayımlandığı `godotengine/godot-builds` sürüm deposuna yönlendirildi.
2. Godot ve Android dışa aktarma şablonlarını indirme adımlarına geçici ağ hatalarında yeniden deneme eklendi.
3. Derleme başlamadan önce Godot ikilisinin, Android debug şablonunun ve `version.txt` dosyasının gerçekten mevcut olduğu kontrol ediliyor.
4. Başsız açılış testi 10 kareden 180 kareye çıkarıldı. Böylece ilk sahnenin yüklenmesinden sonra daha uzun bir başlangıç kontrolü yapılır.
5. Bağımsız yapısal doğrulayıcı, iş akışının bu kontrolleri içerdiğini doğrulayacak şekilde güncellendi.

## Statik kontroller

- `project.godot` ana sahne ayarı ve sürüm bilgisi.
- Ana sahne ve `res://` ile işaret edilen yerel kaynak dosyaları.
- Android ARM64 dışa aktarma profili ve sürüm kodu.
- Oyuncu, savaş birimi, HUD, görev, kayıt, ordu, navigasyon ve kuşatma sistemlerinin dosya/sinyal bağlantıları.
- Kayıt formatı v6 için alan ve geriye uyumluluk kontrolleri.
- Android GitHub Actions iş akışında motor indirme, şablon kontrolü, içe aktarma, açılış testi ve APK yükleme adımları.

## Godot çalıştırılabildiğinde uygulanacak gerçek motor testleri

İşaretlenmemiş kutular henüz test edilmiş sayılmaz. Her testte sonuç, cihaz ve varsa hata günlüğü kaydedilmeli.

- [ ] Godot 4.7.2 Standard ile proje içe aktarılıyor; script parse hatası yok.
- [ ] `scenes/main.tscn` hatasız açılıyor; başlangıçta eksik kaynak veya null erişimi hatası yok.
- [ ] Oyuncu hareketi, kamera ve dokunmatik joystick çalışıyor.
- [ ] Saldırı, savunma, dayanıklılık ve silah değiştirme komutları çalışıyor.
- [ ] Düşmanlar oyuncuyu buluyor, engeller çevresinde ilerliyor ve çatışma sonunda doğru duruma geçiyor.
- [ ] Ok atışı ve kuşatma mermisi çarpışma sonrası doğru şekilde temizleniyor.
- [ ] Birlik komutları ve formasyon değişiklikleri HUD üzerinden uygulanıyor.
- [ ] Kale kapısı dayanıklılığı, kuşatma saldırısı ve kale ele geçirme koşulu çalışıyor.
- [ ] Görev ilerlemesi ve sandık/ganimet durumu beklenen şekilde değişiyor.
- [ ] Üç kayıt yuvasından kayıt alma ve yükleme çalışıyor.
- [ ] Oyundan çıkıp yeniden açınca temel ilerleme korunuyor.
- [ ] Android APK, desteklenen bir tablette kuruluyor ve açılıyor.
- [ ] En az 10 dakika oynanışta çökme, aşırı ısınma veya ciddi performans düşüşü gözlemlenmiyor.

## Test sınırı

Bu paketteki yapısal doğrulama motorun GDScript derleyicisi değildir. Gerçek parse, sahne başlangıcı, oynanış ve APK kurulumu sonuçları ancak Godot başsız testinin GitHub Actions'ta veya editörde çalıştırılması ve APK'nın gerçek Android cihazda denenmesiyle kesinleşir.
