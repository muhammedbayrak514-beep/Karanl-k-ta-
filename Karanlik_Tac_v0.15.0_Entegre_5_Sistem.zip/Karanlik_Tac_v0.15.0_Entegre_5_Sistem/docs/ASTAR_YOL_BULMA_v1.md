# Karanlık Taç v0.7.0 — A* Yol Bulma Teknik Tasarımı v1.0

## Amaç
v0.7'nin amacı, askerlerin her zaman hedefe doğru düz bir çizgide ilerlemesine bağımlılığı azaltmak ve mimari engellerin çevresinde takip edilebilir ara noktalar üretmektir.

## Bileşenler

### `scripts/world_navigation.gd`
- İlk A* sürümü (v0.7) `AStarGrid2D` ile 720 × 720 metre dünyayı 2.5 metre hücrelere bölüyordu. Aşama B ile varsayılan ve aktif alan 900 × 900 metreye genişletildi; hücre adımı 2.5 metre olarak korunur.
- Her hücre, x-z düzleminde bir dünya konumuna karşılık gelir.
- Öklidyen olmayan Octile sezgiseli ve engelli çapraz geçişleri engelleyen diyagonal modu kullanılır.
- `register_obstacle(center, dimensions)` yöntemi, engel çevresine asker boşluğu ekleyerek hücreleri kapatır.
- `find_path(start, destination)` başlangıç ve hedef hücreleri kapalıysa yakındaki erişilebilir hücre araması yapar; ardından A* hücre yolunu dünya koordinatlarına dönüştürür.

### `scripts/arena.gd`
- Dünya oluşturulurken navigasyon ızgarasını başlatır.
- Çarpışmalı kutu ve silindir mimarileri yerleştirilirken aynı engelleri rota ızgarasına kaydeder.
- `get_navigation_path` ve `is_navigation_position_walkable` ile birim AI koduna arayüz sağlar.

### `scripts/battle_unit.gd`
- Her asker rota ara noktalarını önbelleğe alır.
- Yeni hedef önceki hedef noktasından 3 metreden fazla uzaklaşırsa, rota tükenirse veya birim takılı kalırsa rota yeniden hesaplanır.
- Hedef takibinde doğrudan hedefe yürümek yerine rota ara noktasına yönelir.
- v0.6'daki kısa mesafeli fizik ışınları, A* ara noktalarının etrafındaki yerel engel davranışını korur.
- Yakın dövüş birlikleri hedefin çevresindeki farklı yaklaşma noktalarına yönelerek aynı koordinatta toplanma eğilimini azaltır.

## Performans notları
- 2.5 metre hücre boyutu yaklaşık 288 × 288, yani 82.944 hücre oluşturur. Bu, 5 metre hücrelerden daha dar açıklıklara izin verir fakat rota aramasını daha maliyetli kılar.
- Rota her fizik karesinde hesaplanmaz. Hedef hareketi eşiği ve yeniden hesaplama aralığı, maliyeti kontrol altında tutmak içindir.
- Canlı birlik sayısı ciddi biçimde artarsa rota planlayıcıyı ortak rota önbelleği veya iş dilimleme ile geliştirmek gerekir.

## Bilinen sınırlamalar
- Yalnızca `_add_box(..., collision=true)` ve `_add_cylinder(..., collision=true)` mimarileri grid engeli olarak işaretlenir. Görsel ağaçlar, dekoratif taşlar ve dinamik cisimler otomatik kaydedilmez.
- Bu sistem Godot NavigationServer3D tabanlı navmesh değildir. Eğim yüksekliği rota maliyetine dahil edilmez; yol planı x-z düzlemindedir.
- Ulaşılamayan bir rota için eski doğrudan hareket davranışı korunmuştur. Bu nedenle tamamen kapanmış veya yanlış işaretlenmiş alanlarda yol garantisi verilmez.
- Gerçek motorla çarpışma, performans ve Android cihaz testi yapılmadan performans hedefi sağlandı iddiası yoktur.

## Sonraki geliştirme adımları
1. Gerçek Godot headless ve Android cihaz testleri.
2. Kapıların açılıp kapanmasına göre dinamik engel güncellemesi.
3. Kuşatma kapısı sağlık sistemi, kuşatma silahları ve askerlerin kapıya saldırma emri.
4. Birlikler için dar geçitlerde tek sıra geçişi ve otomatik yeniden formasyon.


## v0.8.0 ek notu

Kale ana kapısı A* engel listesine kaydedilir. Kapı yıkıldığında `unregister_obstacle` ilgili engeli listeden çıkarır ve kalan statik mimari engelleri yeniden boyayarak grid yapısını kurar. Böylece kapı açıldıktan sonra askerler aynı kapı hücrelerini kullanabilir.
