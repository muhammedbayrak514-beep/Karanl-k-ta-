# Aşama C — Krallıklar ve Ordular (v0.11.0)

## Amaç

Aşama C, açık dünyadaki grupları kaydedilebilir bir diplomasi/itibar sistemine bağlar ve oyuncunun ordusunu beş sınıfa, on askerlik sınıra taşır. Bu, tam simülasyonlu bir strateji kampanyası değil; mobil cihazda yönetilebilir, veri odaklı ilk kampanya katmanıdır.

## Krallıklar

| ID | Ad | Lider | Tasarım rolü |
|---|---|---|---|
| `north_crown` | Kuzey Tahtı | Kraliçe Elira | Savunma ve kalkanlı muhafızlar |
| `aurel_empire` | Aurel İmparatorluğu | İmparator Cassian | Ticaret ve arbaletçiler |
| `red_banner` | Kızıl Sancak Boyları | Başbuğ Orhan | Süvari ve sınır akınları |
| `mountain_clans` | Dağ Klanları | Ana Reis Yelda | Dayanıklı piyade ve okçular |
| `black_seal` | Kara Mühür Birliği | Mühür Efendisi | Paralı askerler ve düşmanca sınır baskınları |

## İtibar ve yemin

- Her grup için oyuncu itibarı `-100` ile `+100` arasında saklanır.
- `-50` ve altı düşman, `-20` ve altı gergin, `+20` dostça, `+50` müttefik tutumu olarak gösterilir.
- NPC ile ilk kez konuşmak ilgili grupta `+2` itibar sağlar; NPC adı kayıt altına alındığı için aynı kişiyi tekrar tekrar konuşarak itibar kasılamaz.
- Düşman askeri yenmek ait olduğu grupta `-3` itibar; o gruba düşman olan gruplarda uygun olduğunda `+1` itibar sağlar. Haydut alt grubu Kara Mühür ile ilişkilendirilir.
- Oyuncu ilk kez bir gruba yemin edebilir. Başka gruba geçebilmek için hedef grupla en az `+40` itibar gerekir; geçiş eski bağlılıkta `-25`, yenisinde `+10` itibar değişimi yaratır.
- Yeminli olduğun fraksiyonun savaşçıları seni hedef almaz; ordun da bu fraksiyonla savaşmaz. Haydutlar ayrı bir hedef olarak kalır.
- `KRALLIK` panelinden liderler, açıklamalar, itibar, tutum, yemin ve bölge sahipliği görülebilir.

## Bağlılığa göre ticaret ve asker alımı

- `+20` itibardan itibaren ilişkili NPC hizmetleri %15 indirimlidir.
- `-20` ve altındaki itibarda hizmet fiyatları %25 artar.
- `-50` ve altındaki itibarda tüccar, demirci ve otacı hizmet sunmaz.
- Kuzey Tahtı kalkanlı muhafızda, Aurel arbaletçide, Kızıl Sancak süvaride, Dağ Klanları piyade/okçuda indirim sağlar. Kara Mühür asker alımında küçük genel indirim verir.

## Ordu

- Müttefik asker üst sınırı 6'dan 10'a çıkarıldı.
- `infantry`, `archer`, `cavalry` sınıfları korundu.
- `shield_guard`: daha fazla cana, daha düşük hıza ve büyütülmüş kalkana sahip yakın dövüş birliği.
- `crossbowman`: daha uzun menzilli, daha yüksek hasarlı ve daha yavaş atış aralıklı uzak saldırı birliği; ayrı arbalet görseli kullanır ve mermi sistemiyle saldırır.
- Komutlar ve hat/kama/sütun formasyonları yeni sınıflarla da çalışır.
- Yeminli grubun özel sınıflarında indirim uygulanır; HUD gerçek indirimli maliyeti gösterir ve altın yetmezse alım düğmesini kapatır.

## Toprak ve kayıt

- Yedi bölgenin sahipliği veri olarak saklanır: Yeldeğirmeni Köyü, Batı Gözetleme Kulesi, Karakış Manastırı, Kül Ovası, Doğu Sınır Gözetimi, Batık Kervan Durağı ve Sınır Kalesi.
- Kuşatma sonucu Sınır Kalesi ele geçirildiğinde sahibi `player` olur ve diplomasi paneli/otomatik kayıt bunun durumunu saklar.
- Kayıt biçimi `v7` oldu. Yeni `world.kingdoms` alanı yemin, itibar, NPC karşılaşmaları, bölge sahipliği ve değişen grup ilişkilerini saklar.
- Önceki v1-v6 kayıtlarında alan eksikse varsayılan krallık durumu oluşturulur. Mevcut oyun kayıtlarının cihazda ayrıca sınanması gerekir.

## Kontrol sınırları

Python testleri dosya/bağlantı kontrolleridir; Godot GDScript derleyicisinin yerine geçmez. Kabul testleri: Godot 4.7.2 headless import ve açılış, KRALLIK paneli aç/kapat, ilk NPC konuşmasında itibar, aynı NPC'de ikinci görüşmede itibarın değişmemesi, yemin, indirimli alım, beş sınıfın savaş davranışı, kuşatma fethi sonrası kalenin kayıt/yükleme ile korunması ve Android tablette uzun çatışma performansı.
