# v0.5.0 — Ordu Komutanlığı Tasarımı

## Amaç
Karanlık Taç'a Warband hissi veren küçük ölçekli gerçek zamanlı birlik yönetimi eklemek. v0.5, oyuncunun altı askere kadar müttefik birliğini tek bir komutan panelinden yönetmesini sağlar.

## Birlik sınıfları

| Sınıf | Can | Hız | Hasar | Menzil | Maliyet |
|---|---:|---:|---:|---:|---:|
| Piyade | 110 | 3.6 | 18 + seviye katkısı | 1.9 | 25 altın |
| Okçu | 78 | 3.25 | 14 + seviye katkısı | 12.0 | 35 altın |
| Süvari | 132 | 5.0 | 25 + seviye katkısı | 2.25 | 50 altın |

Piyade dengeli yakın dövüş birimidir. Okçu, hedefe yönelen bir ok mermisi üretir; ok hedefe ulaştığında hasar uygulanır. Süvari daha hızlı, dayanıklı ve güçlüdür, ancak daha pahalıdır.

## Emirler
- `follow`: komutanın arkasında formasyon konumuna ilerler; yakın çatışmaya katılır, uzak hedefi sonsuza kadar takip etmez.
- `hold`: emrin verildiği her askerin mevcut konumu `order_position` olarak saklanır. Yakın tehditlerle çatışır ve kendi mevzi çapası çevresine döner.
- `charge`: daha geniş bir yarıçapta düşman arar ve menzile giren düşmana yaklaşır.
- `retreat`: hedefe saldırmaz; komutana dönmeye, düşmandan yeterince yakınsa uzaklaşmaya çalışır.

## Formasyonlar
Formasyon hedefleri komutanın `global_basis.x` (sağ) ve `global_basis.z` (arka) yönlerinden hesaplanır.
- `line`: üç sütun ve iki sıra.
- `wedge`: sıralar ilerledikçe yatay aralık büyür.
- `column`: dönüşümlü sağ/sol iki dar sütun.

## Kayıt şeması v3
Kök JSON alanları: `save_format_version`, `game_version`, `player`, `progress`, `inventory`, `world`, `army_order`, `army_formation`, `army`.
Her ordu kaydı `class`, `health`, `max_health`, `move_speed`, `attack_damage`, `attack_range`, `order`, `formation_index`, `position` ve `order_position` alanlarını taşır.
Kayıt açılırken sınıf kimliği beyaz listeyle doğrulanır, en fazla altı birlik oluşturulur. v0.4 şema v2 ve daha eski kayıtlar için varsayılan ordu boş olarak değerlendirilir.

## Sınırlar ve sonraki teknik adımlar
- Yakın hedef arama doğrudan yapılır; NavigationServer3D/NavMesh tabanlı yol bulma henüz yoktur.
- Hold çapaları asker başınadır; grup merkezli savunma ve otomatik yeniden formasyon sonraki iyileştirmedir.
- Ok mermileri hedefe uzaklık kontrolüyle hasar verir; fizik çarpışması, siper bloklama ve balistik düşüş yoktur.
- Süvari için prosedürel model vardır fakat iskelet rig'i, biniş animasyonu, hızlanma/çarpma hareketi yoktur.
- Gelecek sürüm: asker seviyeleri/tecrübesi, birlik seçimi, ayrı müfreze grupları, okçu cephanesi, kalkan ve moral sistemi.
