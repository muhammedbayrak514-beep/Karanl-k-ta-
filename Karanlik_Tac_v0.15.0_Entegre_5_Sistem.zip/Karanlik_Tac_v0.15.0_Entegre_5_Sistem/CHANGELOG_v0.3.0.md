# Karanlık Taç — Değişiklik Günlüğü

## v0.3.0 — Sağlam temel ve kayıtlı yolculuk

### Eklendi
- `user://karanlik_tac_save.json` üzerinde sürümlenmiş JSON kayıt sistemi.
- Oyuncu konumu, mevcut/azami canı, saldırı gücü ve hareket hızının kaydı.
- Altın, XP, seviye, kılıç seviyesi, yenilen düşman sayısı ve iki görev zincirinin durumunun kaydı.
- Açılmış sandıklar ve yenilmiş yaratıklar için kararlı kimlikler; yükleme sırasında tekrar doğmalarını önleme.
- Otomatik kayıt (60 saniyede bir), uygulama kapanırken/duraklatılırken kayıt ve manuel KAYDET/YÜKLE kontrolleri.
- Çanta arayüzü; şifa iksiri, kurt postu, kemik parçası, örümcek ipeği, bataklık özü, kül özü ve ejder pulu sayacı.
- Şifa iksirinin eksik canı 85 puana kadar geri getirmesi.
- Yaratık yenildiğinde türüne uygun malzeme ganimeti.
- Android dışa aktarma sürümünün 0.3.0 / version code 3 olarak güncellenmesi.
- Kaynak referanslarını ve v0.3 bağlantılarını kontrol eden bağımlılıksız Python yapısal doğrulaması.
- GitHub Actions içinde Godot kaynak içe aktarma/parse ve başsız açılış kontrolü.

### Notlar ve sınırlar
- Kayıt, telefonun Godot uygulama kullanıcı alanında tutulur; uygulama verileri temizlenirse veya uygulama kaldırılırsa silinebilir.
- Kayıt dünya görev ilerlemesini, sandıkları ve statik yerleşimli yaratıkları saklar. Aktif NPC/askerlerin anlık konumları, düşman yapay zekâsının geçici durumları ve animasyonlar bu sürümde saklanmaz.
- Bu ortamda Godot çalıştırıcısı bulunmadığından gerçek motor parse/oyun açılışı ve APK üretimi yerel olarak doğrulanamadı. GitHub Actions için doğrulama adımları eklendi.
