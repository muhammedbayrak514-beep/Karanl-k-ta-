# Karanlık Taç: Sınır Savaşı — v0.8.0

## Kale kuşatması

- HUD'a KUŞAT paneli ve dört komut eklendi: kuşatmayı başlat, askerleri kapıya gönder, mancınık ateşle ve fetih emri ver.
- Kale kapısına dayanıklılık (900 HP) ve gerçek çarpışma eklendi; kapı yıkılınca çarpışma kaldırılır, A* engel ızgarası yeniden hesaplanır. Komutan yakından saldırabilir; birlikler kapı yaklaşma noktalarına giderek birlikte hasar verir.
- Mancınık için görsel model ve balistik taş mermisi eklendi. Atış 25 altın harcar, 12 saniye bekleme süresi uygular ve kapıya/çevredeki düşmanlara hasar verir.
- Kuşatma boyunca savunma kuleleri kapı çevresindeki komutan ve müttefiklere ok atar.
- Ana kapı yıkıldıktan sonra iç avluya girip savunmacıları temizleyerek, 10 saniyelik kontrol süreciyle kaleyi fethetme sistemi eklendi.
- Kapı dayanıklılığı, kuşatmanın başlatılması ve kale mülkiyeti kayıt dosyasına eklendi.
- Kayıt biçimi v5'e, oyun sürümü 0.8.0'a ve Android sürüm kodu 8'e yükseltildi. v1–v4 kayıtları yüklenebilir.
- `tools/validate_project.py` kuşatma bağlantıları ve sürüm ayarları için güncellendi.

## Doğrulama

- Yapısal test ve kaynak referansı denetimi çalıştırılmalıdır.
- Godot motor içi ayrıştırma, başlatma, gerçek oynanış ve APK export testi mevcut ortamda Godot çalıştırıcısı olmadığı için doğrulanmamıştır; Android GitHub Actions iş akışı bu kontrolleri yürütmek üzere korunmuştur.
