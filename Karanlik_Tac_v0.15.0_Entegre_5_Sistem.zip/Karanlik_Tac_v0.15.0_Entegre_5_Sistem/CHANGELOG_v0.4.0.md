# Karanlık Taç — Değişiklik Günlüğü

## v0.4.0 — Üretim, ekipman ve çoklu kayıt

### Üretim tezgâhı
- Simya tarifinden 2 şifa iksiri üretme.
- Üç kademeli zırh: Deri Zırh I, Takviyeli Zırh II, Ejderpulları Zırhı III.
- İki kademeli hareket çizmeleri.
- İki kademeli koruyucu rün yüzüğü.
- İki yükseltme ile Çelik Kılıç II ve Kadim Kılıç III üretimi.
- Her tarif altın ve gösterilen malzemeleri tüketir; kaynak eksiye düşürülemez.
- Tarif düğmeleri gereken malzeme/altın yetersizse pasif olur; en üst seviyedeki tarifler yeniden üretilemez.

### Ekipman etkileri ve görsellik
- Zırh her seviyede gelen hasarı %7, rün yüzüğü her seviyede %4 azaltır.
- Çizmeler üretildiğinde oyuncu hareket hızı her seviyede 0.4 artar.
- Kılıç üretimi saldırı hasarını +11 artırır.
- Zırh göğüslüğü ve omuzlukları, çizme detayları ve rün yüzüğü parıltısı oyuncu modelinde görünür.
- Çanta ve ekipman ekranları ekipman seviyelerini ve aktif istatistikleri gösterir.

### Üç kayıt yuvası
- Yuva 1, Yuva 2 ve Yuva 3 birbirinden bağımsız JSON dosyaları kullanır.
- Kayıt seçici; boş yuvaları, seviye/altın/kılıç/zırh özetini ve geçersiz kayıt durumunu gösterir.
- Aktif yuva ayrı bir küçük kullanıcı ayar dosyasında saklanır.
- Boş bir yuvayı yüklemek yeni yolculuk başlatır; dolu yuva mevcut ilerlemeyi yükler.
- v0.3 tek kayıt dosyası ilk yuva için otomatik algılanır ve yeni sürümlü kayıt formatına taşınır.
- Kayıt formatı sürüm 2; karakter istatistikleri, ekipman, envanter, görevler, sandıklar ve sabit yaratık yenilgileri saklanır.
- Oyun sonu yeniden başlatma yalnızca aktif yuvayı sıfırlar.

### Proje / derleme
- Godot proje sürümü 0.4.0, Android version code 4 olarak güncellendi.
- Bağımsız proje kontrol aracı; üç kayıt yuvası, tarifler, ekipman, hasar azaltımı ve görünür ekipman bağlantılarını denetler.
- GitHub Actions, yapısal doğrulamayı, Godot kaynak içe aktarma/parse kontrolünü, başsız açılış testini ve Android debug APK dışa aktarımını çalıştırmak üzere yapılandırıldı.

### Bilinen sınırlar
- Yerel ortamda Godot çalıştırıcısı bulunmadığından bu paket için gerçek motor parse/oyun açılışı ve APK derlemesi yerelde yürütülemedi. GitHub Actions çıktısı gelmeden bu sürümü motor testinden geçmiş kabul etmeyin.
- Kayıtlar uygulamanın `user://` alanında tutulur. Uygulama verilerini temizlemek veya uygulamayı kaldırmak bu dosyaları silebilir.
- NPC/askerlerin canlı pozisyonları ve geçici yapay zekâ durumları hâlâ kaydedilmiyor.
