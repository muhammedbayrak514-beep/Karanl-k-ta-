# Aşama C — Krallıklar ve Ordular

## Eklenenler
- `scripts/kingdom_system.gd`: beş grup, karşılıklı ilişkiler, oyuncu itibarı, yemin sistemi, NPC karşılaşmalarının tek seferlik ödülü ve bölge sahipliği.
- HUD'da `KRALLIK` düğmesi ve diplomasi/bölge kontrolü paneli. Yemin edilen fraksiyonun savaşçıları oyuncuyu hedeflemez; müttefikler bu fraksiyona saldırmaz.
- Faction state'i kayıt biçimi v7 altında `world.kingdoms` alanına kaydedilir; eski kayıtlar varsayılan durumla yüklenir.
- Kılıçla çarpışan temel sınıfların yanında kalkanlı muhafız ve arbaletçi eklendi.
- Müttefik birim kapasitesi 6'dan 10'a çıktı; sınıfa ve yemine göre alım fiyatı, sağlık, hız, hasar ve menzil ayarları yapıldı.
- İtibara göre tüccar/demirci/otacı hizmet fiyatı ayarlanır; çok kötü itibarda bu hizmetler reddedilir.
- Kuşatmada Sınır Kalesi fethedilince bölge kontrolü ve yeminli gruba küçük itibar ödülü kaydedilir.
- Android paket adı korunur; sürüm adı 0.11.0, version code 11.

## Doğrulama

Offline yapısal test ve kaynak yolu doğrulaması gerekir. Godot çalıştırıcısı bu geliştirme ortamında yoksa GDScript parse/headless runtime ve gerçek APK testleri GitHub Actions üzerinden çalıştırılmalıdır; kodun motor içinde test edildiği iddia edilmez.
