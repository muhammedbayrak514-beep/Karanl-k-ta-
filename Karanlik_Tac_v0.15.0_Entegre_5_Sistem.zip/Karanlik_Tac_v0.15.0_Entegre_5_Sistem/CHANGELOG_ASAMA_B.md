# Karanlık Taç v0.10.0 — Aşama B Açık Dünya Genişletmesi

- Dünya boyutu 900 × 900 metreye çıkarıldı.
- A* yolu 2.5 m hücre adımını koruyacak şekilde 900 m dünyaya uyarlandı.
- Beş yeni keşif noktası ve çevresel silüetleri eklendi.
- Merkezden yeni hedeflere bağlanan yollar ortak rota listesinden üretiliyor.
- Yeni arazi renk alanları, dış dünya bitki/taş dağılımı ve ufuk sırtları eklendi.
- Mini harita ölçeği ve bölge isimleri güncellendi.
- Statik proje doğrulayıcısına Aşama B kontrol maddeleri eklendi.

Bu, oynanış ve Android doğrulaması tamamlanmış bir yayın sürümü değil, açık dünya genişletme aşamasıdır.

Android sürüm kodu 9’dan 10’a, sürüm adı 0.10.0’a çıkarıldı; mevcut v0.9 kayıtlarının şema biçimi aynı kaldığından kayıt biçimi v6 korunur.
