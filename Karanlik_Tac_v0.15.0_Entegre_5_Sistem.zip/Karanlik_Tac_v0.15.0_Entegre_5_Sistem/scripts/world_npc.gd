extends Node3D

var game_ref: Variant = null
var display_name: String = "Gezgin"
var role: String = "villager"
var faction: String = "Yeldeğirmeni"
var faction_id: String = "north_crown"
var body_root: Node3D
var marker: MeshInstance3D
var title_label: Label3D
var elapsed: float = 0.0
var idle_phase: float = 0.0
var wander_enabled: bool = false
var home_position: Vector3 = Vector3.ZERO
var roam_target: Vector3 = Vector3.ZERO
var roam_timer: float = 0.0
var base_y: float = 0.0

func _ready() -> void:
	add_to_group("world_npcs")
	add_to_group("interactables")
	idle_phase = randf_range(0.0, TAU)
	home_position = position
	base_y = position.y
	_build_character()

func _process(delta: float) -> void:
	elapsed += delta
	if role == "villager" or role == "guard" or role == "scout":
		_update_daily_routine(delta)
	if is_instance_valid(body_root):
		body_root.position.y = sin(elapsed * 1.65 + idle_phase) * 0.035
		if role == "villager" or role == "guard" or role == "scout":
			body_root.rotation.y = sin(elapsed * 0.45 + idle_phase) * 0.13
	if is_instance_valid(marker):
		marker.position.y = 3.05 + sin(elapsed * 2.2 + idle_phase) * 0.12
		marker.rotation.y += delta * 0.8

func _update_daily_routine(delta: float) -> void:
	# Short, bounded routines make villagers feel alive without sending them through the whole map.
	roam_timer -= delta
	if roam_timer <= 0.0:
		var radius := 2.8 if role == "villager" else (4.0 if role == "guard" else 3.4)
		roam_target = home_position + Vector3(randf_range(-radius, radius), 0.0, randf_range(-radius, radius))
		roam_timer = randf_range(3.5, 7.5)
	var offset := roam_target - position
	offset.y = 0.0
	if offset.length() > 0.35:
		var step := offset.normalized() * (0.55 if role == "villager" else 0.9) * delta
		position.x += step.x
		position.z += step.z
		if is_instance_valid(game_ref) and is_instance_valid(game_ref.world_ref):
			position.y = game_ref.world_ref.get_ground_height(position.x, position.z)
		if is_instance_valid(body_root):
			body_root.rotation.y = atan2(-offset.x, -offset.z)

func interact(game: Variant) -> void:
	if is_instance_valid(game):
		game.interact_with_npc(self)

func _build_character() -> void:
	body_root = Node3D.new()
	body_root.name = "NPCVisualRoot"
	add_child(body_root)
	var robe_color := Color("#48644d")
	var trim_color := Color("#c6aa68")
	var skin_color := Color("#c89a79")
	var hair_color := Color("#41302a")
	match role:
		"elder":
			robe_color = Color("#62513f")
			trim_color = Color("#e1c67d")
			hair_color = Color("#b8b9b0")
		"merchant":
			robe_color = Color("#326575")
			trim_color = Color("#e1b05e")
		"blacksmith":
			robe_color = Color("#45474b")
			trim_color = Color("#d96e3f")
			hair_color = Color("#302a27")
		"herbalist":
			robe_color = Color("#526b3c")
			trim_color = Color("#9ebd75")
		"guard":
			robe_color = Color("#314e65")
			trim_color = Color("#b8cbd0")
		"companion_guard":
			robe_color = Color("#33495f")
			trim_color = Color("#e3c87d")
			hair_color = Color("#3c3b40")
		"companion_healer":
			robe_color = Color("#3f6b58")
			trim_color = Color("#b5e1a6")
			hair_color = Color("#604b5c")
		"companion_scout":
			robe_color = Color("#5a4936")
			trim_color = Color("#7ec2ad")
			hair_color = Color("#282c25")
		"companion_ranger":
			robe_color = Color("#4d6739")
			trim_color = Color("#d8b95f")
			hair_color = Color("#2e3b2c")
		"scout":
			robe_color = Color("#5a4936")
			trim_color = Color("#d4a24f")
			hair_color = Color("#3d332d")
		"villager":
			robe_color = Color("#81513e") if int(idle_phase * 100.0) % 2 == 0 else Color("#766a48")
			trim_color = Color("#c9b18a")
	var robe := _mat(robe_color, 0.88)
	var trim := _mat(trim_color, 0.52, 0.1)
	var skin := _mat(skin_color, 0.9)
	var hair := _mat(hair_color, 0.97)
	var leather := _mat(Color("#43352a"), 0.95)
	var steel := _mat(Color("#aebfc7"), 0.32, 0.4)
	_add_capsule("LinenTunic", 1.05, 0.34, Vector3(0, 1.0, 0), robe)
	_add_capsule("Neck", 0.2, 0.12, Vector3(0, 1.58, 0), skin)
	_add_sphere("Face", 0.22, Vector3(0, 1.78, -0.02), skin)
	_add_sphere("HairCap", 0.225, Vector3(0, 1.91, 0.015), hair)
	_add_box("WaistSash", Vector3(0.65, 0.12, 0.42), Vector3(0, 0.72, 0), trim)
	_add_capsule("LeftSleeve", 0.62, 0.14, Vector3(-0.42, 1.04, 0), robe)
	_add_capsule("RightSleeve", 0.62, 0.14, Vector3(0.42, 1.04, 0), robe)
	_add_capsule("LeftHand", 0.19, 0.09, Vector3(-0.45, 0.69, -0.02), skin)
	_add_capsule("RightHand", 0.19, 0.09, Vector3(0.45, 0.69, -0.02), skin)
	_add_capsule("LeftBoot", 0.36, 0.14, Vector3(-0.17, 0.2, 0), leather)
	_add_capsule("RightBoot", 0.36, 0.14, Vector3(0.17, 0.2, 0), leather)
	if role == "elder" or role == "herbalist":
		_add_cylinder("WalkingStaff", 0.035, 0.055, 1.55, Vector3(0.59, 0.8, 0), leather)
		_add_sphere("StaffGem", 0.1, Vector3(0.59, 1.62, 0), _glow_mat(Color("#7bdbb0") if role == "herbalist" else Color("#f0cb72")))
	elif role in ["guard", "companion_guard"]:
		_add_box("GuardChestplate", Vector3(0.55, 0.55, 0.1), Vector3(0, 1.15, -0.2), steel)
		_add_cylinder("GuardHelmet", 0.23, 0.24, 0.22, Vector3(0, 1.98, 0), steel)
		_add_box("GuardShield", Vector3(0.32, 0.54, 0.12), Vector3(-0.55, 1.02, -0.05), robe)
		_add_box("GuardSword", Vector3(0.08, 0.78, 0.07), Vector3(0.58, 1.07, -0.08), steel)
	elif role == "blacksmith":
		_add_box("SmithApron", Vector3(0.48, 0.65, 0.08), Vector3(0, 1.0, -0.23), leather)
		_add_box("HammerHandle", Vector3(0.08, 0.66, 0.08), Vector3(0.59, 0.91, -0.08), wood_mat())
		_add_box("HammerHead", Vector3(0.34, 0.16, 0.19), Vector3(0.59, 1.28, -0.08), steel)
	elif role == "merchant":
		_add_cylinder("MerchantPack", 0.25, 0.31, 0.55, Vector3(0, 1.15, 0.25), leather)
		_add_box("MerchantScarf", Vector3(0.56, 0.14, 0.13), Vector3(0, 1.43, -0.18), trim)
	elif role in ["scout", "companion_scout", "companion_ranger"]:
		_add_box("ScoutHood", Vector3(0.47, 0.24, 0.42), Vector3(0, 1.91, 0.04), robe)
		_add_box("ScoutQuiver", Vector3(0.25, 0.62, 0.24), Vector3(-0.27, 1.2, 0.25), leather)
		_add_box("ScoutSpear", Vector3(0.06, 1.55, 0.06), Vector3(0.62, 1.0, 0.03), steel)
	else:
		_add_box("SimpleShoulderWrap", Vector3(0.7, 0.16, 0.39), Vector3(0, 1.42, 0), trim)
	# Static collision keeps the townsfolk from being walked straight through.
	var solid := StaticBody3D.new()
	solid.name = "NPCBodyCollision"
	add_child(solid)
	var collision := CollisionShape3D.new()
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.36
	capsule.height = 1.9
	collision.shape = capsule
	collision.position.y = 0.95
	solid.add_child(collision)
	title_label = Label3D.new()
	title_label.name = "NPCNameplate"
	title_label.text = display_name
	title_label.position = Vector3(0, 2.45, 0)
	title_label.font_size = 26
	title_label.outline_size = 7
	title_label.outline_modulate = Color(0.02, 0.03, 0.035, 0.95)
	title_label.modulate = Color("#f4e3c1")
	title_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	add_child(title_label)
	if role == "elder":
		marker = _add_sphere("QuestMarker", 0.16, Vector3(0, 3.05, 0), _glow_mat(Color("#ffd06a")))
	elif role in ["guard", "companion_guard"]:
		marker = _add_sphere("QuestMarker", 0.16, Vector3(0, 3.05, 0), _glow_mat(Color("#b18cff")))
	elif role in ["scout", "companion_scout", "companion_ranger"]:
		marker = _add_sphere("QuestMarker", 0.16, Vector3(0, 3.05, 0), _glow_mat(Color("#e6a84e")))
	elif role == "companion_healer":
		marker = _add_sphere("CompanionMarker", 0.16, Vector3(0, 3.05, 0), _glow_mat(Color("#74c6a0")))

func _mat(color: Color, roughness: float = 0.9, metallic: float = 0.0) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = roughness
	m.metallic = metallic
	return m

func _glow_mat(color: Color) -> StandardMaterial3D:
	var m := _mat(color, 0.3, 0.05)
	m.emission_enabled = true
	m.emission = color
	m.emission_energy_multiplier = 1.4
	return m

func wood_mat() -> Material:
	return _mat(Color("#543927"), 0.95)

func _add_capsule(node_name: String, height: float, radius: float, at: Vector3, material: Material) -> MeshInstance3D:
	var mesh := CapsuleMesh.new()
	mesh.height = height
	mesh.radius = radius
	var instance := MeshInstance3D.new()
	instance.name = node_name
	instance.mesh = mesh
	instance.material_override = material
	instance.position = at
	body_root.add_child(instance)
	return instance

func _add_sphere(node_name: String, radius: float, at: Vector3, material: Material) -> MeshInstance3D:
	var mesh := SphereMesh.new()
	mesh.radius = radius
	mesh.height = radius * 2.0
	var instance := MeshInstance3D.new()
	instance.name = node_name
	instance.mesh = mesh
	instance.material_override = material
	instance.position = at
	body_root.add_child(instance)
	return instance

func _add_box(node_name: String, dimensions: Vector3, at: Vector3, material: Material) -> MeshInstance3D:
	var mesh := BoxMesh.new()
	mesh.size = dimensions
	var instance := MeshInstance3D.new()
	instance.name = node_name
	instance.mesh = mesh
	instance.material_override = material
	instance.position = at
	body_root.add_child(instance)
	return instance

func _add_cylinder(node_name: String, top_radius: float, bottom_radius: float, height: float, at: Vector3, material: Material) -> MeshInstance3D:
	var mesh := CylinderMesh.new()
	mesh.top_radius = top_radius
	mesh.bottom_radius = bottom_radius
	mesh.height = height
	var instance := MeshInstance3D.new()
	instance.name = node_name
	instance.mesh = mesh
	instance.material_override = material
	instance.position = at
	body_root.add_child(instance)
	return instance
