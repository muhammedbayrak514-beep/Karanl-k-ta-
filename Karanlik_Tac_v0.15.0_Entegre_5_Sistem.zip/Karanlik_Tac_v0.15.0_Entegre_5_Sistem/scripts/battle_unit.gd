extends CharacterBody3D

signal health_changed(current: float, maximum: float)
signal unit_died(unit)

const VisualsScript = preload("res://scripts/unit_visuals.gd")

# Teams: 0 = player, 1 = hostile, 2 = allied.
var team: int = 1
var is_player: bool = false
var game_ref: Variant = null
var unit_class: String = "infantry" # infantry, archer, cavalry
var faction_id: String = ""
var world_id: String = ""
var companion_id: String = ""
var companion_name: String = ""
var max_health: float = 65.0
var health: float = 65.0
var move_speed: float = 2.65
var attack_damage: float = 12.0
var attack_range: float = 1.85
var attack_cooldown: float = 0.0
var attack_animation_left: float = 0.0
var blocking: bool = false
var visuals: Variant = null
var weapon_pivot: Node3D = null
var name_label: Label3D = null
var gravity_strength: float = 24.0

# Orders are only interpreted by allied units. Positions are world-space anchors for HOLD.
var army_order: String = "follow"
var formation_index: int = 0
var order_position: Vector3 = Vector3.ZERO
var _stuck_timer: float = 0.0
var _target_refresh_left: float = 0.0
var _cached_allied_target: Variant = null
var _cached_hostile_target: Variant = null
var _wants_to_move: bool = false
var _last_position: Vector3 = Vector3.ZERO
var _avoidance_side: float = 1.0
var _navigation_path: PackedVector3Array = PackedVector3Array()
var _navigation_path_index: int = 0
var _navigation_goal: Vector3 = Vector3.ZERO
var _navigation_repath_left: float = 0.0
var _navigation_goal_walkable: bool = true

func _ready() -> void:
	add_to_group("battle_units")
	collision_layer = 1
	collision_mask = 1
	var collision := CollisionShape3D.new()
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.43 if unit_class == "cavalry" else (0.38 if unit_class == "shield_guard" else 0.34)
	capsule.height = 2.35 if unit_class == "cavalry" else (2.12 if unit_class == "shield_guard" else 2.05)
	collision.shape = capsule
	collision.position.y = capsule.height * 0.5
	add_child(collision)

	visuals = VisualsScript.new()
	visuals.setup(team, unit_class)
	add_child(visuals)
	weapon_pivot = visuals.weapon_pivot
	if order_position.is_zero_approx():
		order_position = global_position

	name_label = Label3D.new()
	name_label.position = Vector3(0, 2.48 if unit_class == "cavalry" else 2.32, 0)
	name_label.font_size = 26 if team == 2 else 30
	name_label.outline_size = 7
	name_label.outline_modulate = Color(0.025, 0.03, 0.04, 0.95)
	name_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	name_label.no_depth_test = true
	name_label.text = _team_title()
	name_label.modulate = _team_label_color()
	add_child(name_label)
	_last_position = global_position
	_avoidance_side = 1.0 if int(get_instance_id()) % 2 == 0 else -1.0
	health_changed.emit(health, max_health)

func _process(delta: float) -> void:
	attack_cooldown = maxf(0.0, attack_cooldown - delta)
	if attack_animation_left > 0.0:
		attack_animation_left = maxf(0.0, attack_animation_left - delta)
		var progress := 1.0 - attack_animation_left / 0.42
		if is_instance_valid(weapon_pivot):
			weapon_pivot.rotation.z = -sin(progress * PI) * (0.72 if unit_class in ["archer", "crossbowman"] else 1.05)
	else:
		if is_instance_valid(weapon_pivot):
			weapon_pivot.rotation.z = move_toward(weapon_pivot.rotation.z, 0.0, delta * 8.0)

func _physics_process(delta: float) -> void:
	if is_player or health <= 0.0:
		return
	_wants_to_move = false
	_target_refresh_left = maxf(0.0, _target_refresh_left - delta)
	if not is_on_floor():
		velocity.y -= gravity_strength * delta
	elif velocity.y < 0.0:
		velocity.y = -0.5

	if team == 2:
		_run_ally_ai(delta)
	else:
		_run_hostile_ai(delta)
	move_and_slide()
	_update_stuck_state(delta)

func _run_hostile_ai(delta: float) -> void:
	var target: Variant = _get_hostile_target()
	if target != null and is_instance_valid(target) and target.health > 0.0:
		var offset: Vector3 = target.global_position - global_position
		offset.y = 0.0
		var distance := offset.length()
		if distance > attack_range * 0.88:
			_move_toward(_combat_approach_position(target), delta, 1.0)
		else:
			_stop_horizontal(delta)
			if attack_cooldown <= 0.0:
				_perform_attack(target)
	else:
		_stop_horizontal(delta)

func _run_ally_ai(delta: float) -> void:
	if not is_instance_valid(game_ref) or not is_instance_valid(game_ref.player_unit):
		_stop_horizontal(delta)
		return
	var player: Variant = game_ref.player_unit
	var formation_target := _get_formation_target(player)

	# During a siege assault, allied units temporarily prioritize assigned gate approaches.
	if is_instance_valid(game_ref.siege_manager) and game_ref.siege_manager.has_method("is_unit_assaulting_gate") and game_ref.siege_manager.is_unit_assaulting_gate():
		var gate_destination: Vector3 = game_ref.siege_manager.get_gate_approach_position(formation_index)
		if _flat_distance_to(gate_destination) > 2.15:
			_move_toward(gate_destination, delta, 1.0)
		else:
			_stop_horizontal(delta)
		return

	if army_order == "retreat":
		var movement := Vector3.ZERO
		var to_player: Vector3 = player.global_position - global_position
		to_player.y = 0.0
		if to_player.length() > 3.6:
			movement += to_player.normalized()
		var enemy: Variant = _get_cached_allied_target()
		if enemy != null and is_instance_valid(enemy):
			var away: Vector3 = global_position - enemy.global_position
			away.y = 0.0
			if away.length() < 8.0 and not away.is_zero_approx():
				movement += away.normalized() * 1.65
		if movement.length() > 0.1:
			_move_direction(movement.normalized(), delta, 1.12)
		else:
			_stop_horizontal(delta)
		return

	var target: Variant = _get_cached_allied_target()
	var target_distance := INF
	if target != null and is_instance_valid(target):
		target_distance = _flat_distance_to(target.global_position)
	else:
		target = null
	var engagement_radius := 68.0 if army_order == "charge" else (17.0 if unit_class in ["archer", "crossbowman"] else 11.0)
	if army_order == "hold":
		engagement_radius = 15.0 if unit_class in ["archer", "crossbowman"] else 8.0
		if target != null and target.global_position.distance_to(order_position) > 11.0:
			target = null
			target_distance = INF
	elif army_order == "follow" and target != null and target_distance > engagement_radius:
		target = null
		target_distance = INF
	elif army_order == "charge" and target_distance > engagement_radius:
		target = null
		target_distance = INF

	if target != null and is_instance_valid(target) and target.health > 0.0:
		var offset: Vector3 = target.global_position - global_position
		offset.y = 0.0
		target_distance = offset.length()
		if target_distance <= attack_range:
			_stop_horizontal(delta)
			if not offset.is_zero_approx():
				look_at(global_position + offset.normalized(), Vector3.UP)
			if attack_cooldown <= 0.0:
				_perform_attack(target)
			return
		var can_pursue := army_order == "charge"
		if army_order == "follow":
			can_pursue = target_distance <= 8.0
		elif army_order == "hold":
			can_pursue = target_distance <= 4.5 and _flat_distance_to(order_position) <= 5.0
		if can_pursue:
			_move_toward(_combat_approach_position(target), delta, 1.0)
			return

	if army_order == "charge":
		_stop_horizontal(delta)
	elif army_order == "hold":
		_move_toward(order_position, delta, 1.0)
	else:
		_move_toward(formation_target, delta, 1.0)

func _get_hostile_target() -> Variant:
	return _get_cached_hostile_target()

func _get_cached_hostile_target() -> Variant:
	if is_instance_valid(game_ref) and game_ref.has_method("is_faction_friendly_to_player") and game_ref.is_faction_friendly_to_player(str(faction_id)):
		_cached_hostile_target = null
		_target_refresh_left = 0.18
		return null
	if not is_instance_valid(game_ref):
		_cached_hostile_target = null
		return null
	if _cached_hostile_target != null and not _is_live_target(_cached_hostile_target):
		_target_refresh_left = 0.0
	if _target_refresh_left <= 0.0:
		_cached_hostile_target = game_ref.find_nearest_friendly(self)
		_target_refresh_left = 0.22 + randf() * 0.12
	if _is_live_target(_cached_hostile_target) and global_position.distance_to(_cached_hostile_target.global_position) <= 68.0:
		return _cached_hostile_target
	return null

func _get_cached_allied_target() -> Variant:
	if not is_instance_valid(game_ref):
		_cached_allied_target = null
		return null
	if _cached_allied_target != null and not _is_live_target(_cached_allied_target):
		_target_refresh_left = 0.0
	if _target_refresh_left <= 0.0:
		_cached_allied_target = game_ref.find_nearest_enemy(self)
		_target_refresh_left = 0.20 + randf() * 0.14
	return _cached_allied_target if _is_live_target(_cached_allied_target) else null

func _is_live_target(candidate: Variant) -> bool:
	return is_instance_valid(candidate) and candidate.get("health") != null and float(candidate.health) > 0.0

func _get_formation_target(player: Variant) -> Vector3:
	var offsets: Array[Vector2] = []
	var formation := "line"
	if is_instance_valid(game_ref):
		formation = str(game_ref.army_formation)
	match formation:
		"wedge":
			offsets = [Vector2(-1.15, 2.4), Vector2(1.15, 2.4), Vector2(-2.15, 4.2), Vector2(2.15, 4.2), Vector2(-3.05, 6.0), Vector2(3.05, 6.0), Vector2(-4.0, 7.8), Vector2(4.0, 7.8), Vector2(-4.9, 9.6), Vector2(4.9, 9.6), Vector2(-5.8, 11.4), Vector2(5.8, 11.4), Vector2(-6.5, 13.2), Vector2(6.5, 13.2), Vector2(-7.2, 15.0), Vector2(7.2, 15.0)]
		"column":
			offsets = [Vector2(-0.52, 2.5), Vector2(0.52, 3.6), Vector2(-0.52, 4.7), Vector2(0.52, 5.8), Vector2(-0.52, 6.9), Vector2(0.52, 8.0), Vector2(-0.52, 9.1), Vector2(0.52, 10.2), Vector2(-0.52, 11.3), Vector2(0.52, 12.4), Vector2(-0.52, 13.5), Vector2(0.52, 14.6), Vector2(-0.52, 15.7), Vector2(0.52, 16.8), Vector2(-0.52, 17.9), Vector2(0.52, 19.0)]
		_:
			offsets = [Vector2(-2.7, 3.0), Vector2(-0.9, 3.0), Vector2(0.9, 3.0), Vector2(2.7, 3.0), Vector2(-2.7, 4.8), Vector2(-0.9, 4.8), Vector2(0.9, 4.8), Vector2(2.7, 4.8), Vector2(-2.7, 6.6), Vector2(-0.9, 6.6), Vector2(0.9, 6.6), Vector2(2.7, 6.6), Vector2(-2.7, 8.4), Vector2(-0.9, 8.4), Vector2(0.9, 8.4), Vector2(2.7, 8.4)]
	var offset: Vector2 = offsets[clampi(formation_index, 0, offsets.size() - 1)]
	var right: Vector3 = player.global_basis.x
	var backward: Vector3 = player.global_basis.z
	var destination: Vector3 = player.global_position + right * offset.x + backward * offset.y
	if is_instance_valid(game_ref) and game_ref.world_ref != null and game_ref.world_ref.has_method("get_ground_height"):
		destination.y = game_ref.world_ref.get_ground_height(destination.x, destination.z)
	return destination

func set_army_order(order_id: String, new_index: int = -1) -> void:
	if team != 2:
		return
	if order_id in ["follow", "hold", "charge", "retreat"]:
		army_order = order_id
	if new_index >= 0:
		formation_index = clampi(new_index, 0, 15)
	if army_order == "hold":
		order_position = global_position
	elif army_order == "follow":
		order_position = global_position
	_navigation_path = PackedVector3Array()
	_navigation_path_index = 0
	_navigation_repath_left = 0.0
	_update_name_label()

func set_formation_index(new_index: int) -> void:
	formation_index = clampi(new_index, 0, 15)

func _move_toward(destination: Vector3, delta: float, speed_multiplier: float) -> void:
	var offset := destination - global_position
	offset.y = 0.0
	if offset.length() <= 0.85:
		_stop_horizontal(delta)
		return

	_navigation_repath_left = maxf(0.0, _navigation_repath_left - delta)
	var goal_moved := _navigation_goal.distance_to(destination) > 3.0
	var path_finished := _navigation_path_index >= _navigation_path.size()
	var needs_path := ((_navigation_path.is_empty() or path_finished) and _navigation_repath_left <= 0.0) or (goal_moved and _navigation_repath_left <= 0.0) or _stuck_timer > 1.2
	if needs_path and is_instance_valid(game_ref) and is_instance_valid(game_ref.world_ref) and game_ref.world_ref.has_method("get_navigation_path"):
		_navigation_path = game_ref.world_ref.get_navigation_path(global_position, destination)
		_navigation_path_index = 0
		_navigation_goal = destination
		_navigation_goal_walkable = true
		if game_ref.world_ref.has_method("is_navigation_position_walkable"):
			_navigation_goal_walkable = game_ref.world_ref.is_navigation_position_walkable(destination)
		_navigation_repath_left = 0.48
		_stuck_timer = 0.0 if _stuck_timer > 1.2 else _stuck_timer

	var waypoint := destination
	while _navigation_path_index < _navigation_path.size():
		var candidate: Vector3 = _navigation_path[_navigation_path_index]
		var to_candidate := candidate - global_position
		to_candidate.y = 0.0
		if to_candidate.length() <= 1.15:
			_navigation_path_index += 1
		else:
			waypoint = candidate
			break
	if _navigation_path_index >= _navigation_path.size():
		if not _navigation_goal_walkable:
			_stop_horizontal(delta)
			return
		waypoint = destination
	var travel := waypoint - global_position
	travel.y = 0.0
	if travel.length() > 0.05:
		_move_direction(travel.normalized(), delta, speed_multiplier)
	else:
		_stop_horizontal(delta)

func _combat_approach_position(target: Variant) -> Vector3:
	if not is_instance_valid(target) or unit_class in ["archer", "crossbowman"]:
		return target.global_position if is_instance_valid(target) else global_position
	var ring_radius := maxf(0.8, attack_range * 0.72)
	var ring_index := formation_index if team == 2 else int(get_instance_id() % 6)
	var angle := float(ring_index) * TAU / 6.0
	return target.global_position + Vector3(cos(angle) * ring_radius, 0.0, sin(angle) * ring_radius)

func _move_direction(direction: Vector3, delta: float, speed_multiplier: float) -> void:
	if direction.length() <= 0.01:
		_stop_horizontal(delta)
		return
	var desired := direction.normalized()
	var steered := _steering_direction(desired)
	if steered.length() <= 0.01:
		steered = desired
	_wants_to_move = true
	velocity.x = steered.x * move_speed * speed_multiplier
	velocity.z = steered.z * move_speed * speed_multiplier
	look_at(global_position + Vector3(steered.x, 0.0, steered.z), Vector3.UP)

func _steering_direction(desired: Vector3) -> Vector3:
	# Short forward ray detects walls and solid props. Side probes choose a clear detour.
	var forward := Vector3(desired.x, 0.0, desired.z).normalized()
	if forward.length() <= 0.01 or not is_inside_tree() or get_world_3d() == null:
		return forward
	var space := get_world_3d().direct_space_state
	var ray_start := global_position + Vector3.UP * 1.05
	var forward_length := 2.2 if _stuck_timer < 0.9 else 3.8
	if not _ray_is_blocked(space, ray_start, ray_start + forward * forward_length):
		return forward

	var left := Vector3(-forward.z, 0.0, forward.x)
	var right := -left
	var left_clear := not _ray_is_blocked(space, ray_start, ray_start + left * 2.5 + forward * 0.85)
	var right_clear := not _ray_is_blocked(space, ray_start, ray_start + right * 2.5 + forward * 0.85)
	if left_clear and right_clear:
		# Keep the same preferred side per unit to avoid frame-to-frame steering jitter.
		return (left + forward * 0.65).normalized() if _avoidance_side > 0.0 else (right + forward * 0.65).normalized()
	if left_clear:
		return (left + forward * 0.55).normalized()
	if right_clear:
		return (right + forward * 0.55).normalized()
	# If trapped in a tight corner, try a broad sideways escape based on unit index.
	var escape := left if int(get_instance_id()) % 2 == 0 else right
	if not _ray_is_blocked(space, ray_start, ray_start + escape * 3.4):
		return (escape + forward * 0.18).normalized()
	return Vector3.ZERO

func _ray_is_blocked(space: PhysicsDirectSpaceState3D, ray_from: Vector3, ray_to: Vector3) -> bool:
	var exclude: Array[RID] = [get_rid()]
	var query := PhysicsRayQueryParameters3D.create(ray_from, ray_to, collision_mask, exclude)
	query.collide_with_areas = false
	query.collide_with_bodies = true
	return not space.intersect_ray(query).is_empty()

func _update_stuck_state(delta: float) -> void:
	var moved := global_position.distance_to(_last_position)
	if _wants_to_move and Vector2(velocity.x, velocity.z).length() > 0.35:
		if moved < 0.025:
			_stuck_timer += delta
		else:
			_stuck_timer = maxf(0.0, _stuck_timer - delta * 2.0)
	else:
		_stuck_timer = maxf(0.0, _stuck_timer - delta * 2.0)
	_last_position = global_position

func _stop_horizontal(delta: float) -> void:
	velocity.x = move_toward(velocity.x, 0.0, move_speed * 4.0 * delta)
	velocity.z = move_toward(velocity.z, 0.0, move_speed * 4.0 * delta)

func _flat_distance_to(target_position: Vector3) -> float:
	var offset := target_position - global_position
	offset.y = 0.0
	return offset.length()

func _perform_attack(target: Variant) -> void:
	if health <= 0.0 or attack_cooldown > 0.0 or not is_instance_valid(target) or target.health <= 0.0:
		return
	attack_cooldown = (1.65 if unit_class == "crossbowman" else 1.42) if unit_class in ["archer", "crossbowman"] else (0.86 if unit_class == "cavalry" else 0.95)
	attack_animation_left = 0.42
	if unit_class in ["archer", "crossbowman"] and is_instance_valid(game_ref) and game_ref.has_method("launch_arrow"):
		game_ref.launch_arrow(global_position + Vector3(0, 1.45, 0), target, attack_damage, self)
	else:
		target.receive_damage(attack_damage, self)

func _start_attack() -> bool:
	if health <= 0.0 or attack_cooldown > 0.0:
		return false
	attack_cooldown = 0.92 if team == 1 else 0.78
	attack_animation_left = 0.34
	return true

func receive_damage(amount: float, attacker: Variant = null) -> void:
	if health <= 0.0:
		return
	var actual_damage := amount
	if is_player and is_instance_valid(game_ref) and game_ref.has_method("get_player_damage_multiplier"):
		actual_damage *= float(game_ref.get_player_damage_multiplier())
	if is_player and blocking:
		actual_damage *= 0.32
	health = maxf(0.0, health - actual_damage)
	_spawn_damage_feedback(actual_damage)
	health_changed.emit(health, max_health)
	if health <= 0.0:
		_die()

func _spawn_damage_feedback(amount: float) -> void:
	if amount <= 0.0 or not is_inside_tree():
		return
	var label := Label3D.new()
	label.name = "FloatingDamageNumber"
	label.text = str(roundi(amount))
	label.position = global_position + Vector3(randf_range(-0.22, 0.22), 2.45, 0.0)
	label.font_size = 30 if amount >= 30.0 else 24
	label.outline_size = 7
	label.outline_modulate = Color(0.02, 0.02, 0.025, 0.95)
	label.modulate = Color("#ffd274") if amount >= 30.0 else Color("#f4e8dc")
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	label.no_depth_test = true
	get_tree().current_scene.add_child(label)
	var tween := label.create_tween()
	tween.set_parallel(true)
	tween.tween_property(label, "position", label.position + Vector3(0, 0.8, 0), 0.62)
	tween.tween_property(label, "modulate:a", 0.0, 0.62)
	tween.chain().tween_callback(label.queue_free)

func _die() -> void:
	set_physics_process(false)
	set_process(false)
	collision_layer = 0
	collision_mask = 0
	unit_died.emit(self)
	if game_ref != null:
		game_ref.on_unit_died(self)
	queue_free()

func _team_title() -> String:
	if team == 2 and not companion_name.is_empty():
		return "YOLDAŞ · " + companion_name.to_upper()
	if team == 0:
		return "KOMUTAN"
	if team == 2:
		return _class_title() + " · " + _order_title()
	return "AKINCI"

func _class_title() -> String:
	match unit_class:
		"archer": return "OKÇU"
		"crossbowman": return "ARBALETÇİ"
		"cavalry": return "SÜVARİ"
		"shield_guard": return "KALKANLI MUHAFIZ"
		_: return "PİYADE"

func _order_title() -> String:
	match army_order:
		"hold": return "MEVZİ"
		"charge": return "HÜCUM"
		"retreat": return "GERİ ÇEKİL"
		_: return "TAKİP"

func _update_name_label() -> void:
	if is_instance_valid(name_label):
		name_label.text = _team_title()

func _team_label_color() -> Color:
	if team == 0:
		return Color("#f2d18b")
	if team == 2:
		match unit_class:
			"archer": return Color("#b6e09e")
			"crossbowman": return Color("#d8d09a")
			"cavalry": return Color("#e5ca84")
			"shield_guard": return Color("#b9c6d2")
			_: return Color("#a5d9e7")
	return Color("#f1a39a")
