extends "res://scripts/battle_unit.gd"

var mobile_move: Vector2 = Vector2.ZERO
var camera_rig: Node3D = null
var camera_node: Camera3D = null
var camera_yaw: float = 0.0
var camera_pitch: float = -0.29
var sprinting: bool = false
var touch_blocking: bool = false
var touch_sprinting: bool = false
var stamina: float = 100.0
var max_stamina: float = 100.0
var parry_window_left: float = 0.0

func _init() -> void:
	team = 0
	is_player = true
	max_health = 180.0
	health = 180.0
	move_speed = 5.0
	attack_damage = 34.0
	attack_range = 2.25

func _ready() -> void:
	super._ready()
	name = "PlayerCommander"
	camera_rig = Node3D.new()
	camera_rig.name = "OrbitCameraRig"
	game_ref.add_child(camera_rig)
	camera_node = Camera3D.new()
	camera_node.name = "ThirdPersonCamera"
	camera_node.position = Vector3(0, 2.05, 6.0)
	camera_node.rotation.x = camera_pitch
	camera_node.fov = 72.0
	camera_rig.add_child(camera_node)
	camera_node.make_current()
	_update_camera_rig()
	refresh_gear_visuals()

func _process(delta: float) -> void:
	super._process(delta)
	parry_window_left = maxf(0.0, parry_window_left - delta)
	var wants_block := touch_blocking or Input.is_key_pressed(KEY_Q) or Input.is_key_pressed(KEY_CTRL)
	if wants_block and stamina >= 5.0:
		if not blocking:
			parry_window_left = 0.22
		blocking = true
		stamina = maxf(0.0, stamina - 8.5 * delta)
	else:
		blocking = false
		stamina = minf(max_stamina, stamina + (12.0 if sprinting else 19.0) * delta)
	if Input.is_key_pressed(KEY_SPACE) and attack_cooldown <= 0.0:
		try_player_attack()
	if game_ref != null:
		game_ref.try_summon_troops_from_keyboard()

func _physics_process(delta: float) -> void:
	if health <= 0.0:
		return
	if not is_on_floor():
		velocity.y -= gravity_strength * delta
	elif velocity.y < 0.0:
		velocity.y = -0.5

	var keyboard := Vector2.ZERO
	if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT):
		keyboard.x -= 1.0
	if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT):
		keyboard.x += 1.0
	if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP):
		keyboard.y -= 1.0
	if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN):
		keyboard.y += 1.0
	var control := (keyboard + mobile_move).limit_length(1.0)
	var forward := Vector3(-sin(camera_yaw), 0, -cos(camera_yaw))
	var right := Vector3(cos(camera_yaw), 0, -sin(camera_yaw))
	var direction := (right * control.x + forward * -control.y)
	if direction.length() > 0.05:
		direction = direction.normalized()
		sprinting = (Input.is_key_pressed(KEY_SHIFT) or touch_sprinting) and stamina > 8.0
		var companion_speed_multiplier := float(game_ref.get_companion_move_multiplier()) if is_instance_valid(game_ref) and game_ref.has_method("get_companion_move_multiplier") else 1.0
		var speed := move_speed * companion_speed_multiplier * (1.42 if sprinting else 1.0)
		if sprinting:
			stamina = maxf(0.0, stamina - 22.0 * delta)
		velocity.x = direction.x * speed
		velocity.z = direction.z * speed
		look_at(global_position + direction, Vector3.UP)
	else:
		sprinting = false
		velocity.x = move_toward(velocity.x, 0.0, 18.0 * delta)
		velocity.z = move_toward(velocity.z, 0.0, 18.0 * delta)
	move_and_slide()
	_update_camera_rig()

func _update_camera_rig() -> void:
	if not is_instance_valid(camera_rig):
		return
	camera_rig.global_position = global_position + Vector3(0, 1.1, 0)
	camera_rig.rotation.y = camera_yaw
	if is_instance_valid(camera_node):
		camera_node.rotation.x = camera_pitch

func rotate_camera(horizontal_delta: float, vertical_delta: float) -> void:
	camera_yaw -= horizontal_delta
	camera_pitch = clampf(camera_pitch - vertical_delta, -0.58, 0.12)
	_update_camera_rig()

func refresh_gear_visuals() -> void:
	if not is_instance_valid(visuals) or not is_instance_valid(game_ref):
		return
	if visuals.has_method("set_equipment_appearance"):
		visuals.set_equipment_appearance(game_ref.armor_level, game_ref.boots_level, game_ref.ring_level)
	if visuals.has_method("set_weapon_style"):
		visuals.set_weapon_style(game_ref.weapon_type)
	var profile: Dictionary = game_ref._weapon_profile()
	attack_range = float(profile.get("range", 2.25))

func set_mobile_move(value: Vector2) -> void:
	mobile_move = value

func set_mobile_sprint(value: bool) -> void:
	touch_sprinting = value

func set_blocking(value: bool) -> void:
	if value and not touch_blocking:
		parry_window_left = 0.22
	touch_blocking = value
	blocking = touch_blocking or Input.is_key_pressed(KEY_Q) or Input.is_key_pressed(KEY_CTRL)

func try_player_attack() -> void:
	if health <= 0.0 or game_ref == null:
		return
	var weapon_profile: Dictionary = game_ref._weapon_profile()
	var stamina_cost := float(weapon_profile.get("stamina", 12.0))
	if stamina < stamina_cost:
		if game_ref.has_method("show_notice"):
			game_ref.show_notice("Yoruldun! Birkaç saniye dinlenerek dayanıklılığını yenile.")
		return
	if attack_cooldown > 0.0:
		return
	stamina -= stamina_cost
	attack_cooldown = float(weapon_profile.get("cooldown", 0.78))
	attack_animation_left = 0.42
	var facing := -global_basis.z
	facing.y = 0.0
	facing = facing.normalized()
	var possible_targets: Array = []
	var all_targets: Array = get_tree().get_nodes_in_group("battle_units").duplicate()
	all_targets.append_array(get_tree().get_nodes_in_group("wild_creatures"))
	for unit in all_targets:
		if unit == self or not is_instance_valid(unit) or unit.health <= 0.0 or unit.team == team or unit.team == 2:
			continue
		if game_ref.has_method("is_faction_friendly_to_player") and game_ref.is_faction_friendly_to_player(str(unit.get("faction_id"))):
			continue
		var offset: Vector3 = unit.global_position - global_position
		offset.y = 0.0
		var distance := offset.length()
		if distance > attack_range or distance < 0.01:
			continue
		var forward_score := facing.dot(offset.normalized())
		if forward_score > -0.05:
			possible_targets.append({"unit": unit, "distance": distance, "facing": forward_score})
	possible_targets.sort_custom(func(a: Dictionary, b: Dictionary) -> bool: return a["distance"] < b["distance"])
	var hits := mini(2, possible_targets.size())
	for index in range(hits):
		var target: Variant = possible_targets[index].unit
		var distance: float = possible_targets[index].distance
		var damage := attack_damage * game_ref.get_weapon_damage_multiplier()
		if game_ref.has_method("get_companion_outgoing_damage_multiplier"):
			damage *= float(game_ref.get_companion_outgoing_damage_multiplier())
		if distance >= 1.65:
			damage *= 0.78
		var critical_chance := 0.10 + float(game_ref.ring_level) * 0.025
		if randf() < critical_chance:
			damage *= 1.65
			if game_ref.has_method("show_notice"):
				game_ref.show_notice("KRİTİK VURUŞ! %.0f hasar" % damage)
		target.receive_damage(damage, self)

func receive_damage(amount: float, attacker: Variant = null) -> void:
	var incoming_damage := amount
	if is_instance_valid(game_ref) and game_ref.has_method("get_settlement_defense_multiplier"):
		incoming_damage *= float(game_ref.get_settlement_defense_multiplier(global_position))
	if is_instance_valid(game_ref) and game_ref.has_method("get_companion_incoming_damage_multiplier"):
		incoming_damage *= float(game_ref.get_companion_incoming_damage_multiplier())
	if blocking and parry_window_left > 0.0:
		var was_blocking := blocking
		blocking = false
		super.receive_damage(incoming_damage * 0.18, attacker)
		blocking = was_blocking
		parry_window_left = 0.0
		stamina = maxf(0.0, stamina - 10.0)
		if is_instance_valid(game_ref) and game_ref.has_method("show_notice"):
			game_ref.show_notice("ZAMANLAMALI SAVUNMA! Hasar büyük ölçüde azaltıldı.")
		return
	super.receive_damage(incoming_damage, attacker)

func wasd_help_text() -> String:
	return "WASD: hareket | SHIFT: koş (dayanıklılık harcar) | SPACE: saldırı | R: silah değiştir | Q: savun / zamanlamalı savuştur | E: destek"
