extends RefCounted

# Lightweight campaign layer: diplomacy, player reputation, oath and territory ownership.
# Kept data-only so it can be saved safely and does not add background simulation cost.
const FACTION_ORDER: Array[String] = [
	"north_crown", "aurel_empire", "red_banner", "mountain_clans", "black_seal"
]
const FACTION_DATA: Dictionary = {
	"north_crown": {"name": "Kuzey Tahtı", "leader": "Kraliçe Elira", "capital": "Kuzeyhisar", "description": "Eski krallığın sınır muhafızları.", "color": "#4c7891"},
	"aurel_empire": {"name": "Aurel İmparatorluğu", "leader": "İmparator Cassian", "capital": "Aurelion", "description": "Düzenli lejyonları ve zengin ticaret yolları.", "color": "#c4a35a"},
	"red_banner": {"name": "Kızıl Sancak Boyları", "leader": "Başbuğ Orhan", "capital": "Kızılgeçit", "description": "Sınır kaleleri ve hızlı akıncı birlikleri.", "color": "#a24b43"},
	"mountain_clans": {"name": "Dağ Klanları", "leader": "Ana Reis Yelda", "capital": "Taşboynuz", "description": "Dağ geçitlerini ve eski madenleri tutarlar.", "color": "#73916a"},
	"black_seal": {"name": "Kara Mühür Birliği", "leader": "Mühür Efendisi", "capital": "Külkale", "description": "Sınırları tehdit eden acımasız paralı askerler.", "color": "#796b8b"}
}
const BASE_RELATIONS: Dictionary = {
	"north_crown": {"aurel_empire": 18, "red_banner": -38, "mountain_clans": 12, "black_seal": -65},
	"aurel_empire": {"north_crown": 18, "red_banner": -12, "mountain_clans": -8, "black_seal": -45},
	"red_banner": {"north_crown": -38, "aurel_empire": -12, "mountain_clans": 8, "black_seal": -18},
	"mountain_clans": {"north_crown": 12, "aurel_empire": -8, "red_banner": 8, "black_seal": -35},
	"black_seal": {"north_crown": -65, "aurel_empire": -45, "red_banner": -18, "mountain_clans": -35}
}
const TERRITORY_DATA: Dictionary = {
	"windmill_village": {"name": "Yeldeğirmeni Köyü", "owner": "north_crown"},
	"westwatch": {"name": "Batı Gözetleme Kulesi", "owner": "north_crown"},
	"frost_monastery": {"name": "Karakış Manastırı", "owner": "mountain_clans"},
	"ashen_fields": {"name": "Kül Ovası", "owner": "black_seal"},
	"eastern_watch": {"name": "Doğu Sınır Gözetimi", "owner": "aurel_empire"},
	"caravan_stop": {"name": "Batık Kervan Durağı", "owner": "red_banner"},
	"frontier_castle": {"name": "Sınır Kalesi", "owner": "red_banner"}
}

var player_oath: String = ""
var player_standing: Dictionary = {}
var territories: Dictionary = {}
var met_npcs: Array[String] = []
var relation_overrides: Dictionary = {}
var faction_wars: Array[Dictionary] = []
var faction_alliances: Array[Dictionary] = []
var campaign_day: int = 1
var recent_campaign_events: Array[String] = []
var war_cooldowns: Dictionary = {}
var _campaign_rng := RandomNumberGenerator.new()

func initialize(saved_state: Dictionary = {}) -> void:
	player_standing.clear()
	for faction_id in FACTION_ORDER:
		player_standing[faction_id] = 0
	var saved_standing: Variant = saved_state.get("standing", {})
	if saved_standing is Dictionary:
		for faction_id in FACTION_ORDER:
			player_standing[faction_id] = clampi(int(saved_standing.get(faction_id, 0)), -100, 100)
	player_oath = str(saved_state.get("oath", ""))
	if not FACTION_ORDER.has(player_oath):
		player_oath = ""
	territories.clear()
	for territory_id in TERRITORY_DATA.keys():
		territories[territory_id] = str(TERRITORY_DATA[territory_id].get("owner", "neutral"))
	var saved_territories: Variant = saved_state.get("territories", {})
	if saved_territories is Dictionary:
		for territory_id in TERRITORY_DATA.keys():
			var owner := str(saved_territories.get(territory_id, territories[territory_id]))
			if owner == "player" or FACTION_ORDER.has(owner):
				territories[territory_id] = owner
	met_npcs.clear()
	var saved_met: Variant = saved_state.get("met_npcs", [])
	if saved_met is Array:
		for npc_id in saved_met:
			var safe_id := str(npc_id)
			if not safe_id.is_empty() and not met_npcs.has(safe_id):
				met_npcs.append(safe_id)
	relation_overrides.clear()
	var saved_relations: Variant = saved_state.get("relation_overrides", {})
	if saved_relations is Dictionary:
		for faction_a in FACTION_ORDER:
			var row: Variant = saved_relations.get(faction_a, {})
			if row is Dictionary:
				relation_overrides[faction_a] = {}
				for faction_b in FACTION_ORDER:
					if faction_a != faction_b and row.has(faction_b):
						relation_overrides[faction_a][faction_b] = clampi(int(row[faction_b]), -100, 100)
	faction_wars.clear()
	faction_alliances.clear()
	campaign_day = maxi(1, int(saved_state.get("campaign_day", 1)))
	recent_campaign_events.clear()
	war_cooldowns = {}
	var saved_wars: Variant = saved_state.get("wars", [])
	if saved_wars is Array:
		for row_value in saved_wars:
			if not row_value is Dictionary:
				continue
			var a := str(row_value.get("a", ""))
			var b := str(row_value.get("b", ""))
			if a != b and FACTION_ORDER.has(a) and FACTION_ORDER.has(b) and not are_at_war(a, b):
				faction_wars.append({"a": a, "b": b, "days": clampi(int(row_value.get("days", 0)), 0, 9999)})
	# A new or v0.14 legacy campaign starts with a visible border conflict. Modern
	# saves that explicitly store an empty wars array stay peaceful if the player ended it.
	if not saved_state.has("wars") and not are_at_war("north_crown", "black_seal"):
		faction_wars.append({"a": "north_crown", "b": "black_seal", "days": 1})
	var saved_alliances: Variant = saved_state.get("alliances", [])
	if saved_alliances is Array:
		for row_value in saved_alliances:
			if not row_value is Dictionary:
				continue
			var a := str(row_value.get("a", ""))
			var b := str(row_value.get("b", ""))
			if a != b and FACTION_ORDER.has(a) and FACTION_ORDER.has(b) and not are_allied(a, b) and not are_at_war(a, b):
				faction_alliances.append({"a": a, "b": b, "days": clampi(int(row_value.get("days", 0)), 0, 9999)})
	var saved_cooldowns: Variant = saved_state.get("war_cooldowns", {})
	if saved_cooldowns is Dictionary:
		for pair_key in saved_cooldowns.keys():
			war_cooldowns[str(pair_key)] = maxi(0, int(saved_cooldowns[pair_key]))
	_campaign_rng.randomize()

func to_dict() -> Dictionary:
	return {
		"oath": player_oath,
		"standing": player_standing.duplicate(true),
		"territories": territories.duplicate(true),
		"met_npcs": met_npcs.duplicate(),
		"relation_overrides": relation_overrides.duplicate(true),
		"wars": faction_wars.duplicate(true),
		"alliances": faction_alliances.duplicate(true),
		"campaign_day": campaign_day,
		"war_cooldowns": war_cooldowns.duplicate(true)
	}

func get_faction_ids() -> Array[String]:
	return FACTION_ORDER.duplicate()

func get_faction_data(faction_id: String) -> Dictionary:
	if not FACTION_DATA.has(faction_id):
		return {}
	return FACTION_DATA[faction_id].duplicate(true)

func get_faction_name(faction_id: String) -> String:
	if faction_id == "player":
		return "Oyuncu / Komutan"
	if FACTION_DATA.has(faction_id):
		return str(FACTION_DATA[faction_id].get("name", faction_id))
	return "Tarafsız"

func get_standing(faction_id: String) -> int:
	return int(player_standing.get(_normalize_faction(faction_id), 0))

func get_attitude(faction_id: String) -> String:
	var value := get_standing(faction_id)
	if value >= 50:
		return "Müttefik"
	if value >= 20:
		return "Dostça"
	if value <= -50:
		return "Düşman"
	if value <= -20:
		return "Gergin"
	return "Tarafsız"

func get_faction_relation(faction_a: String, faction_b: String) -> int:
	if faction_a == faction_b:
		return 100
	if not FACTION_ORDER.has(faction_a) or not FACTION_ORDER.has(faction_b):
		return 0
	var override_row: Variant = relation_overrides.get(faction_a, {})
	if override_row is Dictionary and override_row.has(faction_b):
		return int(override_row[faction_b])
	var base_row: Variant = BASE_RELATIONS.get(faction_a, {})
	if base_row is Dictionary:
		return int(base_row.get(faction_b, 0))
	return 0

func change_faction_relation(faction_a: String, faction_b: String, amount: int) -> void:
	if faction_a == faction_b or not FACTION_ORDER.has(faction_a) or not FACTION_ORDER.has(faction_b):
		return
	var next_value := clampi(get_faction_relation(faction_a, faction_b) + amount, -100, 100)
	if not relation_overrides.has(faction_a):
		relation_overrides[faction_a] = {}
	if not relation_overrides.has(faction_b):
		relation_overrides[faction_b] = {}
	relation_overrides[faction_a][faction_b] = next_value
	relation_overrides[faction_b][faction_a] = next_value

func change_standing(faction_id: String, amount: int) -> int:
	var normalized := _normalize_faction(faction_id)
	if not FACTION_ORDER.has(normalized):
		return 0
	var next_value := clampi(get_standing(normalized) + amount, -100, 100)
	player_standing[normalized] = next_value
	return next_value

func record_hostile_kill(raw_faction_id: String) -> Dictionary:
	var faction_id := _normalize_faction(raw_faction_id)
	if not FACTION_ORDER.has(faction_id):
		faction_id = "red_banner"
	var gains: Dictionary = {}
	gains[faction_id] = change_standing(faction_id, -3)
	for other_id in FACTION_ORDER:
		if other_id == faction_id:
			continue
		if get_faction_relation(other_id, faction_id) <= -35:
			gains[other_id] = change_standing(other_id, 1)
	return {"faction_id": faction_id, "gains": gains}

func record_npc_meeting(npc_id: String, raw_faction_id: String) -> bool:
	var safe_npc_id := npc_id.strip_edges()
	var faction_id := _normalize_faction(raw_faction_id)
	if safe_npc_id.is_empty() or met_npcs.has(safe_npc_id) or not FACTION_ORDER.has(faction_id):
		return false
	met_npcs.append(safe_npc_id)
	change_standing(faction_id, 2)
	return true

func can_pledge(faction_id: String) -> bool:
	if not FACTION_ORDER.has(faction_id):
		return false
	if player_oath.is_empty() or player_oath == faction_id:
		return true
	return get_standing(faction_id) >= 40

func pledge(faction_id: String) -> Dictionary:
	if not FACTION_ORDER.has(faction_id):
		return {"ok": false, "message": "Bilinmeyen krallık."}
	if player_oath == faction_id:
		return {"ok": false, "message": "%s adına zaten yemin ettin." % get_faction_name(faction_id)}
	if not can_pledge(faction_id):
		return {"ok": false, "message": "Yeni bir krallığa geçmek için o krallıkla en az +40 itibara ulaş."}
	var previous_oath := player_oath
	if not previous_oath.is_empty():
		change_standing(previous_oath, -25)
	player_oath = faction_id
	change_standing(faction_id, 15 if previous_oath.is_empty() else 10)
	return {"ok": true, "message": "%s için yemin ettin. İtibarın arttı; rakipleri sana karşı daha dikkatli olabilir." % get_faction_name(faction_id)}

func capture_frontier_castle() -> bool:
	if str(territories.get("frontier_castle", "red_banner")) == "player":
		return false
	territories["frontier_castle"] = "player"
	if not player_oath.is_empty():
		change_standing(player_oath, 5)
	return true

func get_territory_rows() -> Array[Dictionary]:
	var rows: Array[Dictionary] = []
	for territory_id in TERRITORY_DATA.keys():
		var details: Dictionary = TERRITORY_DATA[territory_id]
		var owner_id := str(territories.get(territory_id, details.get("owner", "neutral")))
		rows.append({
			"id": str(territory_id),
			"name": str(details.get("name", territory_id)),
			"owner_id": owner_id,
			"owner_name": get_faction_name(owner_id),
			"is_player": owner_id == "player"
		})
	return rows

func get_player_territory_count() -> int:
	var total := 0
	for owner_id in territories.values():
		if str(owner_id) == "player":
			total += 1
	return total

func are_at_war(faction_a: String, faction_b: String) -> bool:
	for row in faction_wars:
		if (str(row.get("a", "")) == faction_a and str(row.get("b", "")) == faction_b) or (str(row.get("a", "")) == faction_b and str(row.get("b", "")) == faction_a):
			return true
	return false

func are_allied(faction_a: String, faction_b: String) -> bool:
	for row in faction_alliances:
		if (str(row.get("a", "")) == faction_a and str(row.get("b", "")) == faction_b) or (str(row.get("a", "")) == faction_b and str(row.get("b", "")) == faction_a):
			return true
	return false

func declare_war(faction_a: String, faction_b: String, reason: String = "Sınır anlaşmazlığı") -> Dictionary:
	if faction_a == faction_b or not FACTION_ORDER.has(faction_a) or not FACTION_ORDER.has(faction_b):
		return {"ok": false, "message": "Geçersiz savaş tarafı."}
	if are_at_war(faction_a, faction_b):
		return {"ok": false, "message": "Bu krallıklar zaten savaşta."}
	if are_allied(faction_a, faction_b):
		break_alliance(faction_a, faction_b)
	faction_wars.append({"a": faction_a, "b": faction_b, "days": 0})
	change_faction_relation(faction_a, faction_b, -18)
	war_cooldowns[_pair_key(faction_a, faction_b)] = 3
	return {"ok": true, "message": "%s ile %s arasında savaş başladı (%s)." % [get_faction_name(faction_a), get_faction_name(faction_b), reason]}

func make_peace(faction_a: String, faction_b: String) -> Dictionary:
	for i in range(faction_wars.size() - 1, -1, -1):
		var row: Dictionary = faction_wars[i]
		if (str(row.get("a", "")) == faction_a and str(row.get("b", "")) == faction_b) or (str(row.get("a", "")) == faction_b and str(row.get("b", "")) == faction_a):
			faction_wars.remove_at(i)
			change_faction_relation(faction_a, faction_b, 12)
			war_cooldowns[_pair_key(faction_a, faction_b)] = 4
			return {"ok": true, "message": "%s ve %s barış anlaşması imzaladı." % [get_faction_name(faction_a), get_faction_name(faction_b)]}
	return {"ok": false, "message": "Aktif savaş bulunamadı."}

func form_alliance(faction_a: String, faction_b: String) -> Dictionary:
	if faction_a == faction_b or not FACTION_ORDER.has(faction_a) or not FACTION_ORDER.has(faction_b) or are_at_war(faction_a, faction_b):
		return {"ok": false, "message": "Bu ittifak kurulamaz."}
	if are_allied(faction_a, faction_b):
		return {"ok": false, "message": "İttifak zaten yürürlükte."}
	faction_alliances.append({"a": faction_a, "b": faction_b, "days": 0})
	change_faction_relation(faction_a, faction_b, 8)
	return {"ok": true, "message": "%s ve %s arasında savunma ittifakı kuruldu." % [get_faction_name(faction_a), get_faction_name(faction_b)]}

func break_alliance(faction_a: String, faction_b: String) -> void:
	for i in range(faction_alliances.size() - 1, -1, -1):
		var row: Dictionary = faction_alliances[i]
		if (str(row.get("a", "")) == faction_a and str(row.get("b", "")) == faction_b) or (str(row.get("a", "")) == faction_b and str(row.get("b", "")) == faction_a):
			faction_alliances.remove_at(i)

func advance_ai_turn() -> Array[String]:
	# One call represents one campaign day. Every change is stored as plain data.
	campaign_day += 1
	recent_campaign_events.clear()
	for key in war_cooldowns.keys():
		war_cooldowns[key] = maxi(0, int(war_cooldowns[key]) - 1)
	for row in faction_wars:
		row["days"] = int(row.get("days", 0)) + 1
	for row in faction_alliances:
		row["days"] = int(row.get("days", 0)) + 1

	# Active wars can shift a border. Player-owned territory is never auto-taken by this simulation.
	for war_index in range(faction_wars.size() - 1, -1, -1):
		var war: Dictionary = faction_wars[war_index]
		var a := str(war.get("a", ""))
		var b := str(war.get("b", ""))
		if _campaign_rng.randf() < 0.14:
			var attack_a_wins := _campaign_rng.randf() < 0.5
			var winner := a if attack_a_wins else b
			var loser := b if attack_a_wins else a
			var available: Array[String] = []
			for territory_id in territories.keys():
				if str(territories[territory_id]) == loser:
					available.append(str(territory_id))
			if not available.is_empty():
				var captured: String = available[_campaign_rng.randi_range(0, available.size() - 1)]
				territories[captured] = winner
				recent_campaign_events.append("%s, %s bölgesini ele geçirdi." % [get_faction_name(winner), str(TERRITORY_DATA[captured].get("name", captured))])
		if int(war.get("days", 0)) >= 3 and _campaign_rng.randf() < 0.20:
			var peace: Dictionary = make_peace(a, b)
			recent_campaign_events.append(str(peace.get("message", "Savaş sona erdi.")))

	# Opportunistic AI diplomacy: hostile pairs may start wars; stable friends may ally.
	for i in range(FACTION_ORDER.size()):
		for j in range(i + 1, FACTION_ORDER.size()):
			var a: String = FACTION_ORDER[i]
			var b: String = FACTION_ORDER[j]
			var key := _pair_key(a, b)
			if are_at_war(a, b) or int(war_cooldowns.get(key, 0)) > 0:
				continue
			var relation := get_faction_relation(a, b)
			if are_allied(a, b):
				continue
			if relation <= -45 and _campaign_rng.randf() < 0.12:
				var war_result: Dictionary = declare_war(a, b, "eski düşmanlık ve sınır çekişmesi")
				if bool(war_result.get("ok", false)):
					recent_campaign_events.append(str(war_result.get("message", "")))
			elif relation >= 42 and _campaign_rng.randf() < 0.06:
				var alliance_result: Dictionary = form_alliance(a, b)
				if bool(alliance_result.get("ok", false)):
					recent_campaign_events.append(str(alliance_result.get("message", "")))
	if recent_campaign_events.is_empty():
		recent_campaign_events.append("Kampanya günü %d: sınır devriyeleri ve elçiler hareketlerini sürdürüyor." % campaign_day)
	return recent_campaign_events.duplicate()

func get_campaign_status_text() -> String:
	var war_names: Array[String] = []
	for row in faction_wars:
		war_names.append("%s ↔ %s" % [get_faction_name(str(row.get("a", ""))), get_faction_name(str(row.get("b", "")))])
	var alliance_names: Array[String] = []
	for row in faction_alliances:
		alliance_names.append("%s + %s" % [get_faction_name(str(row.get("a", ""))), get_faction_name(str(row.get("b", "")))])
	return "KAMPANYA GÜNÜ %d\nSavaşlar: %s\nİttifaklar: %s" % [campaign_day, ", ".join(PackedStringArray(war_names)) if not war_names.is_empty() else "yok", ", ".join(PackedStringArray(alliance_names)) if not alliance_names.is_empty() else "yok"]

func _pair_key(a: String, b: String) -> String:
	return "%s|%s" % ([a, b] if a < b else [b, a])

func _normalize_faction(raw_id: String) -> String:
	if raw_id == "bandit" or raw_id == "blackseal":
		return "black_seal"
	return raw_id
