extends Node3D

# Simple ballistic visual projectile used by the siege catapult.
var siege_manager: Variant = null
var target_position: Vector3 = Vector3.ZERO
var damage: float = 220.0
var velocity: Vector3 = Vector3.ZERO
var elapsed: float = 0.0
var flight_time: float = 1.8
var gravity: float = 19.0
var _impacted: bool = false

func configure(manager: Variant, origin: Vector3, destination: Vector3, impact_damage: float = 220.0) -> void:
	siege_manager = manager
	global_position = origin
	target_position = destination
	damage = impact_damage
	var flat_distance := Vector2(destination.x - origin.x, destination.z - origin.z).length()
	flight_time = clampf(flat_distance / 17.0, 1.25, 2.6)
	var offset := destination - origin
	velocity = Vector3(offset.x / flight_time, (offset.y + 0.5 * gravity * flight_time * flight_time) / flight_time, offset.z / flight_time)

func _ready() -> void:
	var mesh := SphereMesh.new()
	mesh.radius = 0.62
	mesh.height = 1.24
	var stone := MeshInstance3D.new()
	stone.name = "CatapultStone"
	stone.mesh = mesh
	var material := StandardMaterial3D.new()
	material.albedo_color = Color("#555657")
	material.roughness = 0.96
	stone.material_override = material
	add_child(stone)

	var band_mesh := TorusMesh.new()
	band_mesh.inner_radius = 0.47
	band_mesh.outer_radius = 0.53
	var band := MeshInstance3D.new()
	band.name = "ProjectileIronBand"
	band.mesh = band_mesh
	var band_mat := StandardMaterial3D.new()
	band_mat.albedo_color = Color("#716044")
	band_mat.metallic = 0.5
	band_mat.roughness = 0.7
	band.material_override = band_mat
	add_child(band)

func _process(delta: float) -> void:
	if _impacted:
		return
	elapsed += delta
	velocity.y -= gravity * delta
	global_position += velocity * delta
	if velocity.length_squared() > 0.1:
		look_at(global_position + velocity.normalized(), Vector3.UP)
	if elapsed >= flight_time:
		_impacted = true
		if is_instance_valid(siege_manager) and siege_manager.has_method("on_catapult_impact"):
			siege_manager.on_catapult_impact(target_position, damage)
		queue_free()
