extends CharacterBody3D

# Distinct stylized fantasy fauna built from original procedural meshes.
var game_ref: Variant = null
var world_id: String = ""
var species: String = "wolf"
var display_name: String = "Orman Kurdu"
var team: int = 1
var faction_id: String = ""
var max_health: float = 60.0
var health: float = 60.0
var move_speed: float = 3.0
var attack_damage: float = 12.0
var attack_range: float = 1.8
var aggro_range: float = 22.0
var reward_xp: int = 22
var reward_gold_min: int = 7
var reward_gold_max: int = 16
var creature_size: float = 1.0
var attack_cooldown: float = 0.0
var gravity_strength: float = 24.0
var home_position: Vector3 = Vector3.ZERO
var wander_target: Vector3 = Vector3.ZERO
var wander_timer: float = 0.0
var visual_root: Node3D
var health_label: Label3D
var blocking: bool = false
var _rng := RandomNumberGenerator.new()

func _ready() -> void:
	add_to_group("wild_creatures")
	add_to_group("hostile_targets")
	_rng.randomize()
	home_position = global_position
	_configure_species()
	health = max_health
	collision_layer = 1
	collision_mask = 1
	var collision := CollisionShape3D.new()
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.38 * creature_size
	capsule.height = maxf(1.35 * creature_size, 1.1)
	collision.shape = capsule
	collision.position.y = capsule.height * 0.5
	add_child(collision)
	visual_root = Node3D.new()
	visual_root.name = "CreatureVisual"
	visual_root.scale = Vector3.ONE * creature_size
	add_child(visual_root)
	_build_model()
	health_label = Label3D.new()
	health_label.name = "CreatureNameplate"
	health_label.text = display_name
	health_label.position = Vector3(0, 2.2 * creature_size, 0)
	health_label.font_size = 25
	health_label.outline_size = 7
	health_label.outline_modulate = Color(0.015, 0.02, 0.03, 0.95)
	health_label.modulate = Color("#f0c3ae")
	health_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	add_child(health_label)

func _configure_species() -> void:
	match species:
		"wolf":
			display_name = "Kızıl Orman Kurdu"
			max_health = 58.0
			move_speed = 4.2
			attack_damage = 12.0
			attack_range = 1.65
			aggro_range = 26.0
			reward_xp = 24
			reward_gold_min = 8
			reward_gold_max = 18
			creature_size = 0.9
		"skeleton":
			display_name = "Kadim İskelet"
			max_health = 94.0
			move_speed = 2.6
			attack_damage = 18.0
			attack_range = 1.9
			aggro_range = 30.0
			reward_xp = 42
			reward_gold_min = 18
			reward_gold_max = 34
			creature_size = 1.0
		"spider":
			display_name = "Mağara Örümceği"
			max_health = 52.0
			move_speed = 3.6
			attack_damage = 11.0
			attack_range = 1.5
			aggro_range = 23.0
			reward_xp = 28
			reward_gold_min = 10
			reward_gold_max = 22
			creature_size = 0.82
		"bog_troll":
			display_name = "Bataklık Devi"
			max_health = 235.0
			move_speed = 1.75
			attack_damage = 29.0
			attack_range = 2.5
			aggro_range = 34.0
			reward_xp = 105
			reward_gold_min = 45
			reward_gold_max = 74
			creature_size = 1.55
		"wraith":
			display_name = "Kül Hayaleti"
			max_health = 112.0
			move_speed = 3.1
			attack_damage = 21.0
			attack_range = 1.85
			aggro_range = 28.0
			reward_xp = 62
			reward_gold_min = 24
			reward_gold_max = 42
			creature_size = 1.08
		"drake":
			display_name = "Küçük Ejderha"
			max_health = 165.0
			move_speed = 3.45
			attack_damage = 25.0
			attack_range = 2.25
			aggro_range = 36.0
			reward_xp = 92
			reward_gold_min = 38
			reward_gold_max = 68
			creature_size = 1.18

func _process(delta: float) -> void:
	attack_cooldown = maxf(0.0, attack_cooldown - delta)
	if is_instance_valid(visual_root):
		var idle_bob := 0.035 * sin(Time.get_ticks_msec() * 0.002 + float(get_instance_id() % 13))
		if species == "wraith":
			visual_root.position.y = 0.55 + idle_bob
		else:
			visual_root.position.y = idle_bob

func _physics_process(delta: float) -> void:
	if health <= 0.0:
		return
	if not is_on_floor():
		velocity.y -= gravity_strength * delta
	elif velocity.y < 0.0:
		velocity.y = -0.5
	var player: Variant = null
	if is_instance_valid(game_ref) and is_instance_valid(game_ref.player_unit):
		player = game_ref.player_unit
	if player != null and player.health > 0.0:
		var offset: Vector3 = player.global_position - global_position
		offset.y = 0.0
		var distance := offset.length()
		if distance <= aggro_range:
			if distance > attack_range * 0.9:
				var direction := offset.normalized()
				velocity.x = direction.x * move_speed
				velocity.z = direction.z * move_speed
				if direction.length() > 0.1:
					look_at(global_position + direction, Vector3.UP)
			else:
				velocity.x = move_toward(velocity.x, 0.0, move_speed * 5.0 * delta)
				velocity.z = move_toward(velocity.z, 0.0, move_speed * 5.0 * delta)
				if attack_cooldown <= 0.0:
					attack_cooldown = 1.35 if species == "bog_troll" else 1.0
					player.receive_damage(attack_damage, self)
		else:
			_wander(delta)
	else:
		_wander(delta)
	move_and_slide()

func _wander(delta: float) -> void:
	wander_timer -= delta
	if wander_timer <= 0.0:
		wander_timer = _rng.randf_range(2.0, 5.0)
		wander_target = home_position + Vector3(_rng.randf_range(-5.5, 5.5), 0, _rng.randf_range(-5.5, 5.5))
	var offset := wander_target - global_position
	offset.y = 0.0
	if offset.length() > 0.75 and global_position.distance_to(home_position) < 8.0:
		var direction := offset.normalized()
		velocity.x = direction.x * move_speed * 0.3
		velocity.z = direction.z * move_speed * 0.3
		look_at(global_position + direction, Vector3.UP)
	else:
		velocity.x = move_toward(velocity.x, 0.0, move_speed * delta)
		velocity.z = move_toward(velocity.z, 0.0, move_speed * delta)

func receive_damage(amount: float, attacker: Variant = null) -> void:
	if health <= 0.0:
		return
	var actual_damage := amount
	if blocking:
		actual_damage *= 0.82
	health = maxf(0.0, health - actual_damage)
	if is_instance_valid(health_label):
		health_label.text = "%s  %d/%d" % [display_name, roundi(health), roundi(max_health)]
		health_label.modulate = Color("#ffb4a2")
		var flash_tween := create_tween()
		flash_tween.tween_property(health_label, "modulate", Color("#f0c3ae"), 0.22)
		_spawn_damage_number(roundi(actual_damage))
	if health <= 0.0:
		_die()

func _spawn_damage_number(amount: int) -> void:
	var popup := Label3D.new()
	popup.text = "-%d" % amount
	popup.font_size = 34
	popup.outline_size = 8
	popup.modulate = Color("#ffd5a1")
	popup.position = Vector3(_rng.randf_range(-0.25, 0.25), 2.3 * creature_size, 0)
	popup.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	add_child(popup)
	var tween := create_tween()
	tween.tween_property(popup, "position", popup.position + Vector3(0, 1.0, 0), 0.55)
	tween.parallel().tween_property(popup, "modulate:a", 0.0, 0.55)
	tween.finished.connect(func() -> void:
		if is_instance_valid(popup):
			popup.queue_free())

func _die() -> void:
	set_physics_process(false)
	set_process(false)
	collision_layer = 0
	collision_mask = 0
	if is_instance_valid(game_ref):
		game_ref.on_creature_died(self)
	queue_free()

func _build_model() -> void:
	match species:
		"wolf":
			_build_wolf()
		"skeleton":
			_build_skeleton()
		"spider":
			_build_spider()
		"bog_troll":
			_build_troll()
		"wraith":
			_build_wraith()
		"drake":
			_build_drake()

func _build_wolf() -> void:
	var fur := _mat(Color("#713f32"), 0.96)
	var fur_light := _mat(Color("#a56b4b"), 0.92)
	var dark := _mat(Color("#352825"), 0.8)
	var eye := _glow_mat(Color("#ff5f4e"))
	_add_sphere("WolfTorso", 0.8, Vector3(0, 0.82, 0.05), fur, Vector3(0.78, 0.62, 1.28))
	_add_sphere("WolfShoulders", 0.57, Vector3(0, 0.91, -0.62), fur_light, Vector3(0.85, 0.85, 0.7))
	_add_sphere("WolfHead", 0.43, Vector3(0, 1.14, -1.02), fur, Vector3(0.8, 0.72, 0.82))
	_add_sphere("WolfMuzzle", 0.23, Vector3(0, 0.99, -1.39), fur_light, Vector3(0.68, 0.55, 0.78))
	_add_sphere("WolfNose", 0.1, Vector3(0, 1.01, -1.56), dark)
	for side in [-1.0, 1.0]:
		_add_cylinder("WolfEar", 0.015, 0.16, 0.38, Vector3(side * 0.25, 1.51, -0.98), dark, Vector3(0.0, 0.0, side * 0.12))
		_add_sphere("WolfEye", 0.075, Vector3(side * 0.27, 1.2, -1.31), eye)
		for z in [-0.65, 0.78]:
			_add_capsule("WolfLeg", 0.7, 0.13, Vector3(side * 0.43, 0.38, z), dark)
	_add_capsule("WolfTail", 0.75, 0.12, Vector3(0, 1.05, 1.14), fur_light, Vector3(0.8, 0, 0))

func _build_skeleton() -> void:
	var bone := _mat(Color("#c8c5b4"), 0.85)
	var dark_bone := _mat(Color("#78796f"), 0.9)
	var cloth := _mat(Color("#312b38"), 0.95)
	var eye := _glow_mat(Color("#c07cff"))
	_add_capsule("SkeletonRibcage", 0.74, 0.28, Vector3(0, 1.12, 0), bone)
	_add_box("RibLineOne", Vector3(0.58, 0.08, 0.18), Vector3(0, 1.32, -0.2), dark_bone)
	_add_box("RibLineTwo", Vector3(0.54, 0.08, 0.18), Vector3(0, 1.12, -0.2), dark_bone)
	_add_box("RibLineThree", Vector3(0.48, 0.08, 0.18), Vector3(0, 0.92, -0.2), dark_bone)
	_add_sphere("SkeletonSkull", 0.25, Vector3(0, 1.78, 0), bone)
	_add_box("SkeletonJaw", Vector3(0.34, 0.13, 0.28), Vector3(0, 1.62, -0.08), dark_bone)
	for side in [-1.0, 1.0]:
		_add_sphere("EyeSocketGlow", 0.07, Vector3(side * 0.105, 1.81, -0.2), eye)
		_add_capsule("UpperArmBone", 0.58, 0.09, Vector3(side * 0.42, 1.22, 0), bone, Vector3(0, 0, side * -0.28))
		_add_capsule("ForearmBone", 0.55, 0.08, Vector3(side * 0.48, 0.82, -0.03), bone, Vector3(0, 0, side * 0.14))
		_add_capsule("FemurBone", 0.5, 0.11, Vector3(side * 0.17, 0.53, 0), bone)
		_add_capsule("ShinBone", 0.46, 0.08, Vector3(side * 0.17, 0.19, -0.03), bone)
	_add_box("TatteredCloak", Vector3(0.64, 0.86, 0.1), Vector3(0, 1.02, 0.23), cloth)
	_add_box("RustySwordBlade", Vector3(0.07, 0.78, 0.05), Vector3(0.62, 1.08, -0.1), dark_bone)

func _build_spider() -> void:
	var shell := _mat(Color("#293c41"), 0.5, 0.2)
	var belly := _mat(Color("#5c374a"), 0.58, 0.08)
	var leg_mat := _mat(Color("#242a31"), 0.68)
	var eye := _glow_mat(Color("#ff453d"))
	_add_sphere("SpiderAbdomen", 0.68, Vector3(0, 0.55, 0.37), belly, Vector3(1.0, 0.82, 1.1))
	_add_sphere("SpiderCarapace", 0.47, Vector3(0, 0.62, -0.38), shell, Vector3(1.0, 0.65, 0.9))
	_add_sphere("SpiderHead", 0.28, Vector3(0, 0.48, -0.72), shell)
	for side in [-1.0, 1.0]:
		for row in range(4):
			var z := -0.55 + float(row) * 0.34
			var upper := _add_box("SpiderLegUpper", Vector3(0.9, 0.12, 0.13), Vector3(side * 0.73, 0.52, z), leg_mat)
			upper.rotation.z = side * -0.34
			var lower := _add_box("SpiderLegLower", Vector3(0.78, 0.10, 0.11), Vector3(side * 1.25, 0.3, z + 0.12), leg_mat)
			lower.rotation.z = side * 0.34
		for eye_i in range(3):
			_add_sphere("SpiderEye", 0.055, Vector3(side * (0.1 + float(eye_i) * 0.13), 0.53, -0.94), eye)

func _build_troll() -> void:
	var skin := _mat(Color("#53694a"), 0.97)
	var shade := _mat(Color("#394e3b"), 0.94)
	var leather := _mat(Color("#44332c"), 0.96)
	var tusk := _mat(Color("#e0d0a7"), 0.5)
	var eye := _glow_mat(Color("#f3a64e"))
	_add_capsule("TrollTorso", 1.45, 0.6, Vector3(0, 1.35, 0), skin)
	_add_sphere("TrollBelly", 0.58, Vector3(0, 1.1, -0.23), skin, Vector3(1.0, 1.1, 0.7))
	_add_sphere("TrollHead", 0.46, Vector3(0, 2.25, -0.06), shade)
	_add_sphere("TrollJaw", 0.31, Vector3(0, 2.08, -0.28), skin)
	for side in [-1.0, 1.0]:
		_add_capsule("TrollLongArm", 1.08, 0.23, Vector3(side * 0.76, 1.45, -0.02), skin, Vector3(0, 0, side * -0.12))
		_add_capsule("TrollLeg", 0.8, 0.24, Vector3(side * 0.34, 0.4, 0.04), shade)
		_add_sphere("TrollEye", 0.085, Vector3(side * 0.18, 2.3, -0.45), eye)
		_add_cylinder("TrollTusk", 0.015, 0.1, 0.38, Vector3(side * 0.23, 2.05, -0.42), tusk, Vector3(0, 0, side * 0.1))
	_add_box("TrollHideBelt", Vector3(1.0, 0.22, 0.75), Vector3(0, 0.88, 0), leather)
	_add_sphere("TrollShoulderPad", 0.36, Vector3(-0.62, 1.92, 0), leather)

func _build_wraith() -> void:
	var cloak := _mat(Color("#302d4c"), 0.55, 0.1)
	var shadow := _mat(Color("#171d32"), 0.42, 0.0)
	var soul := _glow_mat(Color("#8a7dff"))
	_add_cylinder("WraithShroud", 0.12, 0.68, 1.6, Vector3(0, 0.95, 0), cloak)
	_add_sphere("WraithShoulders", 0.55, Vector3(0, 1.55, 0), cloak, Vector3(1.1, 0.66, 0.7))
	_add_sphere("WraithFaceVoid", 0.31, Vector3(0, 1.76, -0.12), shadow)
	for side in [-1.0, 1.0]:
		_add_sphere("WraithEye", 0.085, Vector3(side * 0.13, 1.79, -0.38), soul)
		var wisp := _add_cylinder("WraithSpectralRibbon", 0.02, 0.18, 1.0, Vector3(side * 0.56, 1.15, 0.1), soul, Vector3(0, 0, side * 0.6))
		wisp.rotation.x = 0.3
	_add_sphere("WraithSoulCore", 0.2, Vector3(0, 1.12, -0.36), soul)
	var light := OmniLight3D.new()
	light.position = Vector3(0, 1.25, 0)
	light.light_color = Color("#7569ff")
	light.light_energy = 0.75
	light.omni_range = 5.5
	visual_root.add_child(light)

func _build_drake() -> void:
	var scale_mat := _mat(Color("#5c433f"), 0.58, 0.08)
	var belly := _mat(Color("#c18b57"), 0.75)
	var wing := _mat(Color("#3d303a"), 0.65)
	var horn := _mat(Color("#c6b89a"), 0.55)
	var eye := _glow_mat(Color("#ffb84e"))
	_add_sphere("DrakeBody", 0.58, Vector3(0, 0.94, 0), scale_mat, Vector3(1.0, 0.83, 1.35))
	_add_sphere("DrakeBelly", 0.4, Vector3(0, 0.8, -0.15), belly, Vector3(0.8, 0.7, 1.0))
	_add_sphere("DrakeNeck", 0.3, Vector3(0, 1.25, -0.78), scale_mat, Vector3(0.75, 0.8, 0.9))
	_add_sphere("DrakeHead", 0.36, Vector3(0, 1.48, -1.05), scale_mat)
	_add_sphere("DrakeSnout", 0.2, Vector3(0, 1.36, -1.38), belly, Vector3(0.85, 0.6, 0.9))
	for side in [-1.0, 1.0]:
		_add_sphere("DrakeEye", 0.075, Vector3(side * 0.24, 1.57, -1.29), eye)
		_add_cylinder("DrakeHorn", 0.015, 0.1, 0.42, Vector3(side * 0.22, 1.8, -0.95), horn, Vector3(0, 0, side * -0.4))
		_add_capsule("DrakeLeg", 0.48, 0.12, Vector3(side * 0.4, 0.4, -0.45), scale_mat)
		_add_capsule("DrakeLeg", 0.48, 0.12, Vector3(side * 0.4, 0.4, 0.54), scale_mat)
		var wing_piece := _add_box("DrakeWing", Vector3(1.05, 0.12, 0.84), Vector3(side * 0.69, 1.39, 0.1), wing)
		wing_piece.rotation.z = side * -0.55
		wing_piece.rotation.x = -0.18
	_add_capsule("DrakeTail", 1.1, 0.12, Vector3(0, 0.89, 1.15), scale_mat, Vector3(0.5, 0, 0))
	_add_cylinder("DrakeTailSpade", 0.02, 0.24, 0.45, Vector3(0, 1.22, 1.65), horn)

func _mat(color: Color, roughness: float = 0.9, metallic: float = 0.0) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = roughness
	m.metallic = metallic
	return m

func _glow_mat(color: Color) -> StandardMaterial3D:
	var m := _mat(color, 0.28, 0.08)
	m.emission_enabled = true
	m.emission = color
	m.emission_energy_multiplier = 1.65
	return m

func _add_sphere(node_name: String, radius: float, at: Vector3, material: Material, mesh_scale: Vector3 = Vector3.ONE) -> MeshInstance3D:
	var mesh := SphereMesh.new()
	mesh.radius = radius
	mesh.height = radius * 2.0
	var instance := MeshInstance3D.new()
	instance.name = node_name
	instance.mesh = mesh
	instance.material_override = material
	instance.position = at
	instance.scale = mesh_scale
	visual_root.add_child(instance)
	return instance

func _add_capsule(node_name: String, height: float, radius: float, at: Vector3, material: Material, rot: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	var mesh := CapsuleMesh.new()
	mesh.height = height
	mesh.radius = radius
	var instance := MeshInstance3D.new()
	instance.name = node_name
	instance.mesh = mesh
	instance.material_override = material
	instance.position = at
	instance.rotation = rot
	visual_root.add_child(instance)
	return instance

func _add_box(node_name: String, dimensions: Vector3, at: Vector3, material: Material) -> MeshInstance3D:
	var mesh := BoxMesh.new()
	mesh.size = dimensions
	var instance := MeshInstance3D.new()
	instance.name = node_name
	instance.mesh = mesh
	instance.material_override = material
	instance.position = at
	visual_root.add_child(instance)
	return instance

func _add_cylinder(node_name: String, top_radius: float, bottom_radius: float, height: float, at: Vector3, material: Material, rot: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	var mesh := CylinderMesh.new()
	mesh.top_radius = top_radius
	mesh.bottom_radius = bottom_radius
	mesh.height = height
	var instance := MeshInstance3D.new()
	instance.name = node_name
	instance.mesh = mesh
	instance.material_override = material
	instance.position = at
	instance.rotation = rot
	visual_root.add_child(instance)
	return instance
