extends Node3D

var game_ref: Variant = null
var chest_name: String = "Gezgin Sandığı"
var chest_id: String = ""
var gold_reward: int = 35
var xp_reward: int = 15
var opened: bool = false
var lid: MeshInstance3D
var prompt_label: Label3D

func _ready() -> void:
	add_to_group("interactables")
	add_to_group("loot_chests")
	_build_chest()

func interact(game: Variant) -> void:
	if opened:
		if is_instance_valid(game):
			game.show_notice("Bu sandık daha önce açıldı.")
		return
	opened = true
	if is_instance_valid(lid):
		var tween := create_tween()
		tween.tween_property(lid, "rotation:x", -0.9, 0.35)
	if is_instance_valid(prompt_label):
		prompt_label.text = "BOŞ SANDIK"
	if is_instance_valid(game):
		game.open_loot_chest(self)

func _build_chest() -> void:
	var wood := _mat(Color("#5b3925"), 0.9)
	var dark_wood := _mat(Color("#302820"), 0.92)
	var iron := _mat(Color("#657078"), 0.35, 0.55)
	var gold := _mat(Color("#d9ad4e"), 0.28, 0.48)
	_add_box("ChestBase", Vector3(1.45, 0.78, 0.95), Vector3(0, 0.43, 0), wood)
	_add_box("ChestFrontBand", Vector3(1.49, 0.11, 0.08), Vector3(0, 0.48, -0.49), iron)
	_add_box("ChestLeftBand", Vector3(0.08, 0.8, 0.98), Vector3(-0.5, 0.43, 0), iron)
	_add_box("ChestRightBand", Vector3(0.08, 0.8, 0.98), Vector3(0.5, 0.43, 0), iron)
	var lid_mesh := BoxMesh.new()
	lid_mesh.size = Vector3(1.47, 0.28, 0.98)
	lid = MeshInstance3D.new()
	lid.name = "ChestLid"
	lid.mesh = lid_mesh
	lid.material_override = dark_wood
	lid.position = Vector3(0, 0.91, 0.01)
	add_child(lid)
	_add_box("ChestLockPlate", Vector3(0.25, 0.28, 0.07), Vector3(0, 0.7, -0.52), gold)
	_add_sphere("ChestLockGem", 0.085, Vector3(0, 0.72, -0.57), gold)
	var collision := StaticBody3D.new()
	collision.name = "ChestCollision"
	add_child(collision)
	var collision_shape := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = Vector3(1.55, 1.12, 1.05)
	collision_shape.shape = box
	collision_shape.position.y = 0.55
	collision.add_child(collision_shape)
	prompt_label = Label3D.new()
	prompt_label.name = "ChestName"
	prompt_label.text = chest_name
	prompt_label.position = Vector3(0, 1.65, 0)
	prompt_label.font_size = 25
	prompt_label.outline_size = 7
	prompt_label.outline_modulate = Color(0.02, 0.025, 0.03, 0.95)
	prompt_label.modulate = Color("#f3d18d")
	prompt_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	add_child(prompt_label)
	if opened:
		lid.rotation.x = -0.9
		prompt_label.text = "BOŞ SANDIK"

func _mat(color: Color, roughness: float = 0.9, metallic: float = 0.0) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = roughness
	m.metallic = metallic
	return m

func _add_box(node_name: String, dimensions: Vector3, at: Vector3, material: Material) -> MeshInstance3D:
	var mesh := BoxMesh.new()
	mesh.size = dimensions
	var instance := MeshInstance3D.new()
	instance.name = node_name
	instance.mesh = mesh
	instance.material_override = material
	instance.position = at
	add_child(instance)
	return instance

func _add_sphere(node_name: String, radius: float, at: Vector3, material: Material) -> MeshInstance3D:
	var mesh := SphereMesh.new()
	mesh.radius = radius
	mesh.height = radius * 2.0
	var instance := MeshInstance3D.new()
	instance.name = node_name
	instance.mesh = mesh
	instance.material_override = material
	instance.position = at
	add_child(instance)
	return instance
