extends Node3D

var target: Variant = null
var attacker: Variant = null
var damage: float = 12.0
var speed: float = 25.0
var lifetime: float = 0.0

func _ready() -> void:
	var shaft_mesh := BoxMesh.new()
	shaft_mesh.size = Vector3(0.025, 0.025, 0.72)
	var shaft := MeshInstance3D.new()
	shaft.name = "ArrowShaft"
	shaft.mesh = shaft_mesh
	var shaft_material := StandardMaterial3D.new()
	shaft_material.albedo_color = Color("#8b6840")
	shaft_material.roughness = 0.72
	shaft.material_override = shaft_material
	add_child(shaft)

	var tip_mesh := ConeMesh.new()
	tip_mesh.top_radius = 0.0
	tip_mesh.bottom_radius = 0.055
	tip_mesh.height = 0.16
	var tip := MeshInstance3D.new()
	tip.name = "IronArrowhead"
	tip.mesh = tip_mesh
	tip.position = Vector3(0.0, 0.0, -0.39)
	tip.rotation.x = -PI * 0.5
	var tip_material := StandardMaterial3D.new()
	tip_material.albedo_color = Color("#b9c4ca")
	tip_material.metallic = 0.72
	tip_material.roughness = 0.28
	tip.material_override = tip_material
	add_child(tip)

func _process(delta: float) -> void:
	lifetime += delta
	if lifetime > 4.0 or not is_instance_valid(target) or not target is Node3D:
		queue_free()
		return
	if float(target.health) <= 0.0:
		queue_free()
		return
	var destination: Vector3 = target.global_position + Vector3(0.0, 1.0, 0.0)
	var offset := destination - global_position
	if offset.length() <= 0.75:
		if target.has_method("receive_damage") and float(target.health) > 0.0:
			target.receive_damage(damage, attacker)
		queue_free()
		return
	var direction := offset.normalized()
	global_position += direction * speed * delta
	look_at(global_position + direction, Vector3.UP)
