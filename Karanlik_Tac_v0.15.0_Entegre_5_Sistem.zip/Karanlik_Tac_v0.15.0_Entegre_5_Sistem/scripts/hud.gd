extends CanvasLayer

signal move_changed(value: Vector2)
signal attack_pressed
signal block_changed(value: bool)
signal troops_pressed
signal interact_pressed
signal save_pressed
signal load_pressed
signal inventory_pressed
signal potion_pressed
signal save_slots_pressed
signal save_slot_selected(slot_id: int)
signal save_slot_save_pressed
signal save_slot_load_pressed
signal crafting_pressed
signal equipment_pressed
signal army_panel_pressed
signal army_order_pressed(order_id: String)
signal army_formation_pressed(formation_id: String)
signal army_recruit_pressed(class_id: String)
signal kingdom_panel_pressed
signal kingdom_pledge_pressed(faction_id: String)
signal settlement_panel_pressed
signal settlement_action_pressed(action_id: String)
signal quest_journal_pressed
signal companion_panel_pressed
signal skills_panel_pressed
signal skill_purchase_pressed(skill_id: String)
signal graphics_panel_pressed
signal graphics_quality_selected(quality_id: String)
signal siege_command_pressed(command_id: String)
signal weapon_cycle_pressed
signal sprint_changed(is_sprinting: bool)
signal craft_recipe_pressed(recipe_id: String)
signal modal_open_changed(is_open: bool)
signal restart_pressed
signal story_choice_pressed(choice_id: String)

const JoystickScript = preload("res://scripts/virtual_joystick.gd")
const RadarScript = preload("res://scripts/world_radar.gd")

var root_control: Control
var joystick: Control
var health_bar: ProgressBar
var xp_bar: ProgressBar
var stamina_bar: ProgressBar
var health_text: Label
var mission_label: Label
var stats_label: Label
var status_label: Label
var region_label: Label
var radar: Control
var attack_button: Button
var block_button: Button
var sprint_button: Button
var troops_button: Button
var interact_button: Button
var end_overlay: Control
var inventory_panel: Control
var inventory_text: Label
var inventory_potion_button: Button
var inventory_open: bool = false
var crafting_panel: Control
var crafting_open: bool = false
var craft_rows: Dictionary = {}
var equipment_panel: Control
var equipment_open: bool = false
var equipment_text: Label
var save_slots_panel: Control
var save_slots_open: bool = false
var save_slot_buttons: Array[Button] = []
var save_slot_save_button: Button
var save_slot_load_button: Button
var selected_save_slot: int = 1
var utility_panel: Control
var army_panel: Control
var army_open: bool = false
var army_status_label: Label
var army_recruit_buttons: Dictionary = {}
var kingdom_panel: Control
var kingdom_open: bool = false
var kingdom_status_label: Label
var kingdom_territories_label: Label
var kingdom_faction_rows: Dictionary = {}
var settlement_panel: Control
var settlement_open: bool = false
var settlement_status_label: Label
var settlement_gold_label: Label
var settlement_action_buttons: Dictionary = {}
var quest_panel: Control
var quest_open: bool = false
var quest_text: Label
var companion_panel: Control
var companion_open: bool = false
var companion_text: Label
var companion_summary_label: Label
var skills_panel: Control
var skills_open: bool = false
var graphics_panel: Control
var graphics_open: bool = false
var graphics_quality_label: Label
var graphics_fps_label: Label
var graphics_quality_buttons: Dictionary = {}
var _graphics_fps_refresh_elapsed: float = 0.0
var skills_points_label: Label
var skills_status_label: Label
var skill_buttons: Dictionary = {}
var siege_panel: Control
var siege_open: bool = false
var siege_status_label: Label
var siege_catapult_button: Button
var ui_buttons: Array = []
var story_choice_panel: PanelContainer
var story_choice_open: bool = false
var story_choice_title: Label
var story_choice_detail: Label
var story_choice_buttons: Array[Button] = []

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	root_control = Control.new()
	root_control.name = "HUDRoot"
	root_control.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root_control.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(root_control)
	_build_header()
	_build_controls()
	_build_radar()
	_build_utility_buttons()
	_build_inventory_panel()
	_build_crafting_panel()
	_build_equipment_panel()
	_build_save_slots_panel()
	_build_army_panel()
	_build_kingdom_panel()
	_build_siege_panel()
	_build_settlement_panel()
	_build_quest_panel()
	_build_companion_panel()
	_build_skills_panel()
	_build_graphics_panel()
	_build_story_choice_panel()
	set_process(true)

func _build_header() -> void:
	var title := Label.new()
	title.text = "KARANLIK TAÇ  /  AÇIK DÜNYA"
	title.position = Vector2(24, 12)
	title.size = Vector2(500, 34)
	title.add_theme_font_size_override("font_size", 23)
	title.add_theme_color_override("font_color", Color("#f1d49a"))
	root_control.add_child(title)

	var health_panel := PanelContainer.new()
	health_panel.position = Vector2(22, 48)
	health_panel.size = Vector2(268, 66)
	health_panel.add_theme_stylebox_override("panel", _panel_style(Color(0.035, 0.055, 0.07, 0.9), Color("#9e834c")))
	root_control.add_child(health_panel)
	var health_column := VBoxContainer.new()
	health_column.add_theme_constant_override("separation", 4)
	health_panel.add_child(health_column)
	health_text = Label.new()
	health_text.text = "KOMUTAN  180 / 180"
	health_text.add_theme_font_size_override("font_size", 15)
	health_text.add_theme_color_override("font_color", Color("#f6e7c7"))
	health_column.add_child(health_text)
	health_bar = ProgressBar.new()
	health_bar.custom_minimum_size = Vector2(242, 18)
	health_bar.max_value = 180
	health_bar.value = 180
	health_bar.show_percentage = false
	health_bar.add_theme_stylebox_override("background", _flat_style(Color("#252d31")))
	health_bar.add_theme_stylebox_override("fill", _flat_style(Color("#b64d43")))
	health_column.add_child(health_bar)

	var xp_panel := PanelContainer.new()
	xp_panel.position = Vector2(22, 121)
	xp_panel.size = Vector2(268, 19)
	xp_panel.add_theme_stylebox_override("panel", _panel_style(Color(0.035, 0.055, 0.07, 0.86), Color("#665b89")))
	root_control.add_child(xp_panel)
	xp_bar = ProgressBar.new()
	xp_bar.max_value = 100
	xp_bar.value = 0
	xp_bar.show_percentage = false
	xp_bar.custom_minimum_size = Vector2(248, 12)
	xp_bar.add_theme_stylebox_override("background", _flat_style(Color("#252936")))
	xp_bar.add_theme_stylebox_override("fill", _flat_style(Color("#8d73ce")))
	xp_panel.add_child(xp_bar)

	stats_label = Label.new()
	var stamina_panel := PanelContainer.new()
	stamina_panel.position = Vector2(22, 144)
	stamina_panel.size = Vector2(268, 14)
	stamina_panel.add_theme_stylebox_override("panel", _panel_style(Color(0.035, 0.055, 0.07, 0.86), Color("#4d7668")))
	root_control.add_child(stamina_panel)
	stamina_bar = ProgressBar.new()
	stamina_bar.max_value = 100.0
	stamina_bar.value = 100.0
	stamina_bar.show_percentage = false
	stamina_bar.custom_minimum_size = Vector2(258, 9)
	stamina_bar.add_theme_stylebox_override("background", _flat_style(Color("#252d31")))
	stamina_bar.add_theme_stylebox_override("fill", _flat_style(Color("#6bbd8e")))
	stamina_panel.add_child(stamina_bar)
	stats_label.position = Vector2(25, 164)
	stats_label.size = Vector2(770, 28)
	stats_label.text = "SV 1  •  XP 0/100  •  ALTIN 45  •  YENİLEN 0"
	stats_label.add_theme_font_size_override("font_size", 15)
	stats_label.add_theme_color_override("font_color", Color("#e8e3d6"))
	root_control.add_child(stats_label)

	mission_label = Label.new()
	mission_label.anchor_left = 0.5
	mission_label.anchor_right = 0.5
	mission_label.offset_left = -250
	mission_label.offset_right = 250
	mission_label.offset_top = 17
	mission_label.offset_bottom = 47
	mission_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	mission_label.text = "GÖREV: YELDEĞİRMENİ KÖYÜ'NÜ BUL"
	mission_label.add_theme_font_size_override("font_size", 18)
	mission_label.add_theme_color_override("font_color", Color("#f2dfba"))
	root_control.add_child(mission_label)

	region_label = Label.new()
	region_label.anchor_left = 1.0
	region_label.anchor_right = 1.0
	region_label.offset_left = -205
	region_label.offset_right = -20
	region_label.offset_top = 13
	region_label.offset_bottom = 38
	region_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	region_label.text = "BÖLGE: SINIRLAR"
	region_label.add_theme_font_size_override("font_size", 13)
	region_label.add_theme_color_override("font_color", Color("#d4e1d8"))
	root_control.add_child(region_label)

	status_label = Label.new()
	status_label.anchor_left = 0.5
	status_label.anchor_right = 0.5
	status_label.offset_left = -280
	status_label.offset_right = 280
	status_label.anchor_top = 1.0
	status_label.anchor_bottom = 1.0
	status_label.offset_top = -37
	status_label.offset_bottom = -10
	status_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	status_label.text = ""
	status_label.add_theme_font_size_override("font_size", 15)
	status_label.add_theme_color_override("font_color", Color("#ffdf9a"))
	root_control.add_child(status_label)

func _build_controls() -> void:
	joystick = JoystickScript.new()
	joystick.name = "MovementJoystick"
	joystick.anchor_left = 0.0
	joystick.anchor_right = 0.0
	joystick.anchor_top = 1.0
	joystick.anchor_bottom = 1.0
	joystick.offset_left = 20
	joystick.offset_top = -204
	joystick.offset_right = 210
	joystick.offset_bottom = -14
	root_control.add_child(joystick)
	joystick.value_changed.connect(func(value: Vector2) -> void: move_changed.emit(value))

	attack_button = _make_button("SALDIR", -150, -118, -20, -28, Color("#8e342e"), 19)
	attack_button.pressed.connect(func() -> void: attack_pressed.emit())
	block_button = _make_button("SAVUN", -282, -91, -158, -31, Color("#40596a"), 15)
	block_button.button_down.connect(func() -> void: block_changed.emit(true))
	block_button.button_up.connect(func() -> void: block_changed.emit(false))
	sprint_button = _make_button("KOŞU", -282, -158, -158, -100, Color("#47634d"), 15)
	sprint_button.button_down.connect(func() -> void: sprint_changed.emit(true))
	sprint_button.button_up.connect(func() -> void: sprint_changed.emit(false))
	troops_button = _make_button("DESTEK", -416, -91, -290, -31, Color("#806534"), 15)
	troops_button.pressed.connect(func() -> void: troops_pressed.emit())
	interact_button = _make_button("ETKİLEŞ", -416, -158, -290, -100, Color("#3d6b5a"), 14)
	interact_button.pressed.connect(func() -> void: interact_pressed.emit())
	ui_buttons = [attack_button, block_button, sprint_button, troops_button, interact_button]

	var hint := Label.new()
	hint.anchor_left = 0.0
	hint.anchor_right = 0.0
	hint.anchor_top = 1.0
	hint.anchor_bottom = 1.0
	hint.offset_left = 22
	hint.offset_top = -238
	hint.offset_right = 350
	hint.offset_bottom = -216
	hint.text = "SOL: HAREKET  •  SAĞ: KAMERA  •  F: ETKİLEŞİM"
	hint.add_theme_font_size_override("font_size", 11)
	hint.add_theme_color_override("font_color", Color(0.9, 0.9, 0.85, 0.82))
	root_control.add_child(hint)

func _build_radar() -> void:
	radar = RadarScript.new()
	radar.name = "WorldRadar"
	radar.anchor_left = 1.0
	radar.anchor_right = 1.0
	radar.anchor_top = 0.0
	radar.anchor_bottom = 0.0
	radar.offset_left = -184
	radar.offset_right = -20
	radar.offset_top = 43
	radar.offset_bottom = 168
	root_control.add_child(radar)

func _build_utility_buttons() -> void:
	utility_panel = PanelContainer.new()
	utility_panel.name = "SaveLoadInventoryBar"
	var panel: PanelContainer = utility_panel as PanelContainer
	panel.anchor_left = 1.0
	panel.anchor_right = 1.0
	panel.anchor_top = 0.0
	panel.anchor_bottom = 0.0
	panel.offset_left = -1070
	panel.offset_right = -16
	panel.offset_top = 202
	panel.offset_bottom = 248
	panel.add_theme_stylebox_override("panel", _panel_style(Color(0.035, 0.055, 0.07, 0.88), Color("#9e834c")))
	root_control.add_child(panel)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 4)
	panel.add_child(row)
	var save_button := _make_utility_button("KAYDET", Color("#76613a"))
	save_button.pressed.connect(func() -> void: save_pressed.emit())
	row.add_child(save_button)
	var load_button := _make_utility_button("YÜKLE", Color("#405b65"))
	load_button.pressed.connect(func() -> void: load_pressed.emit())
	row.add_child(load_button)
	var bag_button := _make_utility_button("ÇANTA", Color("#4e6245"))
	bag_button.pressed.connect(func() -> void: inventory_pressed.emit())
	row.add_child(bag_button)
	var slots_button := _make_utility_button("YUVALAR", Color("#5b4a70"))
	slots_button.pressed.connect(func() -> void: save_slots_pressed.emit())
	row.add_child(slots_button)
	var army_button := _make_utility_button("ORDU", Color("#7c4f2e"))
	army_button.pressed.connect(func() -> void: army_panel_pressed.emit())
	row.add_child(army_button)
	var kingdom_button := _make_utility_button("KRALLIK", Color("#64507e"))
	kingdom_button.pressed.connect(func() -> void: kingdom_panel_pressed.emit())
	row.add_child(kingdom_button)
	var siege_button := _make_utility_button("KUŞAT", Color("#8a3f32"))
	siege_button.pressed.connect(func() -> void: toggle_siege_panel())
	row.add_child(siege_button)
	var settlement_button := _make_utility_button("ÜS", Color("#6a6343"))
	settlement_button.pressed.connect(func() -> void: settlement_panel_pressed.emit())
	row.add_child(settlement_button)
	var weapon_button := _make_utility_button("SİLAH · R", Color("#4c5878"))
	weapon_button.pressed.connect(func() -> void: weapon_cycle_pressed.emit())
	row.add_child(weapon_button)
	var quest_button := _make_utility_button("GÖREVLER", Color("#4e665b"))
	quest_button.pressed.connect(func() -> void: quest_journal_pressed.emit())
	row.add_child(quest_button)
	var companion_button := _make_utility_button("YOLDAŞ", Color("#53687a"))
	companion_button.pressed.connect(func() -> void: companion_panel_pressed.emit())
	row.add_child(companion_button)
	var skills_button := _make_utility_button("YETENEK", Color("#745d7c"))
	skills_button.pressed.connect(func() -> void: skills_panel_pressed.emit())
	row.add_child(skills_button)
	ui_buttons.append(save_button)
	ui_buttons.append(load_button)
	ui_buttons.append(bag_button)
	ui_buttons.append(slots_button)
	ui_buttons.append(army_button)
	ui_buttons.append(kingdom_button)
	ui_buttons.append(siege_button)
	ui_buttons.append(settlement_button)
	ui_buttons.append(weapon_button)
	ui_buttons.append(quest_button)
	ui_buttons.append(companion_button)
	ui_buttons.append(skills_button)
	var graphics_button := _make_utility_button("GRAFİK", Color("#586e7b"))
	graphics_button.pressed.connect(func() -> void: graphics_panel_pressed.emit())
	row.add_child(graphics_button)
	ui_buttons.append(graphics_button)

func _build_quest_panel() -> void:
	quest_panel = PanelContainer.new()
	quest_panel.name = "QuestJournalWindow"
	quest_panel.anchor_left = 0.5
	quest_panel.anchor_right = 0.5
	quest_panel.anchor_top = 0.5
	quest_panel.anchor_bottom = 0.5
	quest_panel.offset_left = -310
	quest_panel.offset_right = 310
	quest_panel.offset_top = -285
	quest_panel.offset_bottom = 285
	quest_panel.add_theme_stylebox_override("panel", _panel_style(Color("#111a20"), Color("#d3b57a")))
	quest_panel.mouse_filter = Control.MOUSE_FILTER_STOP
	quest_panel.visible = false
	root_control.add_child(quest_panel)
	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 8)
	quest_panel.add_child(column)
	var title := Label.new()
	title.text = "GÖREV DEFTERİ  /  TAHTIN GÖLGESİ"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 21)
	title.add_theme_color_override("font_color", Color("#f2d49c"))
	column.add_child(title)
	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	column.add_child(scroll)
	quest_text = Label.new()
	quest_text.text = "Görev kayıtları yükleniyor..."
	quest_text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	quest_text.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	quest_text.add_theme_font_size_override("font_size", 15)
	quest_text.add_theme_color_override("font_color", Color("#d7dfd9"))
	scroll.add_child(quest_text)
	var hint := Label.new()
	hint.text = "Hazır görevleri ilgili NPC'ye dönerek teslim et. Ana görevler sırayla açılır."
	hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	hint.add_theme_font_size_override("font_size", 12)
	hint.add_theme_color_override("font_color", Color("#c8b98f"))
	column.add_child(hint)
	var close_button := _make_panel_button("GÖREV DEFTERİNİ KAPAT", Color("#59423e"), 38)
	close_button.pressed.connect(func() -> void: toggle_quest_journal(""))
	column.add_child(close_button)

func _build_companion_panel() -> void:
	companion_panel = PanelContainer.new()
	companion_panel.name = "CompanionRosterWindow"
	companion_panel.anchor_left = 0.5
	companion_panel.anchor_right = 0.5
	companion_panel.anchor_top = 0.5
	companion_panel.anchor_bottom = 0.5
	companion_panel.offset_left = -300
	companion_panel.offset_right = 300
	companion_panel.offset_top = -270
	companion_panel.offset_bottom = 270
	companion_panel.add_theme_stylebox_override("panel", _panel_style(Color("#111a20"), Color("#9bbac8")))
	companion_panel.mouse_filter = Control.MOUSE_FILTER_STOP
	companion_panel.visible = false
	root_control.add_child(companion_panel)
	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 9)
	companion_panel.add_child(column)
	var title := Label.new()
	title.text = "YOLDAŞLAR  /  SADIK YOL ARKADAŞLARI"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 21)
	title.add_theme_color_override("font_color", Color("#c8e0e8"))
	column.add_child(title)
	companion_summary_label = Label.new()
	companion_summary_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	companion_summary_label.add_theme_font_size_override("font_size", 13)
	companion_summary_label.add_theme_color_override("font_color", Color("#d7dfd9"))
	column.add_child(companion_summary_label)
	column.add_child(HSeparator.new())
	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	column.add_child(scroll)
	companion_text = Label.new()
	companion_text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	companion_text.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	companion_text.add_theme_font_size_override("font_size", 14)
	companion_text.add_theme_color_override("font_color", Color("#d7dfd9"))
	scroll.add_child(companion_text)
	var hint := Label.new()
	hint.text = "Yoldaşları dünyada parlayan işaretlerinden bul. Yaklaş ve ETKİLEŞ'e bas; katılım ücreti gerekir."
	hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	hint.add_theme_font_size_override("font_size", 12)
	hint.add_theme_color_override("font_color", Color("#c8b98f"))
	column.add_child(hint)
	var close_button := _make_panel_button("YOLDAŞLARI KAPAT", Color("#59423e"), 38)
	close_button.pressed.connect(func() -> void: toggle_companion_panel({}))
	column.add_child(close_button)

func _build_skills_panel() -> void:
	skills_panel = PanelContainer.new()
	skills_panel.name = "SkillProgressionWindow"
	skills_panel.anchor_left = 0.5
	skills_panel.anchor_right = 0.5
	skills_panel.anchor_top = 0.5
	skills_panel.anchor_bottom = 0.5
	skills_panel.offset_left = -270
	skills_panel.offset_right = 270
	skills_panel.offset_top = -250
	skills_panel.offset_bottom = 250
	skills_panel.add_theme_stylebox_override("panel", _panel_style(Color("#171522"), Color("#b8a0d2")))
	skills_panel.mouse_filter = Control.MOUSE_FILTER_STOP
	skills_panel.visible = false
	root_control.add_child(skills_panel)
	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 10)
	skills_panel.add_child(column)
	var title := Label.new()
	title.text = "KARAKTER GELİŞİMİ  /  YETENEK AĞACI"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 21)
	title.add_theme_color_override("font_color", Color("#e0c8f1"))
	column.add_child(title)
	skills_points_label = Label.new()
	skills_points_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	skills_points_label.add_theme_font_size_override("font_size", 16)
	skills_points_label.add_theme_color_override("font_color", Color("#f2d49c"))
	column.add_child(skills_points_label)
	column.add_child(HSeparator.new())
	for skill_id in ["combat", "leadership", "survival"]:
		var label := Label.new()
		match skill_id:
			"combat": label.text = "SAVAŞ USTALIĞI\nHer seviyede +%8 saldırı hasarı. En fazla 3 seviye."
			"leadership": label.text = "LİDERLİK\nHer seviyede ordu kapasitesi +2 asker. En fazla 3 seviye."
			_: label.text = "HAYATTA KALMA\nHer seviyede +15 azami can ve %4 hasar azaltma. En fazla 3 seviye."
		label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		label.add_theme_font_size_override("font_size", 14)
		label.add_theme_color_override("font_color", Color("#d7dfd9"))
		column.add_child(label)
		var id_for_callback := skill_id
		var button := _make_panel_button("YETENEK PUANIYLA GELİŞTİR", Color("#5f4c75"), 44)
		button.pressed.connect(func() -> void: skill_purchase_pressed.emit(id_for_callback))
		column.add_child(button)
		skill_buttons[skill_id] = button
	skills_status_label = Label.new()
	skills_status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	skills_status_label.add_theme_font_size_override("font_size", 12)
	skills_status_label.add_theme_color_override("font_color", Color("#c8b98f"))
	column.add_child(skills_status_label)
	var close_button := _make_panel_button("YETENEKLERİ KAPAT", Color("#59423e"), 38)
	close_button.pressed.connect(func() -> void: toggle_skills_panel({}))
	column.add_child(close_button)

func _build_graphics_panel() -> void:
	graphics_panel = PanelContainer.new()
	graphics_panel.name = "GraphicsPerformanceWindow"
	graphics_panel.anchor_left = 0.5
	graphics_panel.anchor_right = 0.5
	graphics_panel.anchor_top = 0.5
	graphics_panel.anchor_bottom = 0.5
	graphics_panel.offset_left = -270
	graphics_panel.offset_right = 270
	graphics_panel.offset_top = -215
	graphics_panel.offset_bottom = 215
	graphics_panel.add_theme_stylebox_override("panel", _panel_style(Color("#172126"), Color("#9fb8bd")))
	graphics_panel.mouse_filter = Control.MOUSE_FILTER_STOP
	graphics_panel.visible = false
	root_control.add_child(graphics_panel)
	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 9)
	graphics_panel.add_child(column)
	var title := Label.new()
	title.text = "GRAFİK VE PERFORMANS"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 21)
	title.add_theme_color_override("font_color", Color("#d6e9e7"))
	column.add_child(title)
	var help := Label.new()
	help.text = "Tabletin gücüne göre görsel kaliteyi seç. Ayar hemen uygulanır ve bu cihazda saklanır."
	help.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	help.add_theme_font_size_override("font_size", 13)
	help.add_theme_color_override("font_color", Color("#d1d8d6"))
	column.add_child(help)
	column.add_child(HSeparator.new())
	var presets: Array[Dictionary] = [
		{"id": "low", "text": "DÜŞÜK  •  GÖLGE/EFEKT AZ  •  30 FPS", "color": Color("#4e6658")},
		{"id": "balanced", "text": "DENGELİ  •  ÖNERİLEN  •  45 FPS", "color": Color("#466574")},
		{"id": "high", "text": "YÜKSEK  •  TAM ATMOSFER  •  60 FPS", "color": Color("#765d40")}
	]
	for preset in presets:
		var quality_id := str(preset["id"])
		var id_for_callback := quality_id
		var button := _make_panel_button(str(preset["text"]), preset["color"], 44)
		button.pressed.connect(func() -> void: graphics_quality_selected.emit(id_for_callback))
		column.add_child(button)
		graphics_quality_buttons[quality_id] = button
	graphics_quality_label = Label.new()
	graphics_quality_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	graphics_quality_label.add_theme_font_size_override("font_size", 14)
	graphics_quality_label.add_theme_color_override("font_color", Color("#f1d49a"))
	graphics_quality_label.text = "Etkin kalite: DENGELİ"
	column.add_child(graphics_quality_label)
	graphics_fps_label = Label.new()
	graphics_fps_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	graphics_fps_label.add_theme_font_size_override("font_size", 13)
	graphics_fps_label.add_theme_color_override("font_color", Color("#a9c8b9"))
	graphics_fps_label.text = "FPS: ölçülüyor • Cihaz: %s" % OS.get_name()
	column.add_child(graphics_fps_label)
	var close_button := _make_panel_button("KAPAT", Color("#59423e"), 38)
	close_button.pressed.connect(func() -> void: toggle_graphics_panel())
	column.add_child(close_button)

func toggle_graphics_panel() -> void:
	var next_visible := not graphics_open
	_set_all_modals_closed()
	graphics_open = next_visible
	if is_instance_valid(graphics_panel):
		graphics_panel.visible = graphics_open
	_update_modal_controls()

func refresh_graphics_settings(quality_id: String) -> void:
	var names := {"low": "DÜŞÜK", "balanced": "DENGELİ", "high": "YÜKSEK"}
	if is_instance_valid(graphics_quality_label):
		graphics_quality_label.text = "Etkin kalite: %s" % str(names.get(quality_id, "DENGELİ"))
	for id in graphics_quality_buttons:
		var button: Button = graphics_quality_buttons[id]
		if is_instance_valid(button):
			button.disabled = str(id) == quality_id

func _process(delta: float) -> void:
	_graphics_fps_refresh_elapsed += delta
	if _graphics_fps_refresh_elapsed < 0.5:
		return
	_graphics_fps_refresh_elapsed = 0.0
	if is_instance_valid(graphics_fps_label):
		graphics_fps_label.text = "FPS: %d  •  Cihaz: %s" % [Engine.get_frames_per_second(), OS.get_name()]

func toggle_quest_journal(journal_text_value: String) -> void:
	var next_visible := not quest_open
	_set_all_modals_closed()
	quest_open = next_visible
	if is_instance_valid(quest_panel):
		quest_panel.visible = quest_open
	if quest_open:
		refresh_quest_journal(journal_text_value)
	_update_modal_controls()

func refresh_quest_journal(journal_text_value: String) -> void:
	if is_instance_valid(quest_text) and not journal_text_value.is_empty():
		quest_text.text = journal_text_value

func toggle_companion_panel(summary: Dictionary) -> void:
	var next_visible := not companion_open
	_set_all_modals_closed()
	companion_open = next_visible
	if is_instance_valid(companion_panel):
		companion_panel.visible = companion_open
	if companion_open:
		refresh_companions(summary)
	_update_modal_controls()

func refresh_companions(summary: Dictionary) -> void:
	if is_instance_valid(companion_summary_label):
		companion_summary_label.text = "AKTİF YOLDAŞ: %d  •  ORDU: %d/%d  •  ALTIN: %d" % [int(summary.get("count", 0)), int(summary.get("army_count", summary.get("count", 0))), int(summary.get("capacity", 10)), int(summary.get("gold", 0))]
	if is_instance_valid(companion_text):
		companion_text.text = str(summary.get("text", "Yoldaş bilgisi yok."))

func toggle_skills_panel(summary: Dictionary) -> void:
	var next_visible := not skills_open
	_set_all_modals_closed()
	skills_open = next_visible
	if is_instance_valid(skills_panel):
		skills_panel.visible = skills_open
	if skills_open:
		refresh_skills(summary)
	_update_modal_controls()

func refresh_skills(summary: Dictionary) -> void:
	var points := int(summary.get("points", 0))
	var levels: Variant = summary.get("levels", {})
	if is_instance_valid(skills_points_label):
		skills_points_label.text = "SEVİYE %d  •  KULLANILABİLİR YETENEK PUANI: %d" % [int(summary.get("player_level", 1)), points]
	var details := []
	for skill_id in ["combat", "leadership", "survival"]:
		var current_level := int(levels.get(skill_id, 0)) if levels is Dictionary else 0
		var button: Button = skill_buttons.get(skill_id)
		if is_instance_valid(button):
			button.text = "SEVİYE %d/3  •  %s" % [current_level, "EN ÜST SEVİYE" if current_level >= 3 else "1 PUANLA GELİŞTİR"]
			button.disabled = points <= 0 or current_level >= 3
		details.append("%s: %d/3" % [skill_id.capitalize(), current_level])
	if is_instance_valid(skills_status_label):
		skills_status_label.text = "• ".join(PackedStringArray(details)) + "\nLiderlik mevcut kapasiteyi %d askere çıkarır." % int(summary.get("army_capacity", 10))

func _make_utility_button(label_text: String, color: Color) -> Button:
	var button := Button.new()
	button.text = label_text
	button.custom_minimum_size = Vector2(74, 34)
	button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	button.add_theme_font_size_override("font_size", 12)
	button.add_theme_color_override("font_color", Color("#fff0d1"))
	button.add_theme_stylebox_override("normal", _panel_style(color, Color("#d3b57a")))
	button.add_theme_stylebox_override("hover", _panel_style(color.lightened(0.15), Color("#f0d59a")))
	button.add_theme_stylebox_override("pressed", _panel_style(color.darkened(0.2), Color("#ffe2a1")))
	return button

func _build_inventory_panel() -> void:
	inventory_panel = PanelContainer.new()
	inventory_panel.name = "InventoryWindow"
	inventory_panel.anchor_left = 0.5
	inventory_panel.anchor_right = 0.5
	inventory_panel.anchor_top = 0.5
	inventory_panel.anchor_bottom = 0.5
	inventory_panel.offset_left = -215
	inventory_panel.offset_right = 215
	inventory_panel.offset_top = -240
	inventory_panel.offset_bottom = 240
	inventory_panel.add_theme_stylebox_override("panel", _panel_style(Color("#111b21"), Color("#d3b57a")))
	inventory_panel.mouse_filter = Control.MOUSE_FILTER_STOP
	inventory_panel.visible = false
	root_control.add_child(inventory_panel)
	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 8)
	inventory_panel.add_child(column)
	var title := Label.new()
	title.text = "KOMUTANIN ÇANTASI"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 22)
	title.add_theme_color_override("font_color", Color("#f2d49c"))
	column.add_child(title)
	column.add_child(HSeparator.new())
	inventory_text = Label.new()
	inventory_text.custom_minimum_size = Vector2(0, 208)
	inventory_text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	inventory_text.add_theme_font_size_override("font_size", 15)
	inventory_text.add_theme_color_override("font_color", Color("#e7e0d2"))
	inventory_text.text = "Çanta yükleniyor..."
	column.add_child(inventory_text)
	inventory_potion_button = _make_panel_button("ŞİFA İKSİRİ KULLAN", Color("#3e6853"), 42)
	inventory_potion_button.add_theme_font_size_override("font_size", 14)
	inventory_potion_button.pressed.connect(func() -> void: potion_pressed.emit())
	column.add_child(inventory_potion_button)
	var action_row := HBoxContainer.new()
	action_row.add_theme_constant_override("separation", 8)
	column.add_child(action_row)
	var craft_button := _make_panel_button("ÜRETİM", Color("#6d5737"), 40)
	craft_button.pressed.connect(func() -> void: crafting_pressed.emit())
	action_row.add_child(craft_button)
	var equipment_button := _make_panel_button("EKİPMAN", Color("#405c6c"), 40)
	equipment_button.pressed.connect(func() -> void: equipment_pressed.emit())
	action_row.add_child(equipment_button)
	var close_button := _make_panel_button("KAPAT", Color("#59423e"), 38)
	close_button.pressed.connect(func() -> void: _set_inventory_visible(false))
	column.add_child(close_button)

func _build_crafting_panel() -> void:
	crafting_panel = PanelContainer.new()
	crafting_panel.name = "CraftingWindow"
	crafting_panel.anchor_left = 0.5
	crafting_panel.anchor_right = 0.5
	crafting_panel.anchor_top = 0.5
	crafting_panel.anchor_bottom = 0.5
	crafting_panel.offset_left = -275
	crafting_panel.offset_right = 275
	crafting_panel.offset_top = -255
	crafting_panel.offset_bottom = 255
	crafting_panel.add_theme_stylebox_override("panel", _panel_style(Color("#101a20"), Color("#c8a66a")))
	crafting_panel.mouse_filter = Control.MOUSE_FILTER_STOP
	crafting_panel.visible = false
	root_control.add_child(crafting_panel)
	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 6)
	crafting_panel.add_child(column)
	var title := Label.new()
	title.text = "USTA TEZGAHI  /  ÜRETİM"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 22)
	title.add_theme_color_override("font_color", Color("#f2d49c"))
	column.add_child(title)
	var subtitle := Label.new()
	subtitle.text = "Malzemeler yaratıklardan düşer. Üretim altın ve gerekli malzemeleri tüketir."
	subtitle.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	subtitle.add_theme_font_size_override("font_size", 12)
	subtitle.add_theme_color_override("font_color", Color("#c8d0cc"))
	column.add_child(subtitle)
	column.add_child(HSeparator.new())
	for recipe_id in ["potion_bundle", "armor", "boots", "ring", "sword"]:
		var recipe_id_for_callback := str(recipe_id)
		var row := HBoxContainer.new()
		row.custom_minimum_size = Vector2(0, 67)
		row.add_theme_constant_override("separation", 8)
		column.add_child(row)
		var details_column := VBoxContainer.new()
		details_column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		details_column.add_theme_constant_override("separation", 2)
		row.add_child(details_column)
		var recipe_title := Label.new()
		recipe_title.text = recipe_id
		recipe_title.add_theme_font_size_override("font_size", 15)
		recipe_title.add_theme_color_override("font_color", Color("#f0d6a4"))
		recipe_title.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		details_column.add_child(recipe_title)
		var recipe_details := Label.new()
		recipe_details.text = "Tarif yükleniyor..."
		recipe_details.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		recipe_details.add_theme_font_size_override("font_size", 12)
		recipe_details.add_theme_color_override("font_color", Color("#d0d5d2"))
		details_column.add_child(recipe_details)
		var craft_button := _make_panel_button("ÜRET", Color("#49664d"), 42)
		craft_button.custom_minimum_size = Vector2(88, 42)
		craft_button.size_flags_horizontal = Control.SIZE_SHRINK_END
		craft_button.pressed.connect(func() -> void: craft_recipe_pressed.emit(recipe_id_for_callback))
		row.add_child(craft_button)
		craft_rows[recipe_id_for_callback] = {"title": recipe_title, "details": recipe_details, "button": craft_button}
	column.add_child(HSeparator.new())
	var close_button := _make_panel_button("KAPAT", Color("#59423e"), 38)
	close_button.pressed.connect(func() -> void: _set_crafting_visible(false))
	column.add_child(close_button)

func _build_equipment_panel() -> void:
	equipment_panel = PanelContainer.new()
	equipment_panel.name = "EquipmentWindow"
	equipment_panel.anchor_left = 0.5
	equipment_panel.anchor_right = 0.5
	equipment_panel.anchor_top = 0.5
	equipment_panel.anchor_bottom = 0.5
	equipment_panel.offset_left = -230
	equipment_panel.offset_right = 230
	equipment_panel.offset_top = -185
	equipment_panel.offset_bottom = 185
	equipment_panel.add_theme_stylebox_override("panel", _panel_style(Color("#121b22"), Color("#8fb2bf")))
	equipment_panel.mouse_filter = Control.MOUSE_FILTER_STOP
	equipment_panel.visible = false
	root_control.add_child(equipment_panel)
	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 10)
	equipment_panel.add_child(column)
	var title := Label.new()
	title.text = "KOMUTANIN EKİPMANI"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 22)
	title.add_theme_color_override("font_color", Color("#f2d49c"))
	column.add_child(title)
	column.add_child(HSeparator.new())
	equipment_text = Label.new()
	equipment_text.custom_minimum_size = Vector2(0, 205)
	equipment_text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	equipment_text.add_theme_font_size_override("font_size", 16)
	equipment_text.add_theme_color_override("font_color", Color("#e7e0d2"))
	equipment_text.text = "Ekipman bilgisi yükleniyor..."
	column.add_child(equipment_text)
	var close_button := _make_panel_button("KAPAT", Color("#59423e"), 38)
	close_button.pressed.connect(func() -> void: _set_equipment_visible(false))
	column.add_child(close_button)

func _build_save_slots_panel() -> void:
	save_slots_panel = PanelContainer.new()
	save_slots_panel.name = "SaveSlotsWindow"
	save_slots_panel.anchor_left = 0.5
	save_slots_panel.anchor_right = 0.5
	save_slots_panel.anchor_top = 0.5
	save_slots_panel.anchor_bottom = 0.5
	save_slots_panel.offset_left = -230
	save_slots_panel.offset_right = 230
	save_slots_panel.offset_top = -220
	save_slots_panel.offset_bottom = 220
	save_slots_panel.add_theme_stylebox_override("panel", _panel_style(Color("#101920"), Color("#bca16f")))
	save_slots_panel.mouse_filter = Control.MOUSE_FILTER_STOP
	save_slots_panel.visible = false
	root_control.add_child(save_slots_panel)
	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 9)
	save_slots_panel.add_child(column)
	var title := Label.new()
	title.text = "YOLCULUK KAYITLARI"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 22)
	title.add_theme_color_override("font_color", Color("#f2d49c"))
	column.add_child(title)
	var info := Label.new()
	info.text = "Bir kayıt seç. Boş yuvayı yüklemek yeni bir yolculuk başlatır."
	info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	info.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	info.add_theme_font_size_override("font_size", 12)
	info.add_theme_color_override("font_color", Color("#c8d0cc"))
	column.add_child(info)
	column.add_child(HSeparator.new())
	for slot_id in range(1, 4):
		var slot_id_for_callback := slot_id
		var slot_button := _make_panel_button("YUVA %d  —  BOŞ" % slot_id_for_callback, Color("#31434a"), 52)
		slot_button.add_theme_font_size_override("font_size", 13)
		slot_button.pressed.connect(func() -> void: _select_save_slot(slot_id_for_callback))
		column.add_child(slot_button)
		save_slot_buttons.append(slot_button)
	var action_row := HBoxContainer.new()
	action_row.add_theme_constant_override("separation", 8)
	column.add_child(action_row)
	save_slot_save_button = _make_panel_button("YUVA KAYDET", Color("#76613a"), 42)
	save_slot_save_button.pressed.connect(func() -> void: save_slot_save_pressed.emit())
	action_row.add_child(save_slot_save_button)
	save_slot_load_button = _make_panel_button("YÜKLE / YENİ OYUN", Color("#405b65"), 42)
	save_slot_load_button.pressed.connect(func() -> void: save_slot_load_pressed.emit())
	action_row.add_child(save_slot_load_button)
	var close_button := _make_panel_button("KAPAT", Color("#59423e"), 38)
	close_button.pressed.connect(func() -> void: _set_save_slots_visible(false))
	column.add_child(close_button)

func _build_army_panel() -> void:
	army_panel = PanelContainer.new()
	army_panel.name = "ArmyCommandWindow"
	army_panel.anchor_left = 0.5
	army_panel.anchor_right = 0.5
	army_panel.anchor_top = 0.5
	army_panel.anchor_bottom = 0.5
	army_panel.offset_left = -265
	army_panel.offset_right = 265
	army_panel.offset_top = -260
	army_panel.offset_bottom = 260
	army_panel.add_theme_stylebox_override("panel", _panel_style(Color("#101a20"), Color("#d3b57a")))
	army_panel.mouse_filter = Control.MOUSE_FILTER_STOP
	army_panel.visible = false
	root_control.add_child(army_panel)

	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 7)
	army_panel.add_child(column)
	var title := Label.new()
	title.text = "KRALLIK ORDUSU  /  KOMUTANLIK"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 21)
	title.add_theme_color_override("font_color", Color("#f2d49c"))
	column.add_child(title)
	army_status_label = Label.new()
	army_status_label.text = "Birlik bilgileri hazırlanıyor..."
	army_status_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	army_status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	army_status_label.add_theme_font_size_override("font_size", 13)
	army_status_label.add_theme_color_override("font_color", Color("#d7dfd9"))
	column.add_child(army_status_label)
	column.add_child(HSeparator.new())

	var order_title := Label.new()
	order_title.text = "SAVAŞ EMİRLERİ"
	order_title.add_theme_color_override("font_color", Color("#f0d6a4"))
	order_title.add_theme_font_size_override("font_size", 14)
	column.add_child(order_title)
	var order_row_one := HBoxContainer.new()
	order_row_one.add_theme_constant_override("separation", 7)
	column.add_child(order_row_one)
	var order_row_two := HBoxContainer.new()
	order_row_two.add_theme_constant_override("separation", 7)
	column.add_child(order_row_two)
	_add_army_action_button(order_row_one, "TAKİP ET", "follow", "#405d69")
	_add_army_action_button(order_row_one, "MEVZİ TUT", "hold", "#4d674a")
	_add_army_action_button(order_row_two, "HÜCUM ET", "charge", "#8b3e32")
	_add_army_action_button(order_row_two, "GERİ ÇEKİL", "retreat", "#62517d")

	column.add_child(HSeparator.new())
	var formation_title := Label.new()
	formation_title.text = "FORMASYON"
	formation_title.add_theme_color_override("font_color", Color("#f0d6a4"))
	formation_title.add_theme_font_size_override("font_size", 14)
	column.add_child(formation_title)
	var formation_row := HBoxContainer.new()
	formation_row.add_theme_constant_override("separation", 7)
	column.add_child(formation_row)
	_add_formation_button(formation_row, "HAT DÜZENİ", "line")
	_add_formation_button(formation_row, "KAMA", "wedge")
	_add_formation_button(formation_row, "SÜTUN", "column")

	column.add_child(HSeparator.new())
	var recruit_title := Label.new()
	recruit_title.text = "ASKER TOPLA  •  ALTIN KARŞILIĞI"
	recruit_title.add_theme_color_override("font_color", Color("#f0d6a4"))
	recruit_title.add_theme_font_size_override("font_size", 14)
	column.add_child(recruit_title)
	var recruit_row := HBoxContainer.new()
	recruit_row.add_theme_constant_override("separation", 7)
	column.add_child(recruit_row)
	_add_recruit_button(recruit_row, "PİYADE\n25 ALTIN", "infantry", "#405d69")
	_add_recruit_button(recruit_row, "OKÇU\n35 ALTIN", "archer", "#49664d")
	_add_recruit_button(recruit_row, "SÜVARİ\n50 ALTIN", "cavalry", "#806534")
	var recruit_row_two := HBoxContainer.new()
	recruit_row_two.add_theme_constant_override("separation", 7)
	column.add_child(recruit_row_two)
	_add_recruit_button(recruit_row_two, "KALKANLI MUHAFIZ\n60 ALTIN", "shield_guard", "#374653")
	_add_recruit_button(recruit_row_two, "ARBALETÇİ\n55 ALTIN", "crossbowman", "#586345")

	var footer := Label.new()
	footer.text = "Azami 10 asker. Yeni ağır muhafız ve arbaletçi birlikleri dâhil."
	footer.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	footer.add_theme_font_size_override("font_size", 12)
	footer.add_theme_color_override("font_color", Color("#c8d0cc"))
	column.add_child(footer)
	var close_button := _make_panel_button("KOMUTANLIK KAPAT", Color("#59423e"), 36)
	close_button.pressed.connect(func() -> void: _set_army_visible(false))
	column.add_child(close_button)

func _build_kingdom_panel() -> void:
	kingdom_panel = PanelContainer.new()
	kingdom_panel.name = "KingdomDiplomacyWindow"
	kingdom_panel.anchor_left = 0.5
	kingdom_panel.anchor_right = 0.5
	kingdom_panel.anchor_top = 0.5
	kingdom_panel.anchor_bottom = 0.5
	kingdom_panel.offset_left = -270
	kingdom_panel.offset_right = 270
	kingdom_panel.offset_top = -300
	kingdom_panel.offset_bottom = 300
	kingdom_panel.add_theme_stylebox_override("panel", _panel_style(Color("#11171f"), Color("#c7a56b")))
	kingdom_panel.mouse_filter = Control.MOUSE_FILTER_STOP
	kingdom_panel.visible = false
	root_control.add_child(kingdom_panel)
	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 5)
	kingdom_panel.add_child(column)
	var title := Label.new()
	title.text = "KRALLIKLAR  /  DİPLOMASİ"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 21)
	title.add_theme_color_override("font_color", Color("#f2d49c"))
	column.add_child(title)
	kingdom_status_label = Label.new()
	kingdom_status_label.text = "Bağlılık ve itibar yükleniyor..."
	kingdom_status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	kingdom_status_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	kingdom_status_label.add_theme_font_size_override("font_size", 13)
	kingdom_status_label.add_theme_color_override("font_color", Color("#d7dfd9"))
	column.add_child(kingdom_status_label)
	column.add_child(HSeparator.new())
	for faction_id in ["north_crown", "aurel_empire", "red_banner", "mountain_clans", "black_seal"]:
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 8)
		column.add_child(row)
		var faction_label := Label.new()
		faction_label.custom_minimum_size = Vector2(0, 48)
		faction_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		faction_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		faction_label.add_theme_font_size_override("font_size", 12)
		faction_label.add_theme_color_override("font_color", Color("#e7e0d2"))
		row.add_child(faction_label)
		var pledge_button := _make_panel_button("YEMİN ET", Color("#4a5969"), 44)
		pledge_button.custom_minimum_size = Vector2(132, 44)
		var captured_id: String = faction_id
		pledge_button.pressed.connect(func() -> void: kingdom_pledge_pressed.emit(captured_id))
		row.add_child(pledge_button)
		kingdom_faction_rows[faction_id] = {"label": faction_label, "button": pledge_button}
	column.add_child(HSeparator.new())
	kingdom_territories_label = Label.new()
	kingdom_territories_label.custom_minimum_size = Vector2(0, 105)
	kingdom_territories_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	kingdom_territories_label.add_theme_font_size_override("font_size", 12)
	kingdom_territories_label.add_theme_color_override("font_color", Color("#cbd2d0"))
	column.add_child(kingdom_territories_label)
	var close_button := _make_panel_button("DİPLOMASİYİ KAPAT", Color("#59423e"), 36)
	close_button.pressed.connect(func() -> void: _set_kingdom_visible(false))
	column.add_child(close_button)

func toggle_kingdom_panel(summary: Dictionary = {}) -> void:
	var next_visible := not kingdom_open
	_set_all_modals_closed()
	kingdom_open = next_visible
	if is_instance_valid(kingdom_panel):
		kingdom_panel.visible = kingdom_open
	if kingdom_open:
		refresh_kingdom_panel(summary)
	_update_modal_controls()

func _set_kingdom_visible(value: bool) -> void:
	kingdom_open = value
	if is_instance_valid(kingdom_panel):
		kingdom_panel.visible = value
	_update_modal_controls()

func refresh_kingdom_panel(summary: Dictionary) -> void:
	if is_instance_valid(kingdom_status_label):
		kingdom_status_label.text = "BAĞLILIK: %s  •  ELE GEÇİRİLEN BÖLGE: %d\nYeminli grubun askerleri sana saldırmaz; yemin itibar ve asker alım maliyetini etkiler.\n%s" % [str(summary.get("oath_name", "Bağımsız")), int(summary.get("player_territory_count", 0)), str(summary.get("campaign_text", "Kampanya simülasyonu hazırlanıyor."))]
	var factions: Variant = summary.get("factions", [])
	if factions is Array:
		for entry in factions:
			if not entry is Dictionary:
				continue
			var faction_id := str(entry.get("id", ""))
			if not kingdom_faction_rows.has(faction_id):
				continue
			var row: Dictionary = kingdom_faction_rows[faction_id]
			var standing := int(entry.get("standing", 0))
			var standing_text := "+%d" % standing if standing >= 0 else str(standing)
			var faction_label: Label = row["label"]
			faction_label.text = "%s  •  İtibar %s  •  %s\nLider: %s — %s" % [str(entry.get("name", faction_id)), standing_text, str(entry.get("attitude", "Tarafsız")), str(entry.get("leader", "")), str(entry.get("description", ""))]
			var pledge_button: Button = row["button"]
			if bool(entry.get("is_oath", false)):
				pledge_button.text = "YEMİNLİSİN"
				pledge_button.disabled = true
			elif bool(entry.get("can_pledge", false)):
				pledge_button.text = "YEMİN ET" if str(summary.get("oath_name", "Bağımsız")) == "Bağımsız" else "BAĞLILIK DEĞİŞTİR"
				pledge_button.disabled = false
			else:
				pledge_button.text = "İTİBAR +40"
				pledge_button.disabled = true
	var territories: Variant = summary.get("territories", [])
	var territory_lines: Array[String] = ["BÖLGE KONTROLÜ"]
	if territories is Array:
		for entry in territories:
			if entry is Dictionary:
				var prefix := "◆" if bool(entry.get("is_player", false)) else "•"
				territory_lines.append("%s %s — %s" % [prefix, str(entry.get("name", "Bölge")), str(entry.get("owner_name", "Tarafsız"))])
	if is_instance_valid(kingdom_territories_label):
		kingdom_territories_label.text = "\n".join(PackedStringArray(territory_lines))

func _build_settlement_panel() -> void:
	settlement_panel = PanelContainer.new()
	settlement_panel.name = "SettlementManagementWindow"
	settlement_panel.anchor_left = 0.5
	settlement_panel.anchor_right = 0.5
	settlement_panel.anchor_top = 0.5
	settlement_panel.anchor_bottom = 0.5
	settlement_panel.offset_left = -270
	settlement_panel.offset_right = 270
	settlement_panel.offset_top = -285
	settlement_panel.offset_bottom = 285
	settlement_panel.add_theme_stylebox_override("panel", _panel_style(Color("#151b1b"), Color("#c7a56b")))
	settlement_panel.mouse_filter = Control.MOUSE_FILTER_STOP
	settlement_panel.visible = false
	root_control.add_child(settlement_panel)

	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 6)
	settlement_panel.add_child(column)
	var title := Label.new()
	title.text = "KALE  /  YERLEŞİM YÖNETİMİ"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 20)
	title.add_theme_color_override("font_color", Color("#f2d49c"))
	column.add_child(title)
	settlement_status_label = Label.new()
	settlement_status_label.text = "Yerleşim bilgileri yükleniyor..."
	settlement_status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	settlement_status_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	settlement_status_label.add_theme_font_size_override("font_size", 13)
	settlement_status_label.add_theme_color_override("font_color", Color("#d7dfd9"))
	column.add_child(settlement_status_label)
	settlement_gold_label = Label.new()
	settlement_gold_label.text = "ALTIN: 0"
	settlement_gold_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	settlement_gold_label.add_theme_color_override("font_color", Color("#f1d49a"))
	column.add_child(settlement_gold_label)
	column.add_child(HSeparator.new())

	_add_settlement_action(column, "KIŞLAYI GELİŞTİR", "upgrade_barracks", Color("#465d66"), 40)
	_add_settlement_action(column, "TAŞ SURLARI GÜÇLENDİR", "upgrade_walls", Color("#5a5150"), 40)
	_add_settlement_action(column, "PAZARI GELİŞTİR", "upgrade_market", Color("#526645"), 40)
	column.add_child(HSeparator.new())
	_add_settlement_action(column, "KALE MUHAFIZI TOPLA", "recruit_garrison", Color("#715333"), 42)
	_add_settlement_action(column, "VERGİLERİ TOPLA", "collect_taxes", Color("#6a6343"), 42)
	var footer := Label.new()
	footer.text = "Kışla garnizon kapasitesini, surlar savunma puanını, pazar vergi gelirini artırır."
	footer.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	footer.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	footer.add_theme_font_size_override("font_size", 11)
	footer.add_theme_color_override("font_color", Color("#c8d0cc"))
	column.add_child(footer)
	var close_button := _make_panel_button("YERLEŞİMİ KAPAT", Color("#59423e"), 34)
	close_button.pressed.connect(func() -> void: _set_settlement_visible(false))
	column.add_child(close_button)

func _add_settlement_action(parent: VBoxContainer, label_text: String, action_id: String, color: Color, height: float) -> void:
	var button := _make_panel_button(label_text, color, height)
	button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	button.pressed.connect(func() -> void: settlement_action_pressed.emit(action_id))
	parent.add_child(button)
	settlement_action_buttons[action_id] = button

func toggle_settlement_panel(summary: Dictionary = {}) -> void:
	var next_visible := not settlement_open
	_set_all_modals_closed()
	settlement_open = next_visible
	if is_instance_valid(settlement_panel):
		settlement_panel.visible = settlement_open
	if settlement_open:
		refresh_settlement_panel(summary)
	_update_modal_controls()

func _set_settlement_visible(value: bool) -> void:
	settlement_open = value
	if is_instance_valid(settlement_panel):
		settlement_panel.visible = value
	_update_modal_controls()

func refresh_settlement_panel(summary: Dictionary) -> void:
	var owned := bool(summary.get("castle_owned", false))
	var levels: Variant = summary.get("building_levels", {})
	if not levels is Dictionary:
		levels = {}
	var barracks_level := int(levels.get("barracks", 0))	
	var wall_level := int(levels.get("walls", 0))
	var market_level := int(levels.get("market", 0))
	var garrison := int(summary.get("garrison_units", 0))
	var garrison_cap := int(summary.get("garrison_capacity", 8))
	var tax_cooldown := float(summary.get("tax_cooldown", 0.0))
	if is_instance_valid(settlement_status_label):
		if owned:
			settlement_status_label.text = "KONTROL: SENDE  •  SAVUNMA: %d\nKIŞLA %d/%d  •  SURLAR %d/%d  •  PAZAR %d/%d\nGARNİZON %d/%d  •  VERGİ GELİRİ: %d ALTIN" % [int(summary.get("defense_rating", 0)), barracks_level, 3, wall_level, 3, market_level, 3, garrison, garrison_cap, int(summary.get("tax_income", 20))]
		else:
			settlement_status_label.text = "KONTROL: DÜŞMANDA\nBu yönetim panelini kullanmak için Karanlık Taç Kalesi'ni fethet.\nKuşatma panelinden ana kapıyı yıkıp iç avluyu temizle."
	if is_instance_valid(settlement_gold_label):
		settlement_gold_label.text = "ALTIN: %d  •  TOPLANAN VERGİ: %d" % [int(summary.get("gold", 0)), int(summary.get("taxes_collected", 0))]
	var costs: Variant = summary.get("upgrade_costs", {})
	if not costs is Dictionary:
		costs = {}
	_update_settlement_button("upgrade_barracks", "KIŞLAYI GELİŞTİR", int(costs.get("barracks", -1)), int(summary.get("gold", 0)), owned)
	_update_settlement_button("upgrade_walls", "TAŞ SURLARI GÜÇLENDİR", int(costs.get("walls", -1)), int(summary.get("gold", 0)), owned)
	_update_settlement_button("upgrade_market", "PAZARI GELİŞTİR", int(costs.get("market", -1)), int(summary.get("gold", 0)), owned)
	var recruit_button: Button = settlement_action_buttons.get("recruit_garrison")
	if is_instance_valid(recruit_button):
		recruit_button.text = "KALE MUHAFIZI TOPLA · %d ALTIN" % int(summary.get("garrison_recruit_cost", 40))
		recruit_button.disabled = not owned or garrison >= garrison_cap or int(summary.get("gold", 0)) < int(summary.get("garrison_recruit_cost", 40))
	var tax_button: Button = settlement_action_buttons.get("collect_taxes")
	if is_instance_valid(tax_button):
		if tax_cooldown > 0.0:
			tax_button.text = "VERGİLERİ TOPLA · %ds" % ceili(tax_cooldown)
		else:
			tax_button.text = "VERGİLERİ TOPLA · +%d ALTIN" % int(summary.get("tax_income", 20))
		tax_button.disabled = not owned or tax_cooldown > 0.0

func _update_settlement_button(action_id: String, label_text: String, cost: int, current_gold: int, owned: bool) -> void:
	var button: Button = settlement_action_buttons.get(action_id)
	if not is_instance_valid(button):
		return
	if cost < 0:
		button.text = label_text + " · MAKS."
		button.disabled = true
	else:
		button.text = "%s · %d ALTIN" % [label_text, cost]
		button.disabled = not owned or current_gold < cost

func _build_siege_panel() -> void:
	siege_panel = PanelContainer.new()
	siege_panel.name = "CastleSiegeWindow"
	siege_panel.anchor_left = 0.5
	siege_panel.anchor_right = 0.5
	siege_panel.anchor_top = 0.5
	siege_panel.anchor_bottom = 0.5
	siege_panel.offset_left = -245
	siege_panel.offset_right = 245
	siege_panel.offset_top = -205
	siege_panel.offset_bottom = 205
	siege_panel.add_theme_stylebox_override("panel", _panel_style(Color("#171b20"), Color("#b98b50")))
	siege_panel.mouse_filter = Control.MOUSE_FILTER_STOP
	siege_panel.visible = false
	root_control.add_child(siege_panel)

	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 8)
	siege_panel.add_child(column)
	var title := Label.new()
	title.text = "KARANLIK TAÇ  /  KALE KUŞATMASI"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 20)
	title.add_theme_color_override("font_color", Color("#f0d19a"))
	column.add_child(title)
	var subtitle := Label.new()
	subtitle.text = "Kapıyı yık, savunmacıları temizle ve iç avluda 10 saniye tutun."
	subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	subtitle.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	subtitle.add_theme_font_size_override("font_size", 13)
	subtitle.add_theme_color_override("font_color", Color("#d4d8d7"))
	column.add_child(subtitle)
	column.add_child(HSeparator.new())
	siege_status_label = Label.new()
	siege_status_label.text = "Kapı ve kuşatma durumu yükleniyor..."
	siege_status_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	siege_status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	siege_status_label.add_theme_font_size_override("font_size", 14)
	siege_status_label.add_theme_color_override("font_color", Color("#e7e2d5"))
	column.add_child(siege_status_label)
	column.add_child(HSeparator.new())
	_add_siege_command_button(column, "KUŞATMAYI BAŞLAT", "start", Color("#455e70"), 42)
	_add_siege_command_button(column, "ASKERLERİ KAPIYA GÖNDER", "assault", Color("#8b4933"), 42)
	siege_catapult_button = _add_siege_command_button(column, "MANCINIK ATEŞLE · 25 ALTIN", "catapult", Color("#755a35"), 42)
	_add_siege_command_button(column, "FETİH EMRİ VER", "capture", Color("#4d6b4b"), 42)
	var close_button := _make_panel_button("KUŞATMA PANELİNİ KAPAT", Color("#59423e"), 34)
	close_button.pressed.connect(func() -> void: _set_siege_visible(false))
	column.add_child(close_button)

func _add_siege_command_button(parent: VBoxContainer, label_text: String, command_id: String, color: Color, height: float) -> Button:
	var button := _make_panel_button(label_text, color, height)
	button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	button.pressed.connect(func() -> void: siege_command_pressed.emit(command_id))
	parent.add_child(button)
	return button

func toggle_siege_panel() -> void:
	var next_visible := not siege_open
	_set_all_modals_closed()
	siege_open = next_visible
	if is_instance_valid(siege_panel):
		siege_panel.visible = siege_open
	_update_modal_controls()

func _set_siege_visible(value: bool) -> void:
	siege_open = value
	if is_instance_valid(siege_panel):
		siege_panel.visible = value
	_update_modal_controls()

func update_siege_status(status_text: String, cooldown: float = 0.0, cost: int = 25) -> void:
	if is_instance_valid(siege_status_label):
		siege_status_label.text = status_text
	if is_instance_valid(siege_catapult_button):
		if cooldown > 0.0:
			siege_catapult_button.text = "MANCINIK HAZIRLANIYOR · %ds" % ceili(cooldown)
		else:
			siege_catapult_button.text = "MANCINIK ATEŞLE · %d ALTIN" % cost

func _add_army_action_button(parent: HBoxContainer, label_text: String, order_id: String, color_hex: String) -> void:
	var button := _make_panel_button(label_text, Color(color_hex), 40)
	button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	button.pressed.connect(func() -> void: army_order_pressed.emit(order_id))
	parent.add_child(button)

func _add_formation_button(parent: HBoxContainer, label_text: String, formation_id: String) -> void:
	var button := _make_panel_button(label_text, Color("#4b5362"), 38)
	button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	button.pressed.connect(func() -> void: army_formation_pressed.emit(formation_id))
	parent.add_child(button)

func _add_recruit_button(parent: HBoxContainer, label_text: String, class_id: String, color_hex: String) -> void:
	var button := _make_panel_button(label_text, Color(color_hex), 48)
	button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	button.add_theme_font_size_override("font_size", 13)
	button.pressed.connect(func() -> void: army_recruit_pressed.emit(class_id))
	parent.add_child(button)
	army_recruit_buttons[class_id] = button

func toggle_army_panel(summary: Dictionary = {}) -> void:
	var next_visible := not army_open
	_set_all_modals_closed()
	army_open = next_visible
	if is_instance_valid(army_panel):
		army_panel.visible = army_open
	if army_open:
		refresh_army_panel(summary)
	_update_modal_controls()

func _set_army_visible(value: bool) -> void:
	army_open = value
	if is_instance_valid(army_panel):
		army_panel.visible = value
	_update_modal_controls()

func refresh_army_panel(summary: Dictionary) -> void:
	if is_instance_valid(army_status_label):
		army_status_label.text = "Asker: %d/%d  •  Piyade %d  •  Okçu %d  •  Süvari %d\nMuhafız %d  •  Arbaletçi %d  •  Emir: %s\nFormasyon: %s  •  Altın: %d" % [int(summary.get("count", 0)), int(summary.get("capacity", 10)), int(summary.get("infantry", 0)), int(summary.get("archer", 0)), int(summary.get("cavalry", 0)), int(summary.get("shield_guard", 0)), int(summary.get("crossbowman", 0)), str(summary.get("order_name", "Takip")), str(summary.get("formation_name", "Hat")), int(summary.get("gold", 0))]
	for class_id in ["infantry", "archer", "cavalry", "shield_guard", "crossbowman"]:
		if not army_recruit_buttons.has(class_id):
			continue
		var button: Button = army_recruit_buttons[class_id]
		var cost := int(summary.get("costs", {}).get(class_id, 999999))
		var full := int(summary.get("count", 0)) >= int(summary.get("capacity", 10))
		var labels := {"infantry": "PİYADE", "archer": "OKÇU", "cavalry": "SÜVARİ", "shield_guard": "KALKANLI MUHAFIZ", "crossbowman": "ARBALETÇİ"}
		button.text = "%s\n%d ALTIN" % [str(labels.get(class_id, class_id)), cost]
		button.disabled = full or int(summary.get("gold", 0)) < cost

func _make_panel_button(label_text: String, color: Color, height: float = 40.0) -> Button:
	var button := Button.new()
	button.text = label_text
	button.custom_minimum_size = Vector2(0, height)
	button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	button.add_theme_font_size_override("font_size", 14)
	button.add_theme_color_override("font_color", Color("#fff0d1"))
	button.add_theme_stylebox_override("normal", _panel_style(color, Color("#d3b57a")))
	button.add_theme_stylebox_override("hover", _panel_style(color.lightened(0.15), Color("#f0d59a")))
	button.add_theme_stylebox_override("pressed", _panel_style(color.darkened(0.2), Color("#ffe2a1")))
	button.add_theme_stylebox_override("disabled", _panel_style(Color("#30383a"), Color("#77746b")))
	return button

func _select_save_slot(slot_id: int) -> void:
	selected_save_slot = clampi(slot_id, 1, 3)
	save_slot_selected.emit(selected_save_slot)

func toggle_inventory(items: Dictionary, gold_amount: int, current_weapon_level: int, armor_level: int = 0, boots_level: int = 0, ring_level: int = 0) -> void:
	var next_visible := not inventory_open
	_set_all_modals_closed()
	inventory_open = next_visible
	if inventory_open:
		refresh_inventory(items, gold_amount, current_weapon_level, armor_level, boots_level, ring_level)
	if is_instance_valid(inventory_panel):
		inventory_panel.visible = inventory_open
	_update_modal_controls()

func toggle_crafting(options: Array = []) -> void:
	var next_visible := not crafting_open
	_set_all_modals_closed()
	crafting_open = next_visible
	if is_instance_valid(crafting_panel):
		crafting_panel.visible = crafting_open
	if crafting_open:
		refresh_crafting(options)
	_update_modal_controls()

func toggle_equipment(summary: Dictionary = {}) -> void:
	var next_visible := not equipment_open
	_set_all_modals_closed()
	equipment_open = next_visible
	if is_instance_valid(equipment_panel):
		equipment_panel.visible = equipment_open
	if equipment_open:
		refresh_equipment(summary)
	_update_modal_controls()

func toggle_save_slots(slots: Array = [], active_slot: int = 1) -> void:
	var next_visible := not save_slots_open
	_set_all_modals_closed()
	save_slots_open = next_visible
	if is_instance_valid(save_slots_panel):
		save_slots_panel.visible = save_slots_open
	if save_slots_open:
		refresh_save_slots(slots, active_slot)
	_update_modal_controls()

func _build_story_choice_panel() -> void:
	story_choice_panel = PanelContainer.new()
	story_choice_panel.name = "StoryDecisionWindow"
	story_choice_panel.anchor_left = 0.5
	story_choice_panel.anchor_right = 0.5
	story_choice_panel.anchor_top = 0.5
	story_choice_panel.anchor_bottom = 0.5
	story_choice_panel.offset_left = -290
	story_choice_panel.offset_right = 290
	story_choice_panel.offset_top = -190
	story_choice_panel.offset_bottom = 190
	story_choice_panel.add_theme_stylebox_override("panel", _panel_style(Color("#171a20"), Color("#d9b768")))
	story_choice_panel.mouse_filter = Control.MOUSE_FILTER_STOP
	story_choice_panel.visible = false
	root_control.add_child(story_choice_panel)
	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 10)
	story_choice_panel.add_child(column)
	story_choice_title = Label.new()
	story_choice_title.text = "HİKÂYE KARARI"
	story_choice_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	story_choice_title.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	story_choice_title.add_theme_font_size_override("font_size", 21)
	story_choice_title.add_theme_color_override("font_color", Color("#f2d49c"))
	column.add_child(story_choice_title)
	story_choice_detail = Label.new()
	story_choice_detail.text = "Kararın dünyanın gidişatını değiştirecek."
	story_choice_detail.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	story_choice_detail.custom_minimum_size = Vector2(0, 76)
	story_choice_detail.add_theme_font_size_override("font_size", 14)
	story_choice_detail.add_theme_color_override("font_color", Color("#d7dfd9"))
	column.add_child(story_choice_detail)
	column.add_child(HSeparator.new())
	var hint := Label.new()
	hint.text = "Bir karar seç. Bazı sonuçlar geri alınamaz."
	hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	hint.add_theme_font_size_override("font_size", 12)
	hint.add_theme_color_override("font_color", Color("#c8b98f"))
	column.add_child(hint)

func show_story_choices(title_text: String, detail_text: String, choices: Array) -> void:
	if not is_instance_valid(story_choice_panel):
		return
	_set_all_modals_closed()
	story_choice_title.text = title_text
	story_choice_detail.text = detail_text
	for button in story_choice_buttons:
		if is_instance_valid(button):
			button.queue_free()
	story_choice_buttons.clear()
	var column := story_choice_panel.get_child(0) as VBoxContainer
	for choice in choices:
		var choice_id := str(choice.get("id", ""))
		var choice_label := str(choice.get("label", "Karar ver"))
		var choice_detail := str(choice.get("description", ""))
		var button := _make_panel_button(choice_label, Color("#4c5b52"), 54)
		button.custom_minimum_size = Vector2(0, 54)
		button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		button.text = choice_label + ("\n" + choice_detail if not choice_detail.is_empty() else "")
		button.add_theme_font_size_override("font_size", 13)
		button.pressed.connect(_on_story_choice_button_pressed.bind(choice_id))
		column.add_child(button)
		story_choice_buttons.append(button)
	story_choice_open = true
	story_choice_panel.visible = true
	_update_modal_controls()

func _on_story_choice_button_pressed(choice_id: String) -> void:
	story_choice_pressed.emit(choice_id)

func close_story_choices() -> void:
	story_choice_open = false
	if is_instance_valid(story_choice_panel):
		story_choice_panel.visible = false
	_update_modal_controls()

func _set_all_modals_closed() -> void:
	inventory_open = false
	crafting_open = false
	equipment_open = false
	save_slots_open = false
	army_open = false
	kingdom_open = false
	siege_open = false
	settlement_open = false
	quest_open = false
	companion_open = false
	skills_open = false
	graphics_open = false
	story_choice_open = false
	for panel in [inventory_panel, crafting_panel, equipment_panel, save_slots_panel, army_panel, kingdom_panel, siege_panel, settlement_panel, quest_panel, companion_panel, skills_panel, graphics_panel, story_choice_panel]:
		if is_instance_valid(panel):
			panel.visible = false

func _set_inventory_visible(value: bool) -> void:
	inventory_open = value
	if is_instance_valid(inventory_panel):
		inventory_panel.visible = value
	_update_modal_controls()

func _set_crafting_visible(value: bool) -> void:
	crafting_open = value
	if is_instance_valid(crafting_panel):
		crafting_panel.visible = value
	_update_modal_controls()

func _set_equipment_visible(value: bool) -> void:
	equipment_open = value
	if is_instance_valid(equipment_panel):
		equipment_panel.visible = value
	_update_modal_controls()

func _set_save_slots_visible(value: bool) -> void:
	save_slots_open = value
	if is_instance_valid(save_slots_panel):
		save_slots_panel.visible = value
	_update_modal_controls()

func _update_modal_controls() -> void:
	var modal_active := inventory_open or crafting_open or equipment_open or save_slots_open or army_open or kingdom_open or siege_open or settlement_open or quest_open or companion_open or skills_open or graphics_open or story_choice_open
	get_tree().paused = modal_active
	modal_open_changed.emit(modal_active)
	if is_instance_valid(joystick):
		joystick.visible = not modal_active
	for control in [attack_button, block_button, sprint_button, troops_button, interact_button]:
		if is_instance_valid(control):
			control.visible = not modal_active
	if modal_active:
		sprint_changed.emit(false)

func refresh_inventory(items: Dictionary, gold_amount: int, current_weapon_level: int, armor_level: int = 0, boots_level: int = 0, ring_level: int = 0) -> void:
	if not is_instance_valid(inventory_text):
		return
	var rows: Array[String] = [
		"ALTIN: %d   •   KILIÇ SEVİYESİ: %d" % [gold_amount, current_weapon_level],
		"Zırh: %d/3   •   Çizme: %d/2   •   Rün yüzüğü: %d/2" % [armor_level, boots_level, ring_level],
		"",
		"Şifa iksiri: %d   (+85 can)" % int(items.get("healing_potion", 0)),
		"Kurt postu: %d" % int(items.get("wolf_pelt", 0)),
		"Kemik parçası: %d" % int(items.get("bone_fragment", 0)),
		"Örümcek ipeği: %d" % int(items.get("spider_silk", 0)),
		"Bataklık özü: %d" % int(items.get("bog_core", 0)),
		"Kül özü: %d" % int(items.get("ash_essence", 0)),
		"Ejder pulu: %d" % int(items.get("drake_scale", 0)),
		"Kadim kalıntı: %d" % int(items.get("ancient_relic", 0)),
		"Haydut sancağı: %d" % int(items.get("bandit_insignia", 0)),
		"",
		"Malzemeler üretimde; ekipmanlar hasar, hız ve dayanıklılığı etkiler."
	]
	inventory_text.text = "\n".join(PackedStringArray(rows))
	if is_instance_valid(inventory_potion_button):
		inventory_potion_button.text = "ŞİFA İKSİRİ KULLAN (%d)" % int(items.get("healing_potion", 0))

func refresh_crafting(options: Array) -> void:
	for option in options:
		if not option is Dictionary:
			continue
		var recipe_id := str(option.get("id", ""))
		if not craft_rows.has(recipe_id):
			continue
		var row: Dictionary = craft_rows[recipe_id]
		var title_label: Label = row["title"]
		var details_label: Label = row["details"]
		var button: Button = row["button"]
		title_label.text = str(option.get("title", recipe_id))
		details_label.text = str(option.get("description", ""))
		var maxed := bool(option.get("maxed", false))
		button.disabled = not bool(option.get("ready", false))
		button.text = "EN ÜST" if maxed else ("ÜRET" if bool(option.get("ready", false)) else "EKSİK")

func refresh_equipment(summary: Dictionary) -> void:
	if not is_instance_valid(equipment_text) or summary.is_empty():
		return
	var rows: Array[String] = [
		"SİLAH  •  %s (seviye %d)" % [str(summary.get("weapon_name", "Uzun Kılıç")), int(summary.get("weapon_level", 1))],
		"Hasar: %.0f" % float(summary.get("attack_damage", 34.0)),
		"",
		"GÖVDE  •  %s" % str(summary.get("armor_name", "Gezgin Giysisi")),
		"HAREKET  •  %s" % str(summary.get("boots_name", "Yıpranmış Çizmeler")),
		"AKSESUAR  •  %s" % str(summary.get("ring_name", "Yüzük yok")),
		"",
		"Toplam hasar azaltma: %%%d" % int(summary.get("damage_reduction_percent", 0)),
		"Hareket hızı: %.1f" % float(summary.get("move_speed", 5.0)),
		"Zırh ve rün yüzüğü hasarı azaltır; çizmeler hareket hızını artırır."
	]
	equipment_text.text = "\n".join(PackedStringArray(rows))

func refresh_save_slots(slots: Array, selected_slot: int) -> void:
	selected_save_slot = clampi(selected_slot, 1, 3)
	var selected_info: Dictionary = {}
	for i in range(save_slot_buttons.size()):
		var slot_id := i + 1
		var info: Dictionary = {}
		for entry in slots:
			if entry is Dictionary and int(entry.get("slot", 0)) == slot_id:
				info = entry
				break
		var button := save_slot_buttons[i]
		var exists := bool(info.get("exists", false))
		var valid := bool(info.get("valid", true))
		var prefix := "▶ " if slot_id == selected_save_slot else ""
		if not exists:
			button.text = "%sYUVA %d  —  BOŞ / YENİ MACERA" % [prefix, slot_id]
		elif not valid:
			button.text = "%sYUVA %d  —  GEÇERSİZ KAYIT" % [prefix, slot_id]
		else:
			button.text = "%sYUVA %d  •  SV %d  •  %d ALTIN  •  KILIÇ %d  •  ZIRH %d" % [prefix, slot_id, int(info.get("level", 1)), int(info.get("gold", 0)), int(info.get("weapon_level", 1)), int(info.get("armor_level", 0))]
		if slot_id == selected_save_slot:
			selected_info = info
	if is_instance_valid(save_slot_load_button):
		save_slot_load_button.disabled = bool(selected_info.get("exists", false)) and not bool(selected_info.get("valid", true))

func _make_button(label_text: String, left: float, top: float, right: float, bottom: float, color: Color, font_size: int) -> Button:
	var button := Button.new()
	button.text = label_text
	button.anchor_left = 1.0
	button.anchor_right = 1.0
	button.anchor_top = 1.0
	button.anchor_bottom = 1.0
	button.offset_left = left
	button.offset_top = top
	button.offset_right = right
	button.offset_bottom = bottom
	button.add_theme_font_size_override("font_size", font_size)
	button.add_theme_color_override("font_color", Color("#fff0d1"))
	button.add_theme_stylebox_override("normal", _panel_style(color, Color("#d3b57a")))
	button.add_theme_stylebox_override("hover", _panel_style(color.lightened(0.15), Color("#f0d59a")))
	button.add_theme_stylebox_override("pressed", _panel_style(color.darkened(0.22), Color("#ffe2a1")))
	root_control.add_child(button)
	return button

func update_status(current_health: float, maximum_health: float, kills: int, level: int, enemy_count: int, ally_count: int, summon_cooldown: float, current_xp: int = 0, xp_goal: int = 100, gold: int = 0, mission: String = "KEŞİF", weapon_level: int = 1, armor_level: int = 0, weapon_name: String = "Uzun Kılıç", stamina_value: float = 100.0, stamina_maximum: float = 100.0) -> void:
	if is_instance_valid(health_bar):
		health_bar.max_value = maximum_health
		health_bar.value = current_health
		health_text.text = "KOMUTAN  %d / %d" % [roundi(current_health), roundi(maximum_health)]
	if is_instance_valid(xp_bar):
		xp_bar.max_value = maxi(1, xp_goal)
		xp_bar.value = current_xp
	if is_instance_valid(mission_label):
		mission_label.text = "GÖREV  •  " + mission
	if is_instance_valid(stats_label):
		stats_label.text = "SV %d  •  XP %d/%d  •  ALTIN %d  •  YENİLEN %d  •  YARATIK %d  •  BİRLİK %d  •  SİLAH: %s  •  ZIRH %d" % [level, current_xp, xp_goal, gold, kills, enemy_count, ally_count, weapon_name, armor_level]
	if is_instance_valid(stamina_bar):
		stamina_bar.max_value = maxf(1.0, stamina_maximum)
		stamina_bar.value = clampf(stamina_value, 0.0, stamina_maximum)
	if is_instance_valid(troops_button):
		if summon_cooldown > 0.0:
			troops_button.text = "DESTEK %ds" % ceili(summon_cooldown)
		elif ally_count >= 10:
			troops_button.text = "ASKER SINIRI"
		else:
			troops_button.text = "DESTEK"

func update_world_info(world_position: Vector3, region_name: String) -> void:
	if is_instance_valid(region_label):
		region_label.text = "BÖLGE: " + region_name
	if is_instance_valid(radar) and radar.has_method("set_world_position"):
		radar.set_world_position(world_position)

func set_notice(message: String) -> void:
	if is_instance_valid(status_label):
		status_label.text = message

func is_ui_point(point: Vector2) -> bool:
	if is_instance_valid(joystick) and joystick.get_global_rect().has_point(point):
		return true
	for panel in [inventory_panel, crafting_panel, equipment_panel, save_slots_panel, army_panel, kingdom_panel, siege_panel, settlement_panel, quest_panel, companion_panel, skills_panel, graphics_panel, story_choice_panel]:
		if is_instance_valid(panel) and panel.visible and panel.get_global_rect().has_point(point):
			return true
	if is_instance_valid(utility_panel) and utility_panel.get_global_rect().has_point(point):
		return true
	for button in ui_buttons:
		if is_instance_valid(button) and button.get_global_rect().has_point(point):
			return true
	return false

func show_game_over(kills: int, level: int) -> void:
	if is_instance_valid(end_overlay):
		return
	end_overlay = Control.new()
	end_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	end_overlay.mouse_filter = Control.MOUSE_FILTER_STOP
	root_control.add_child(end_overlay)
	var dimmer := ColorRect.new()
	dimmer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	dimmer.color = Color(0.015, 0.02, 0.03, 0.82)
	end_overlay.add_child(dimmer)
	var panel := PanelContainer.new()
	panel.anchor_left = 0.5
	panel.anchor_right = 0.5
	panel.anchor_top = 0.5
	panel.anchor_bottom = 0.5
	panel.offset_left = -220
	panel.offset_right = 220
	panel.offset_top = -145
	panel.offset_bottom = 145
	panel.add_theme_stylebox_override("panel", _panel_style(Color("#18242a"), Color("#d1ad63")))
	end_overlay.add_child(panel)
	var column := VBoxContainer.new()
	column.alignment = BoxContainer.ALIGNMENT_CENTER
	column.add_theme_constant_override("separation", 18)
	panel.add_child(column)
	var title := Label.new()
	title.text = "YOLCULUK SONLANDI"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 28)
	title.add_theme_color_override("font_color", Color("#f0d29a"))
	column.add_child(title)
	var result := Label.new()
	result.text = "Seviye: %d    •    Yenilen düşman: %d" % [level, kills]
	result.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	result.add_theme_font_size_override("font_size", 18)
	column.add_child(result)
	var restart := Button.new()
	restart.text = "YENİDEN BAŞLA"
	restart.custom_minimum_size = Vector2(180, 48)
	restart.add_theme_font_size_override("font_size", 18)
	restart.add_theme_stylebox_override("normal", _panel_style(Color("#77582f"), Color("#e7c783")))
	restart.pressed.connect(func() -> void: restart_pressed.emit())
	column.add_child(restart)

func _panel_style(background_color: Color, border_color: Color) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = background_color
	style.border_color = border_color
	style.set_border_width_all(2)
	style.set_corner_radius_all(8)
	style.content_margin_left = 10
	style.content_margin_right = 10
	style.content_margin_top = 6
	style.content_margin_bottom = 6
	return style

func _flat_style(background_color: Color) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = background_color
	style.set_corner_radius_all(5)
	return style
