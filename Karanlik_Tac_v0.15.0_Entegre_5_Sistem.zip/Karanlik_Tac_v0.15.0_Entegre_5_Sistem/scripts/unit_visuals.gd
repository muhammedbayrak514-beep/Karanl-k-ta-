extends Node3D

var weapon_pivot: Node3D
var shield_mesh: MeshInstance3D
var player_team: int = -1
var player_gear_root: Node3D
var visual_class: String = "infantry"

func setup(team_id: int, class_id: String = "infantry") -> void:
	visual_class = class_id
	player_team = team_id
	var armor_color := Color("#263d54")
	var trim_color := Color("#d5ad59")
	var cloth_color := Color("#4a2230")
	var skin_color := Color("#bd9270")
	var leather_color := Color("#342b28")
	if team_id == 1:
		armor_color = Color("#73342f")
		trim_color = Color("#bd7854")
		cloth_color = Color("#35191e")
	elif team_id == 2:
		armor_color = Color("#245b69")
		trim_color = Color("#a9c4bd")
		cloth_color = Color("#153b45")
	if class_id == "archer":
		armor_color = Color("#496746") if team_id == 2 else Color("#56503a")
		trim_color = Color("#d9c783")
		cloth_color = Color("#263e2b") if team_id == 2 else Color("#362f22")
	elif class_id == "cavalry":
		armor_color = Color("#3c4962") if team_id == 2 else Color("#62302c")
		trim_color = Color("#dcb66d")
		cloth_color = Color("#202d45") if team_id == 2 else Color("#35191e")
	elif class_id == "shield_guard":
		armor_color = Color("#243b4b") if team_id == 2 else Color("#542d2e")
		trim_color = Color("#c9d3d8")
		cloth_color = Color("#182b36") if team_id == 2 else Color("#32191e")
	elif class_id == "crossbowman":
		armor_color = Color("#46563a") if team_id == 2 else Color("#62503b")
		trim_color = Color("#d6c07e")
		cloth_color = Color("#273723") if team_id == 2 else Color("#35291f")

	var armor := _material(armor_color, 0.76, 0.12)
	var trim := _material(trim_color, 0.42, 0.28)
	var cloth := _material(cloth_color, 0.94, 0.0)
	var skin := _material(skin_color, 0.9, 0.0)
	var leather := _material(leather_color, 0.84, 0.0)
	var steel := _material(Color("#c5d0d6"), 0.28, 0.62)
	var dark_steel := _material(Color("#596875"), 0.38, 0.5)

	_add_capsule("Torso", 0.86, 0.32, Vector3(0, 1.13, 0), armor)
	_add_box("ChestPlate", Vector3(0.57, 0.62, 0.11), Vector3(0, 1.22, -0.205), trim)
	_add_box("ChestInset", Vector3(0.44, 0.48, 0.035), Vector3(0, 1.22, -0.27), armor)
	_add_box("ChainmailCollar", Vector3(0.38, 0.12, 0.12), Vector3(0, 1.57, -0.15), dark_steel)
	_add_sphere("LeftShoulderPauldron", 0.22, Vector3(-0.43, 1.47, -0.015), trim)
	_add_sphere("RightShoulderPauldron", 0.22, Vector3(0.43, 1.47, -0.015), trim)
	_add_box("ChestSigil", Vector3(0.12, 0.25, 0.045), Vector3(0, 1.23, -0.3), trim)
	_add_capsule("Neck", 0.22, 0.12, Vector3(0, 1.65, 0), skin)
	_add_sphere("Head", 0.205, Vector3(0, 1.82, -0.015), skin)
	_add_cylinder("Helmet", 0.22, 0.24, 0.16, Vector3(0, 1.99, 0), trim)
	_add_cylinder("HelmetRidge", 0.025, 0.035, 0.5, Vector3(0, 2.1, 0), armor)
	_add_box("HelmetNoseGuard", Vector3(0.055, 0.19, 0.06), Vector3(0, 1.86, -0.21), steel)

	_add_capsule("LeftArm", 0.64, 0.135, Vector3(-0.43, 1.22, 0), armor)
	_add_capsule("RightArm", 0.64, 0.135, Vector3(0.43, 1.22, -0.01), armor)
	_add_capsule("LeftGlove", 0.22, 0.13, Vector3(-0.45, 0.88, -0.03), leather)
	_add_capsule("RightGlove", 0.22, 0.13, Vector3(0.46, 0.88, -0.04), leather)
	_add_capsule("LeftLeg", 0.76, 0.15, Vector3(-0.18, 0.43, 0), leather)
	_add_capsule("RightLeg", 0.76, 0.15, Vector3(0.18, 0.43, 0), leather)
	_add_box("LeftKneeGuard", Vector3(0.25, 0.2, 0.12), Vector3(-0.18, 0.48, -0.13), steel)
	_add_box("RightKneeGuard", Vector3(0.25, 0.2, 0.12), Vector3(0.18, 0.48, -0.13), steel)
	_add_box("LeftBootRim", Vector3(0.28, 0.11, 0.3), Vector3(-0.18, 0.12, -0.06), trim)
	_add_box("RightBootRim", Vector3(0.28, 0.11, 0.3), Vector3(0.18, 0.12, -0.06), trim)
	_add_box("Cape", Vector3(0.5, 0.77, 0.055), Vector3(0, 1.2, 0.205), cloth)
	_add_box("Belt", Vector3(0.62, 0.12, 0.37), Vector3(0, 0.84, 0), leather)
	_add_box("BeltBuckle", Vector3(0.13, 0.12, 0.04), Vector3(0, 0.84, -0.2), trim)
	_add_box("LeftBeltPouch", Vector3(0.18, 0.24, 0.17), Vector3(-0.39, 0.82, -0.05), leather)
	_add_box("RightBeltPouch", Vector3(0.18, 0.24, 0.17), Vector3(0.39, 0.82, -0.05), leather)
	_add_box("CapeClasp", Vector3(0.2, 0.18, 0.08), Vector3(0, 1.56, 0.22), trim)

	shield_mesh = _add_box("Shield", Vector3(0.31, 0.47, 0.10), Vector3(-0.54, 1.05, -0.09), dark_steel)
	_add_box("ShieldBoss", Vector3(0.13, 0.17, 0.035), Vector3(-0.54, 1.06, -0.16), trim)
	_add_box("ShieldHeraldry", Vector3(0.075, 0.28, 0.025), Vector3(-0.54, 1.06, -0.19), trim)

	weapon_pivot = Node3D.new()
	weapon_pivot.name = "WeaponPivot"
	weapon_pivot.position = Vector3(0.48, 1.2, -0.12)
	add_child(weapon_pivot)
	_add_box_to(weapon_pivot, "SwordBlade", Vector3(0.075, 0.78, 0.045), Vector3(0, 0.48, 0), steel)
	_add_box_to(weapon_pivot, "SwordEdge", Vector3(0.018, 0.69, 0.012), Vector3(0.04, 0.49, -0.027), dark_steel)
	_add_box_to(weapon_pivot, "SwordGuard", Vector3(0.28, 0.055, 0.09), Vector3(0, 0.065, 0), trim)
	_add_box_to(weapon_pivot, "SwordGrip", Vector3(0.085, 0.23, 0.085), Vector3(0, -0.06, 0), leather)
	_add_box_to(weapon_pivot, "SwordPommel", Vector3(0.12, 0.085, 0.095), Vector3(0, -0.19, 0), trim)

	if class_id in ["archer", "crossbowman"]:
		shield_mesh.visible = false
		for weapon_piece in weapon_pivot.get_children():
			weapon_piece.visible = false
		var bow_material := _material(Color("#523a27"), 0.72, 0.03)
		var bow_string := _material(Color("#d6d1bd"), 0.78, 0.0)
		if class_id == "crossbowman":
			_add_box_to(weapon_pivot, "CrossbowStock", Vector3(0.12, 0.18, 0.82), Vector3(0.0, 0.46, -0.27), bow_material)
			_add_box_to(weapon_pivot, "CrossbowProd", Vector3(0.92, 0.085, 0.1), Vector3(0.0, 0.54, -0.43), steel)
			_add_box_to(weapon_pivot, "CrossbowString", Vector3(0.025, 0.58, 0.025), Vector3(0.0, 0.54, -0.43), bow_string)
			_add_box_to(weapon_pivot, "CrossbowTrigger", Vector3(0.09, 0.22, 0.1), Vector3(0.0, 0.28, -0.12), leather)
		else:
			var bow_upper := _add_capsule_to(weapon_pivot, "BowUpperLimb", 0.5, 0.035, Vector3(0.02, 0.47, 0), bow_material)
			bow_upper.rotation.z = -0.27
			var bow_lower := _add_capsule_to(weapon_pivot, "BowLowerLimb", 0.5, 0.035, Vector3(0.02, 0.0, 0), bow_material)
			bow_lower.rotation.z = 0.27
			_add_box_to(weapon_pivot, "BowString", Vector3(0.018, 0.9, 0.018), Vector3(-0.015, 0.24, 0.01), bow_string)
	elif class_id == "shield_guard":
		shield_mesh.scale = Vector3(1.35, 1.32, 1.08)
	elif class_id == "cavalry":
		for weapon_piece in weapon_pivot.get_children():
			weapon_piece.visible = false
		_add_box_to(weapon_pivot, "LanceShaft", Vector3(0.055, 0.055, 1.38), Vector3(0.0, 0.56, -0.48), leather)
		var lance_head_mesh := ConeMesh.new()
		lance_head_mesh.top_radius = 0.0
		lance_head_mesh.bottom_radius = 0.09
		lance_head_mesh.height = 0.25
		var lance_head := MeshInstance3D.new()
		lance_head.name = "LanceHead"
		lance_head.mesh = lance_head_mesh
		lance_head.position = Vector3(0.0, 0.56, -1.25)
		lance_head.rotation.x = -PI * 0.5
		lance_head.material_override = steel
		weapon_pivot.add_child(lance_head)
		if team_id == 2:
			for part_name in ["LeftLeg", "RightLeg", "LeftBootRim", "RightBootRim"]:
				var leg_part := get_node_or_null(NodePath(part_name))
				if is_instance_valid(leg_part):
					leg_part.visible = false
			_add_mount_visuals(leather, skin, trim, armor)

func _add_mount_visuals(leather: Material, skin: Material, trim: Material, barding: Material) -> void:
	var horse_body_mesh := CapsuleMesh.new()
	horse_body_mesh.radius = 0.34
	horse_body_mesh.height = 1.08
	var horse_body := MeshInstance3D.new()
	horse_body.name = "WarhorseBody"
	horse_body.mesh = horse_body_mesh
	horse_body.position = Vector3(0.0, 0.73, 0.2)
	horse_body.rotation.x = PI * 0.5
	horse_body.scale = Vector3(0.92, 1.12, 0.92)
	horse_body.material_override = _material(Color("#68462f"), 0.88, 0.0)
	add_child(horse_body)

	var horse_neck_mesh := CapsuleMesh.new()
	horse_neck_mesh.radius = 0.17
	horse_neck_mesh.height = 0.7
	var horse_neck := MeshInstance3D.new()
	horse_neck.name = "WarhorseNeck"
	horse_neck.mesh = horse_neck_mesh
	horse_neck.position = Vector3(0.0, 0.93, -0.42)
	horse_neck.rotation.x = -0.28
	horse_neck.material_override = _material(Color("#755038"), 0.9, 0.0)
	add_child(horse_neck)
	_add_sphere("WarhorseHead", 0.19, Vector3(0.0, 1.17, -0.69), _material(Color("#755038"), 0.9, 0.0))
	_add_sphere("WarhorseMuzzle", 0.105, Vector3(0.0, 1.1, -0.84), skin)
	_add_box("WarhorseBarding", Vector3(0.48, 0.32, 0.62), Vector3(0.0, 0.69, 0.12), barding)
	_add_box("WarhorseHarness", Vector3(0.52, 0.07, 0.64), Vector3(0.0, 0.62, 0.12), leather)
	_add_box("WarhorseForeheadPlate", Vector3(0.21, 0.25, 0.09), Vector3(0.0, 1.25, -0.81), trim)
	for x in [-0.22, 0.22]:
		for z in [-0.15, 0.49]:
			var leg_mesh := CapsuleMesh.new()
			leg_mesh.radius = 0.075
			leg_mesh.height = 0.58
			var horse_leg := MeshInstance3D.new()
			horse_leg.name = "WarhorseLeg_%s_%s" % [str(x), str(z)]
			horse_leg.mesh = leg_mesh
			horse_leg.position = Vector3(x, 0.32, z)
			horse_leg.material_override = leather
			add_child(horse_leg)

func set_equipment_appearance(armor_level: int, boots_level: int, ring_level: int) -> void:
	if player_team != 0:
		return
	if is_instance_valid(player_gear_root):
		player_gear_root.queue_free()
	player_gear_root = Node3D.new()
	player_gear_root.name = "CraftedEquipmentVisuals"
	add_child(player_gear_root)
	if armor_level > 0:
		var armor_colors := [Color("#71513b"), Color("#65727a"), Color("#9a7845")]
		var armor_color: Color = armor_colors[clampi(armor_level - 1, 0, armor_colors.size() - 1)]
		var crafted_armor := _material(armor_color, 0.48, 0.28)
		var leather_straps := _material(Color("#302b2a"), 0.88, 0.02)
		_add_box_to(player_gear_root, "CraftedChestplate", Vector3(0.63, 0.53, 0.14), Vector3(0, 1.22, -0.325), crafted_armor)
		_add_box_to(player_gear_root, "ChestplateRim", Vector3(0.66, 0.065, 0.15), Vector3(0, 1.49, -0.32), crafted_armor)
		_add_box_to(player_gear_root, "ArmorBeltStrap", Vector3(0.66, 0.09, 0.405), Vector3(0, 0.91, 0), leather_straps)
		if armor_level >= 2:
			_add_sphere_to(player_gear_root, "ReinforcedLeftPauldron", 0.24, Vector3(-0.43, 1.49, -0.015), crafted_armor)
			_add_sphere_to(player_gear_root, "ReinforcedRightPauldron", 0.24, Vector3(0.43, 1.49, -0.015), crafted_armor)
		if armor_level >= 3:
			var dragon_trim := _material(Color("#d5a75b"), 0.32, 0.62)
			_add_box_to(player_gear_root, "DragonCrest", Vector3(0.11, 0.27, 0.05), Vector3(0, 1.23, -0.41), dragon_trim)
			_add_box_to(player_gear_root, "DragonShoulderLeft", Vector3(0.25, 0.12, 0.24), Vector3(-0.45, 1.59, -0.015), dragon_trim)
			_add_box_to(player_gear_root, "DragonShoulderRight", Vector3(0.25, 0.12, 0.24), Vector3(0.45, 1.59, -0.015), dragon_trim)
	if boots_level > 0:
		var boot_color := _material(Color("#5a3d2c") if boots_level == 1 else Color("#302f50"), 0.68, 0.05)
		_add_box_to(player_gear_root, "CraftedLeftBoot", Vector3(0.31, 0.22, 0.36), Vector3(-0.18, 0.13, -0.07), boot_color)
		_add_box_to(player_gear_root, "CraftedRightBoot", Vector3(0.31, 0.22, 0.36), Vector3(0.18, 0.13, -0.07), boot_color)
		if boots_level >= 2:
			var rune_material := _material(Color("#9278ef"), 0.36, 0.28)
			rune_material.emission_enabled = true
			rune_material.emission = Color("#6f5bd9")
			rune_material.emission_energy_multiplier = 0.45
			_add_box_to(player_gear_root, "LeftBootRune", Vector3(0.06, 0.14, 0.03), Vector3(-0.18, 0.16, -0.26), rune_material)
			_add_box_to(player_gear_root, "RightBootRune", Vector3(0.06, 0.14, 0.03), Vector3(0.18, 0.16, -0.26), rune_material)
	if ring_level > 0:
		var rune_color := Color("#79dfd4") if ring_level == 1 else Color("#b18cff")
		var rune := _material(rune_color, 0.3, 0.3)
		rune.emission_enabled = true
		rune.emission = rune_color
		rune.emission_energy_multiplier = 1.3
		_add_sphere_to(player_gear_root, "RuneRingGlow", 0.075, Vector3(0.47, 0.86, -0.15), rune)

func _add_sphere_to(parent: Node3D, node_name: String, radius: float, at: Vector3, material: Material) -> MeshInstance3D:
	var mesh := SphereMesh.new()
	mesh.radius = radius
	mesh.height = radius * 2.0
	var instance := MeshInstance3D.new()
	instance.name = node_name
	instance.mesh = mesh
	instance.material_override = material
	instance.position = at
	parent.add_child(instance)
	return instance

func _material(color: Color, roughness: float, metallic: float) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.roughness = roughness
	material.metallic = metallic
	return material

func _add_capsule_to(parent: Node3D, node_name: String, height: float, radius: float, at: Vector3, material: Material) -> MeshInstance3D:
	var mesh := CapsuleMesh.new()
	mesh.height = height
	mesh.radius = radius
	var instance := MeshInstance3D.new()
	instance.name = node_name
	instance.mesh = mesh
	instance.material_override = material
	instance.position = at
	parent.add_child(instance)
	return instance

func _add_capsule(node_name: String, height: float, radius: float, at: Vector3, material: Material) -> MeshInstance3D:
	var mesh := CapsuleMesh.new()
	mesh.height = height
	mesh.radius = radius
	var instance := MeshInstance3D.new()
	instance.name = node_name
	instance.mesh = mesh
	instance.material_override = material
	instance.position = at
	add_child(instance)
	return instance

func _add_sphere(node_name: String, radius: float, at: Vector3, material: Material) -> MeshInstance3D:
	var mesh := SphereMesh.new()
	mesh.radius = radius
	mesh.height = radius * 2.0
	var instance := MeshInstance3D.new()
	instance.name = node_name
	instance.mesh = mesh
	instance.material_override = material
	instance.position = at
	add_child(instance)
	return instance

func _add_cylinder(node_name: String, top_radius: float, bottom_radius: float, height: float, at: Vector3, material: Material) -> MeshInstance3D:
	var mesh := CylinderMesh.new()
	mesh.top_radius = top_radius
	mesh.bottom_radius = bottom_radius
	mesh.height = height
	var instance := MeshInstance3D.new()
	instance.name = node_name
	instance.mesh = mesh
	instance.material_override = material
	instance.position = at
	add_child(instance)
	return instance

func _add_box(node_name: String, dimensions: Vector3, at: Vector3, material: Material) -> MeshInstance3D:
	return _add_box_to(self, node_name, dimensions, at, material)

func _add_box_to(parent: Node3D, node_name: String, dimensions: Vector3, at: Vector3, material: Material) -> MeshInstance3D:
	var mesh := BoxMesh.new()
	mesh.size = dimensions
	var instance := MeshInstance3D.new()
	instance.name = node_name
	instance.mesh = mesh
	instance.material_override = material
	instance.position = at
	parent.add_child(instance)
	return instance


func set_weapon_style(weapon_id: String) -> void:
	if player_team != 0 or not is_instance_valid(weapon_pivot) or visual_class != "infantry":
		return
	var new_nodes := ["V09SpearShaft", "V09SpearHead", "V09AxeHaft", "V09AxeHead", "V09AxeEdge"]
	for piece in weapon_pivot.get_children():
		if piece.name in new_nodes:
			piece.visible = false
		else:
			piece.visible = weapon_id in ["sword", "greatsword"]
	weapon_pivot.scale = Vector3.ONE * (1.42 if weapon_id == "greatsword" else 1.0)
	var leather := _material(Color("#5a3c28"), 0.86, 0.0)
	var steel := _material(Color("#c8d4dd"), 0.28, 0.62)
	var dark_steel := _material(Color("#687780"), 0.34, 0.48)
	if weapon_pivot.get_node_or_null("V09SpearShaft") == null:
		_add_box_to(weapon_pivot, "V09SpearShaft", Vector3(0.065, 0.065, 2.18), Vector3(0.0, 0.55, -0.52), leather)
		var head_mesh := ConeMesh.new()
		head_mesh.top_radius = 0.0
		head_mesh.bottom_radius = 0.105
		head_mesh.height = 0.32
		var head := MeshInstance3D.new()
		head.name = "V09SpearHead"
		head.mesh = head_mesh
		head.position = Vector3(0.0, 0.55, -1.72)
		head.rotation.x = PI * 0.5
		head.material_override = steel
		weapon_pivot.add_child(head)
	if weapon_pivot.get_node_or_null("V09AxeHaft") == null:
		_add_box_to(weapon_pivot, "V09AxeHaft", Vector3(0.075, 0.075, 1.05), Vector3(0.0, 0.33, -0.02), leather)
		_add_box_to(weapon_pivot, "V09AxeHead", Vector3(0.38, 0.32, 0.12), Vector3(0.14, 0.77, -0.04), dark_steel)
		_add_box_to(weapon_pivot, "V09AxeEdge", Vector3(0.1, 0.29, 0.15), Vector3(0.34, 0.77, -0.04), steel)
	for piece in weapon_pivot.get_children():
		if piece.name in new_nodes:
			piece.visible = (weapon_id == "spear" and str(piece.name).begins_with("V09Spear")) or (weapon_id == "axe" and str(piece.name).begins_with("V09Axe"))
		elif str(piece.name).begins_with("Sword"):
			piece.visible = weapon_id in ["sword", "greatsword"]
