extends Node

const CaravanScript = preload("res://scripts/caravan_agent.gd")
const WEATHER_IDS: Array[String] = ["clear", "rain", "fog", "snow"]
const EVENT_IDS: Array[String] = ["harvest_festival", "trade_boom", "bandit_surge", "lost_cache"]

var game_ref: Variant = null
var arena_ref: Variant = null
var current_weather: String = "clear"
var active_event: String = ""
var event_remaining: float = 0.0
var weather_remaining: float = 70.0
var event_check_remaining: float = 24.0
var day_elapsed: float = 0.0
var world_day: int = 1
var caravans: Array[Node] = []
var _rng := RandomNumberGenerator.new()
var _last_event_day: int = -1
var event_serial: int = 0
var lost_cache_id: String = ""

func initialize(game: Variant, arena: Variant, saved_state: Dictionary = {}) -> void:
	game_ref = game
	arena_ref = arena
	_rng.randomize()
	current_weather = str(saved_state.get("weather", "clear"))
	if current_weather not in WEATHER_IDS:
		current_weather = "clear"
	active_event = str(saved_state.get("active_event", ""))
	if active_event not in EVENT_IDS:
		active_event = ""
	event_remaining = clampf(float(saved_state.get("event_remaining", 0.0)), 0.0, 240.0)
	weather_remaining = clampf(float(saved_state.get("weather_remaining", 70.0)), 5.0, 180.0)
	day_elapsed = clampf(float(saved_state.get("day_elapsed", 0.0)), 0.0, 60.0)
	world_day = maxi(1, int(saved_state.get("world_day", 1)))
	_last_event_day = int(saved_state.get("last_event_day", -1))
	event_serial = maxi(0, int(saved_state.get("event_serial", 0)))
	lost_cache_id = str(saved_state.get("lost_cache_id", ""))
	event_check_remaining = clampf(float(saved_state.get("event_check_remaining", 24.0)), 1.0, 90.0)
	_create_caravans(saved_state.get("caravans", {}))
	if not lost_cache_id.is_empty() and is_instance_valid(game_ref) and not game_ref.opened_chest_ids.has(lost_cache_id):
		game_ref._spawn_chest(lost_cache_id, Vector3(-128, 0, 118), 85, 100)
	# Transient event bandits are not saved as individual units, so restore them
	# whenever a save is loaded in the middle of that world event.
	if active_event == "bandit_surge" and event_remaining > 0.0 and is_instance_valid(game_ref):
		game_ref.spawn_world_event_bandits(Vector3(-205, 0, 83))
	if is_instance_valid(arena_ref) and arena_ref.has_method("set_weather"):
		arena_ref.set_weather(current_weather, _player_position())

func _process(delta: float) -> void:
	if not is_instance_valid(game_ref) or game_ref.game_over:
		return
	weather_remaining -= delta
	event_remaining -= delta
	day_elapsed += delta
	if is_instance_valid(arena_ref) and arena_ref.has_method("update_weather_center"):
		arena_ref.update_weather_center(_player_position())
	if weather_remaining <= 0.0:
		weather_remaining = _rng.randf_range(65.0, 105.0)
		var options: Array[String] = WEATHER_IDS.duplicate()
		options.erase(current_weather)
		current_weather = options[_rng.randi_range(0, options.size() - 1)]
		if is_instance_valid(arena_ref) and arena_ref.has_method("set_weather"):
			arena_ref.set_weather(current_weather, _player_position())
		if is_instance_valid(game_ref):
			game_ref.show_notice("Hava değişti: %s. Görüş ve atmosfer koşulları yenilendi." % _weather_name(current_weather))
			game_ref._mark_progress_dirty()
	if event_remaining <= 0.0 and not active_event.is_empty():
		active_event = ""
		event_check_remaining = 28.0
		if is_instance_valid(game_ref):
			game_ref.show_notice("Dünya olayı sona erdi. Ticaret koşulları normale döndü.")
			game_ref._mark_progress_dirty()
	if active_event.is_empty():
		event_check_remaining -= delta
		if event_check_remaining <= 0.0:
			event_check_remaining = 28.0
			if _rng.randf() < 0.52:
				_start_world_event()
	if day_elapsed >= 60.0:
		day_elapsed = 0.0
		world_day += 1

func _create_caravans(saved_value: Variant) -> void:
	var saved: Dictionary = saved_value if saved_value is Dictionary else {}
	var routes: Array[Dictionary] = [
		{"id": "west_route", "name": "Batı Kervanı", "speed": 3.1, "points": [Vector3(88, 0, 30), Vector3(-160, 0, 70), Vector3(-345, 0, 42), Vector3(-160, 0, 70)]},
		{"id": "southern_route", "name": "Göl Tüccarları", "speed": 3.5, "points": [Vector3(0, 0, 8), Vector3(0, 0, 220), Vector3(295, 0, 298), Vector3(88, 0, 30)]},
		{"id": "eastern_route", "name": "Doğu Erzak Kervanı", "speed": 2.7, "points": [Vector3(88, 0, 30), Vector3(188, 0, 88), Vector3(362, 0, -20), Vector3(145, 0, -188)]}
	]
	for route_data in routes:
		var agent: Variant = CaravanScript.new()
		var id_value := str(route_data["id"])
		var route_points: Array[Vector3] = []
		for point_value in route_data["points"]:
			route_points.append(point_value)
		var one_saved: Dictionary = saved.get(id_value, {}) if saved.get(id_value, {}) is Dictionary else {}
		agent.configure(game_ref, id_value, str(route_data["name"]), route_points, one_saved)
		agent.move_speed = float(route_data["speed"])
		if is_instance_valid(game_ref):
			game_ref.add_child(agent)
			caravans.append(agent)

func _start_world_event() -> void:
	var options: Array[String] = EVENT_IDS.duplicate()
	options.erase(active_event)
	if not lost_cache_id.is_empty() and is_instance_valid(game_ref) and not game_ref.opened_chest_ids.has(lost_cache_id):
		# Keep an unclaimed world cache tracked until it is opened; avoid replacing
		# its ID with another cache before the first one has been collected.
		options.erase("lost_cache")
	if options.is_empty():
		return
	active_event = options[_rng.randi_range(0, options.size() - 1)]
	event_remaining = 95.0
	event_check_remaining = 28.0
	_last_event_day = world_day
	event_serial += 1
	var notice := ""
	match active_event:
		"harvest_festival":
			notice = "DÜNYA OLAYI: Hasat Şenliği. Kervanlar şifa iksirlerini indirimli satıyor."
		"trade_boom":
			notice = "DÜNYA OLAYI: Ticaret canlılığı. Kervanlar yaratık malzemelerine daha fazla altın veriyor."
		"bandit_surge":
			notice = "DÜNYA OLAYI: Haydut akını! Batı ticaret yolunda iki akıncı belirdi."
			if is_instance_valid(game_ref) and game_ref.has_method("spawn_world_event_bandits"):
				game_ref.spawn_world_event_bandits(Vector3(-205, 0, 83))
		"lost_cache":
			lost_cache_id = "Kayıp Kervan Sandığı %d-%d" % [world_day, event_serial]
			notice = "DÜNYA OLAYI: Bir kervan kayıp erzak sandığı bildirdi; batı yolu yakınında arayabilirsin."
			if is_instance_valid(game_ref) and game_ref.has_method("spawn_world_event_cache"):
				game_ref.spawn_world_event_cache(Vector3(-128, 0, 118), world_day, lost_cache_id)
	if is_instance_valid(game_ref):
		game_ref.show_notice(notice)
		game_ref._mark_progress_dirty()

func get_buy_price(base_price: int) -> int:
	var price := float(base_price)
	if active_event == "harvest_festival":
		price *= 0.65
	elif active_event == "bandit_surge":
		price *= 1.15
	return maxi(1, roundi(price))

func get_sell_price(base_price: int) -> int:
	var price := float(base_price)
	if active_event == "trade_boom":
		price *= 1.55
	elif active_event == "bandit_surge":
		price *= 0.8
	return maxi(1, roundi(price))

func get_world_status_text() -> String:
	var event_text := "olay yok"
	match active_event:
		"harvest_festival": event_text = "Hasat Şenliği"
		"trade_boom": event_text = "Ticaret canlılığı"
		"bandit_surge": event_text = "Haydut akını"
		"lost_cache": event_text = "Kayıp erzak"
	return "%s • %s" % [_weather_name(current_weather), event_text]

func get_save_state() -> Dictionary:
	var caravan_state: Dictionary = {}
	for agent in caravans:
		if is_instance_valid(agent) and agent.has_method("get_save_state"):
			caravan_state[str(agent.caravan_id)] = agent.get_save_state()
	return {"weather": current_weather, "active_event": active_event, "event_remaining": event_remaining, "weather_remaining": weather_remaining, "event_check_remaining": event_check_remaining, "day_elapsed": day_elapsed, "world_day": world_day, "last_event_day": _last_event_day, "event_serial": event_serial, "lost_cache_id": lost_cache_id, "caravans": caravan_state}

func _player_position() -> Vector3:
	if is_instance_valid(game_ref) and is_instance_valid(game_ref.player_unit):
		return game_ref.player_unit.global_position
	return Vector3.ZERO

func _weather_name(weather_id: String) -> String:
	match weather_id:
		"rain": return "Yağmur"
		"fog": return "Sis"
		"snow": return "Kar"
		_: return "Açık"
