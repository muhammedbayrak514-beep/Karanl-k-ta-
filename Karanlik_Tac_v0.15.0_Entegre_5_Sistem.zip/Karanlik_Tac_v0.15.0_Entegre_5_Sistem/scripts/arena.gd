extends Node3D

# Procedural open-world scene. Built from shared primitive meshes to keep the APK asset-free.
const WORLD_SIZE := 900.0
const NavigationScript = preload("res://scripts/world_navigation.gd")
const GRID_CELLS := 180
const CELL_SIZE := WORLD_SIZE / float(GRID_CELLS)
const FLAT_CENTRES = [Vector2(0, 8), Vector2(0, -33), Vector2(88, 30), Vector2(-160, 70), Vector2(-60, 170), Vector2(0, -245), Vector2(188, 88), Vector2(-218, -160), Vector2(145, -188), Vector2(0, 220), Vector2(68, -258), Vector2(-34, 164), Vector2(-345, 42), Vector2(-292, -325), Vector2(8, 350), Vector2(362, -20), Vector2(295, 298), Vector2(390, -20)]
const ROAD_SEGMENTS = [
	[Vector2(0, 8), Vector2(0, -37)],
	[Vector2(0, 8), Vector2(88, 30)],
	[Vector2(88, 30), Vector2(150, -178)],
	[Vector2(88, 30), Vector2(184, 85)],
	[Vector2(0, 8), Vector2(-160, 70)],
	[Vector2(-160, 70), Vector2(-218, -158)],
	[Vector2(0, 8), Vector2(0, 194)],
	[Vector2(0, 8), Vector2(-345, 42)],
	[Vector2(-345, 42), Vector2(-292, -325)],
	[Vector2(0, 8), Vector2(8, 350)],
	[Vector2(8, 350), Vector2(295, 298)],
	[Vector2(88, 30), Vector2(362, -20)],
	[Vector2(362, -20), Vector2(295, 298)],
	[Vector2(-345, 42), Vector2(-305, 240)]
]
const BIOME_ZONES = [
	{"p": Vector2(-160, 70), "r": 150.0, "c": Color("#355642")},
	{"p": Vector2(-60, 170), "r": 108.0, "c": Color("#3d5b45")},
	{"p": Vector2(10, -245), "r": 126.0, "c": Color("#aab8b5")},
	{"p": Vector2(188, 88), "r": 112.0, "c": Color("#485e50")},
	{"p": Vector2(-218, -160), "r": 126.0, "c": Color("#97805d")},
	{"p": Vector2(145, -188), "r": 92.0, "c": Color("#696b65")},
	{"p": Vector2(0, 220), "r": 96.0, "c": Color("#527052")},
	{"p": Vector2(-330, 42), "r": 132.0, "c": Color("#294337")},
	{"p": Vector2(-292, -325), "r": 92.0, "c": Color("#a8b8bc")},
	{"p": Vector2(8, 350), "r": 126.0, "c": Color("#625b50")},
	{"p": Vector2(362, -20), "r": 88.0, "c": Color("#526b73")},
	{"p": Vector2(295, 298), "r": 108.0, "c": Color("#9b825c")}
]

var rng := RandomNumberGenerator.new()
var world_environment: WorldEnvironment = null
var sun_light: DirectionalLight3D = null
var fill_light: DirectionalLight3D = null
var day_cycle_elapsed: float = 42.0
const DAY_CYCLE_SECONDS: float = 360.0
var navigation: Variant = null
var noise := FastNoiseLite.new()
var grass_mat: StandardMaterial3D
var path_mat: StandardMaterial3D
var stone_mat: StandardMaterial3D
var dark_stone_mat: StandardMaterial3D
var wood_mat: StandardMaterial3D
var roof_mat: StandardMaterial3D
var banner_red: StandardMaterial3D
var banner_blue: StandardMaterial3D
var leaf_mat: StandardMaterial3D
var pine_mat: StandardMaterial3D
var rock_mat: StandardMaterial3D
var snow_mat: StandardMaterial3D
var gold_mat: StandardMaterial3D
var water_mat: StandardMaterial3D
var weather_particles: CPUParticles3D = null
var current_weather: String = "clear"
var glow_blue: StandardMaterial3D
var glow_purple: StandardMaterial3D
var trunk_mesh: CylinderMesh
var pine_lower_mesh: CylinderMesh
var pine_upper_mesh: CylinderMesh
var rock_mesh: SphereMesh

func _ready() -> void:
	rng.seed = 472026
	noise.seed = 1357911
	noise.frequency = 0.018
	noise.fractal_octaves = 3
	grass_mat = _mat(Color("#526b49"), 1.0)
	path_mat = _mat(Color("#88765a"), 1.0)
	stone_mat = _mat(Color("#777c7e"), 0.9, 0.08)
	dark_stone_mat = _mat(Color("#3d454a"), 0.95)
	wood_mat = _mat(Color("#553a29"), 0.94)
	roof_mat = _mat(Color("#493b3b"), 0.94)
	banner_red = _mat(Color("#8e3034"), 0.86)
	banner_blue = _mat(Color("#285d77"), 0.86)
	leaf_mat = _mat(Color("#244735"), 1.0)
	pine_mat = _mat(Color("#315b40"), 1.0)
	rock_mat = _mat(Color("#62696b"), 0.98)
	snow_mat = _mat(Color("#cbd9d8"), 0.88)
	gold_mat = _mat(Color("#d5ad58"), 0.35, 0.55)
	water_mat = _mat(Color("#286b7b"), 0.23, 0.15)
	water_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	water_mat.albedo_color = Color(0.16, 0.42, 0.48, 0.82)
	glow_blue = _glow_mat(Color("#40c6d9"))
	glow_purple = _glow_mat(Color("#a66bff"))
	navigation = NavigationScript.new()
	navigation.configure(WORLD_SIZE, 2.5)
	trunk_mesh = CylinderMesh.new()
	trunk_mesh.top_radius = 0.15
	trunk_mesh.bottom_radius = 0.27
	trunk_mesh.height = 2.4
	pine_lower_mesh = CylinderMesh.new()
	pine_lower_mesh.top_radius = 0.02
	pine_lower_mesh.bottom_radius = 1.05
	pine_lower_mesh.height = 2.7
	pine_upper_mesh = CylinderMesh.new()
	pine_upper_mesh.top_radius = 0.01
	pine_upper_mesh.bottom_radius = 0.77
	pine_upper_mesh.height = 2.15
	rock_mesh = SphereMesh.new()
	rock_mesh.radius = 1.0
	rock_mesh.height = 2.0
	_make_environment()
	_make_terrain()
	_make_lake_and_river()
	_make_roads()
	_make_castle()
	_make_campaign_forts()
	_make_siege_engine()
	_make_village()
	_make_biome_landmarks()
	_make_v09_landmarks()
	_make_v10_landmarks()
	_make_forests_and_rocks()
	_make_boundary_ridges()
	_make_world_boundaries()
	_make_torches_and_runes()

func _process(delta: float) -> void:
	day_cycle_elapsed = fposmod(day_cycle_elapsed + delta, DAY_CYCLE_SECONDS)
	var phase := day_cycle_elapsed / DAY_CYCLE_SECONDS
	var daylight := clampf(maxf(0.0, sin(phase * TAU)) * 0.92 + 0.08, 0.08, 1.0)
	if is_instance_valid(sun_light):
		sun_light.rotation_degrees = Vector3(-90.0 + phase * 360.0, -28.0, 0.0)
		sun_light.light_energy = 0.08 + daylight * 1.25
		sun_light.light_color = Color("#8fb9e8").lerp(Color("#ffe1b5"), daylight)
	if is_instance_valid(fill_light):
		fill_light.light_energy = 0.08 + (1.0 - daylight) * 0.22
	if is_instance_valid(world_environment) and is_instance_valid(world_environment.environment):
		world_environment.environment.ambient_light_energy = 0.22 + daylight * 0.35
		world_environment.environment.fog_density = 0.0011 + (1.0 - daylight) * 0.00075

func apply_graphics_quality(quality_id: String) -> void:
	var quality := quality_id if quality_id in ["low", "balanced", "high"] else "balanced"
	var foliage_end := 0.0
	var rocks_end := 0.0
	var horizon_end := 0.0
	match quality:
		"low":
			foliage_end = 125.0
			rocks_end = 175.0
			horizon_end = 340.0
			if is_instance_valid(sun_light):
				sun_light.shadow_enabled = false
			if is_instance_valid(world_environment) and is_instance_valid(world_environment.environment):
				world_environment.environment.fog_enabled = false
				world_environment.environment.glow_enabled = false
		"balanced":
			foliage_end = 255.0
			rocks_end = 310.0
			horizon_end = 0.0
			if is_instance_valid(sun_light):
				sun_light.shadow_enabled = true
				sun_light.directional_shadow_max_distance = 68.0
			if is_instance_valid(world_environment) and is_instance_valid(world_environment.environment):
				world_environment.environment.fog_enabled = true
				world_environment.environment.glow_enabled = false
		"high":
			foliage_end = 0.0
			rocks_end = 0.0
			horizon_end = 0.0
			if is_instance_valid(sun_light):
				sun_light.shadow_enabled = true
				sun_light.directional_shadow_max_distance = 105.0
			if is_instance_valid(world_environment) and is_instance_valid(world_environment.environment):
				world_environment.environment.fog_enabled = true
				world_environment.environment.glow_enabled = true
	for item in get_tree().get_nodes_in_group("quality_foliage"):
		if item is GeometryInstance3D:
			item.visibility_range_end = foliage_end
	for item in get_tree().get_nodes_in_group("quality_rocks"):
		if item is GeometryInstance3D:
			item.visibility_range_end = rocks_end
	for item in get_tree().get_nodes_in_group("quality_horizon"):
		if item is GeometryInstance3D:
			item.visibility_range_end = horizon_end
	# Reduce draw submissions in low mode by hiding whole clusters, never individual parts of a tree.
	var foliage_clusters := get_tree().get_nodes_in_group("quality_foliage_cluster")
	for index in range(foliage_clusters.size()):
		var cluster: Node3D = foliage_clusters[index]
		cluster.visible = quality != "low" or index % 4 != 0
	var rock_nodes := get_tree().get_nodes_in_group("quality_rocks")
	for index in range(rock_nodes.size()):
		var rock_node: GeometryInstance3D = rock_nodes[index]
		rock_node.visible = quality != "low" or index % 4 != 0

func get_ground_height(x: float, z: float) -> float:
	return _terrain_height(x, z)

func get_navigation_path(start: Vector3, destination: Vector3) -> PackedVector3Array:
	if is_instance_valid(navigation):
		return navigation.find_path(start, destination)
	var fallback := PackedVector3Array()
	fallback.append(destination)
	return fallback

func is_navigation_position_walkable(position: Vector3) -> bool:
	return not is_instance_valid(navigation) or navigation.is_world_position_walkable(position)

func unregister_navigation_obstacle(center: Vector3, dimensions: Vector3) -> void:
	if is_instance_valid(navigation) and navigation.has_method("unregister_obstacle"):
		navigation.unregister_obstacle(center, dimensions)

func _register_navigation_obstacle(center: Vector3, dimensions: Vector3) -> void:
	if is_instance_valid(navigation):
		navigation.register_obstacle(center, dimensions)

func _make_environment() -> void:
	world_environment = WorldEnvironment.new()
	var world: WorldEnvironment = world_environment
	world.name = "WorldAtmosphere"
	var environment := Environment.new()
	environment.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	var sky_mat := ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = Color("#142a46")
	sky_mat.sky_horizon_color = Color("#d6a778")
	sky_mat.ground_bottom_color = Color("#222e31")
	sky_mat.ground_horizon_color = Color("#879080")
	sky_mat.sun_angle_max = 22.0
	sky_mat.use_debanding = true
	sky.sky_material = sky_mat
	environment.sky = sky
	environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	environment.ambient_light_color = Color("#a9b9bd")
	environment.ambient_light_energy = 0.72
	environment.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	environment.tonemap_exposure = 1.05
	environment.fog_enabled = true
	environment.fog_light_color = Color("#b3a18b")
	environment.fog_density = 0.00145
	environment.fog_sky_affect = 0.5
	environment.glow_enabled = true
	environment.glow_intensity = 0.45
	environment.glow_strength = 0.55
	environment.glow_bloom = 0.16
	environment.glow_hdr_threshold = 0.82
	world.environment = environment
	add_child(world)

	sun_light = DirectionalLight3D.new()
	var sun: DirectionalLight3D = sun_light
	sun.name = "GoldenHourSun"
	sun.rotation_degrees = Vector3(-42, -28, 0)
	sun.light_color = Color("#ffe0b2")
	sun.light_energy = 1.32
	sun.shadow_enabled = true
	sun.directional_shadow_max_distance = 105.0
	add_child(sun)

	fill_light = DirectionalLight3D.new()
	var fill: DirectionalLight3D = fill_light
	fill.name = "CoolSkyFill"
	fill.rotation_degrees = Vector3(-18, 145, 0)
	fill.light_color = Color("#8bb8d2")
	fill.light_energy = 0.26
	fill.shadow_enabled = false
	add_child(fill)

func _make_terrain() -> void:
	# A large vertex-coloured terrain mesh gives each region its own palette without external textures.
	var vertices := PackedVector3Array()
	var normals := PackedVector3Array()
	var colors := PackedColorArray()
	var uvs := PackedVector2Array()
	var indices := PackedInt32Array()
	var resolution := GRID_CELLS + 1
	vertices.resize(resolution * resolution)
	normals.resize(resolution * resolution)
	colors.resize(resolution * resolution)
	uvs.resize(resolution * resolution)
	indices.resize(GRID_CELLS * GRID_CELLS * 6)
	var half := WORLD_SIZE * 0.5
	for z in range(resolution):
		for x in range(resolution):
			var idx := z * resolution + x
			var px := -half + float(x) * CELL_SIZE
			var pz := -half + float(z) * CELL_SIZE
			vertices[idx] = Vector3(px, _terrain_height(px, pz), pz)
			uvs[idx] = Vector2(float(x) / GRID_CELLS, float(z) / GRID_CELLS)
			colors[idx] = _terrain_color(px, pz)
	for z in range(resolution):
		for x in range(resolution):
			var idx := z * resolution + x
			var left_h: float = vertices[z * resolution + maxi(0, x - 1)].y
			var right_h: float = vertices[z * resolution + mini(GRID_CELLS, x + 1)].y
			var back_h: float = vertices[maxi(0, z - 1) * resolution + x].y
			var front_h: float = vertices[mini(GRID_CELLS, z + 1) * resolution + x].y
			normals[idx] = Vector3(left_h - right_h, CELL_SIZE * 2.0, back_h - front_h).normalized()
	var write_idx := 0
	for z in range(GRID_CELLS):
		for x in range(GRID_CELLS):
			var a := z * resolution + x
			var b := a + resolution
			var c := a + 1
			var d := b + 1
			# Counter-clockwise from above: keep the surface visible from the sky.
			indices[write_idx] = a
			indices[write_idx + 1] = b
			indices[write_idx + 2] = c
			indices[write_idx + 3] = c
			indices[write_idx + 4] = b
			indices[write_idx + 5] = d
			write_idx += 6
	var arrays: Array = []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = vertices
	arrays[Mesh.ARRAY_NORMAL] = normals
	arrays[Mesh.ARRAY_COLOR] = colors
	arrays[Mesh.ARRAY_TEX_UV] = uvs
	arrays[Mesh.ARRAY_INDEX] = indices
	var terrain_mesh := ArrayMesh.new()
	terrain_mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	var terrain_material := StandardMaterial3D.new()
	terrain_material.vertex_color_use_as_albedo = true
	terrain_material.roughness = 1.0
	terrain_material.cull_mode = BaseMaterial3D.CULL_DISABLED
	var terrain := MeshInstance3D.new()
	terrain.name = "LivingWorldTerrain"
	terrain.mesh = terrain_mesh
	terrain.material_override = terrain_material
	add_child(terrain)

	# Concave collision follows the same gentle rolling ground mesh.
	var collision_faces := PackedVector3Array()
	collision_faces.resize(indices.size())
	for face_index in range(indices.size()):
		collision_faces[face_index] = vertices[indices[face_index]]
	var ground_body := StaticBody3D.new()
	ground_body.name = "WorldTerrainCollision"
	add_child(ground_body)
	var ground_shape := CollisionShape3D.new()
	var terrain_collision := ConcavePolygonShape3D.new()
	terrain_collision.set_faces(collision_faces)
	ground_shape.shape = terrain_collision
	ground_body.add_child(ground_shape)

func _terrain_height(x: float, z: float) -> float:
	var point := Vector2(x, z)
	var height := noise.get_noise_2d(x, z) * 3.1 + noise.get_noise_2d(x * 2.7, z * 2.7) * 0.48
	var flatness := 1.0
	for centre in FLAT_CENTRES:
		var distance := point.distance_to(centre)
		if distance < 40.0:
			var amount := clampf((distance - 16.0) / 24.0, 0.0, 1.0)
			flatness = minf(flatness, amount * amount * (3.0 - 2.0 * amount))
	for segment in ROAD_SEGMENTS:
		var a: Vector2 = segment[0]
		var b: Vector2 = segment[1]
		var nearest_t := clampf((point - a).dot(b - a) / maxf((b - a).length_squared(), 0.001), 0.0, 1.0)
		var road_distance := point.distance_to(a.lerp(b, nearest_t))
		if road_distance < 7.0:
			flatness = minf(flatness, clampf(road_distance / 7.0, 0.0, 1.0))
	# A level floor keeps the small eastern lagoon from being covered by procedural hills.
	if point.distance_to(Vector2(390, -20)) < 30.0:
		flatness = 0.0
	return height * flatness

func _terrain_color(x: float, z: float) -> Color:
	var color := Color("#62794e")
	# region centres and radii: forest, snow, marsh, badlands, ancient ruins.
	for zone in BIOME_ZONES:
		var distance := Vector2(x, z).distance_to(zone["p"])
		var radius: float = zone["r"]
		if distance < radius:
			var blend := clampf((radius - distance) / (radius * 0.34), 0.0, 1.0)
			blend = blend * blend * (3.0 - 2.0 * blend)
			color = color.lerp(zone["c"], blend * 0.94)
	var n := noise.get_noise_2d(x, z)
	var shade := clampf(n * 0.18, -0.14, 0.14)
	if shade >= 0.0:
		color = color.lightened(shade)
	else:
		color = color.darkened(-shade)
	return color

func _make_lake_and_river() -> void:
	var lake := _add_cylinder("MoonmereLake", 1.0, 1.0, 0.22, Vector3(0, -0.08, 220), water_mat, false)
	lake.scale = Vector3(37.0, 1.0, 28.0)
	# Reeds and lily pads give the lake edge detail.
	var reed_mat := _mat(Color("#657b47"), 0.98)
	for i in range(70):
		var angle := rng.randf_range(0.0, TAU)
		var radius := rng.randf_range(29.0, 41.0)
		var x := cos(angle) * radius
		var z := 220.0 + sin(angle) * radius * 0.73
		_add_cylinder("LakeReed", 0.025, 0.05, rng.randf_range(0.5, 1.25), Vector3(x, 0.46, z), reed_mat, false)
	for i in range(8):
		var angle := float(i) * TAU / 8.0
		var pad := _add_cylinder("WaterLily", 0.8, 0.8, 0.055, Vector3(cos(angle) * 14.0, 0.06, 220.0 + sin(angle) * 9.0), _mat(Color("#497850"), 1.0), false)
		pad.scale = Vector3(1.0, 1.0, 0.8)
	# A shallow, stylized river running through the eastern marsh.
	var river_mat := _mat(Color("#387887"), 0.3, 0.12)
	river_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	river_mat.albedo_color = Color(0.20, 0.43, 0.48, 0.72)
	for i in range(9):
		var z := 45.0 + float(i) * 13.0
		var x := 164.0 + sin(float(i) * 0.7) * 13.0
		var segment := _add_box("MarshWatercourse", Vector3(12.0, 0.05, 17.0), Vector3(x, 0.025, z), river_mat, false)
		segment.rotation.y = sin(float(i) * 0.9) * 0.18
	# Shallow eastern lagoon, levelled at the centre and linked visually to the watchpost dock.
	var lagoon := _add_cylinder("EasternWatchLagoon", 1.0, 1.0, 0.12, Vector3(390.0, -0.08, -20.0), water_mat, false)
	lagoon.scale = Vector3(24.0, 1.0, 30.0)

func _make_roads() -> void:
	# One route list drives terrain flattening and visible roads; the radar mirrors the main connections.
	for index in range(ROAD_SEGMENTS.size()):
		var segment: Array = ROAD_SEGMENTS[index]
		var a: Vector2 = segment[0]
		var b: Vector2 = segment[1]
		var road_width := 3.2
		if index == 0:
			road_width = 5.0
		elif index == 1 or index == 4:
			road_width = 4.0
		_add_path_segment(Vector3(a.x, 0.035, a.y), Vector3(b.x, 0.035, b.y), road_width)
	# Stone paving helps players identify the castle approach at a glance.
	for i in range(110):
		var x := rng.randf_range(-2.2, 2.2)
		var z := 23.0 - float(i) * 1.48
		var stone := _add_box("MainRoadCobble", Vector3(rng.randf_range(0.25, 0.75), 0.035, rng.randf_range(0.35, 0.85)), Vector3(x, 0.05, z), _mat(Color("#9e8b6c"), 1.0), false)
		stone.rotation.y = rng.randf_range(-0.25, 0.25)

func _add_path_segment(a: Vector3, b: Vector3, width: float) -> void:
	var direction := b - a
	var length := Vector2(direction.x, direction.z).length()
	var path := _add_box("AncientTradeRoad", Vector3(width, 0.055, length), (a + b) * 0.5, path_mat, false)
	path.rotation.y = atan2(direction.x, direction.z)
	# A few uneven edge stones visually break up the perfect rectangle.
	for i in range(maxi(2, int(length / 8.0))):
		if rng.randf() < 0.45:
			var t := rng.randf()
			var edge := -1.0 if rng.randf() < 0.5 else 1.0
			var side := Vector3(direction.z, 0, -direction.x).normalized() * edge * width * 0.68
			var p := a.lerp(b, t) + side
			var pebble := _add_box("RoadEdgeStone", Vector3(0.55, 0.1, 0.35), Vector3(p.x, 0.08, p.z), stone_mat, false)
			pebble.rotation.y = rng.randf_range(0.0, TAU)

func _make_castle() -> void:
	# Original keep retained, with layered stonework, gate details, and a new outer ward.
	_add_box("GatehouseLeftPier", Vector3(2.3, 8.3, 3.2), Vector3(-3.0, 4.15, -33.5), stone_mat, true)
	_add_box("GatehouseRightPier", Vector3(2.3, 8.3, 3.2), Vector3(3.0, 4.15, -33.5), stone_mat, true)
	_add_box("GateThreshold", Vector3(3.8, 0.08, 3.2), Vector3(0, 0.04, -31.8), dark_stone_mat, false)
	_add_box("GateLintel", Vector3(6.7, 1.35, 3.8), Vector3(0, 7.45, -33.5), dark_stone_mat, true)
	_add_box("LeftCurtainWall", Vector3(9.0, 6.0, 2.4), Vector3(-8.1, 3.0, -33.5), stone_mat, true)
	_add_box("RightCurtainWall", Vector3(9.0, 6.0, 2.4), Vector3(8.1, 3.0, -33.5), stone_mat, true)
	_add_box("LeftSideWall", Vector3(2.4, 6.0, 22.0), Vector3(-12.6, 3.0, -44.0), stone_mat, true)
	_add_box("RightSideWall", Vector3(2.4, 6.0, 22.0), Vector3(12.6, 3.0, -44.0), stone_mat, true)
	_add_box("InnerKeepWall", Vector3(24.0, 6.0, 2.0), Vector3(0, 3.0, -55.0), dark_stone_mat, true)
	_add_box("KeepCoping", Vector3(24.5, 0.5, 2.5), Vector3(0, 6.2, -55.0), stone_mat, false)
	_add_box("GateWoodenDoors", Vector3(3.2, 4.2, 0.4), Vector3(0, 2.15, -33.0), wood_mat, true)
	for side in [-1.0, 1.0]:
		var tower_x := side * 13.2
		_add_cylinder("KeepWatchTower", 2.05, 2.65, 10.4, Vector3(tower_x, 5.2, -33.8), dark_stone_mat, true)
		_add_cylinder("TowerCrown", 2.35, 2.35, 0.65, Vector3(tower_x, 10.45, -33.8), stone_mat, false)
		_add_cylinder("TowerRoof", 0.05, 2.15, 2.7, Vector3(tower_x, 12.0, -33.8), banner_red, false)
		_add_box("ArrowSlit", Vector3(0.22, 1.25, 0.11), Vector3(tower_x, 6.8, -31.15), dark_stone_mat, false)
		for bx in [-1.15, 1.15]:
			_add_box("TowerBattlement", Vector3(0.9, 0.85, 0.9), Vector3(tower_x + bx, 10.9, -33.8), stone_mat, false)
		_add_cylinder("BannerPole", 0.045, 0.045, 4.7, Vector3(side * 4.4, 2.35, -25.0), gold_mat, false)
		_add_box("RoyalBanner", Vector3(1.15, 1.5, 0.06), Vector3(side * 4.4 - side * 0.55, 3.2, -25.0), banner_red if side < 0 else banner_blue, false)
		_add_box("BannerSigil", Vector3(0.25, 0.58, 0.075), Vector3(side * 4.4 - side * 0.55, 3.2, -24.92), gold_mat, false)
	# Keep courtyard props and broken stones.
	_add_box("KeepCourtyardPlatform", Vector3(18, 0.12, 10), Vector3(0, 0.04, -44), path_mat, false)
	for i in range(22):
		var x := rng.randf_range(-17.0, 17.0)
		var z := rng.randf_range(-29.0, -23.0)
		var rubble := _add_box("FallenMasonry", Vector3(rng.randf_range(0.5, 1.5), rng.randf_range(0.2, 0.75), rng.randf_range(0.4, 1.35)), Vector3(x, 0.22, z), rock_mat, false)
		rubble.rotation = Vector3(rng.randf_range(-0.18, 0.18), rng.randf_range(0, TAU), rng.randf_range(-0.15, 0.15))
	_add_label("KARANLIK TAÇ KALESİ", Vector3(0, 14.8, -51), Color("#f5d6a0"), 62)

func _make_campaign_forts() -> void:
	# Two additional capture sites. Each has its own gate node and collision body,
	# allowing siege_manager.gd to keep independent durability/capture state.
	_make_small_fort("EastWatch", "DOĞU GÖZETLEME KALESİ", Vector3(362, 0, -20), banner_blue)
	_make_small_fort("FrostHold", "KARAKIŞ KAL'ASI", Vector3(-292, 0, -325), snow_mat)

func _make_small_fort(prefix: String, display_name: String, center: Vector3, banner_material: Material) -> void:
	var x := center.x
	var z := center.z
	# Wide, readable outer walls with a deliberate gate opening in the northern face.
	_add_box(prefix + "WestWall", Vector3(2.2, 5.5, 22.0), Vector3(x - 10.0, 2.75, z + 2.0), stone_mat, true)
	_add_box(prefix + "EastWall", Vector3(2.2, 5.5, 22.0), Vector3(x + 10.0, 2.75, z + 2.0), stone_mat, true)
	_add_box(prefix + "SouthWall", Vector3(22.0, 5.5, 2.2), Vector3(x, 2.75, z + 12.0), dark_stone_mat, true)
	_add_box(prefix + "NorthWallLeft", Vector3(7.0, 5.5, 2.2), Vector3(x - 7.5, 2.75, z - 8.0), stone_mat, true)
	_add_box(prefix + "NorthWallRight", Vector3(7.0, 5.5, 2.2), Vector3(x + 7.5, 2.75, z - 8.0), stone_mat, true)
	_add_box(prefix + "GateHeader", Vector3(8.0, 1.0, 2.5), Vector3(x, 5.25, z - 8.0), dark_stone_mat, true)
	var gate_name := "GateEastWatch" if prefix == "EastWatch" else "GateFrostHold"
	_add_box(gate_name, Vector3(3.8, 4.0, 0.45), Vector3(x, 2.0, z - 8.0), wood_mat, true)
	for side in [-1.0, 1.0]:
		_add_cylinder(prefix + "WatchTower", 1.35, 1.7, 8.0, Vector3(x + side * 12.4, 4.0, z - 7.5), dark_stone_mat, true)
		_add_cylinder(prefix + "TowerRoof", 0.05, 1.55, 2.1, Vector3(x + side * 12.4, 9.0, z - 7.5), banner_material, false)
		_add_box(prefix + "Banner", Vector3(0.9, 1.45, 0.08), Vector3(x + side * 5.0, 4.6, z - 4.2), banner_material, false)
	_add_box(prefix + "Courtyard", Vector3(14.5, 0.14, 11.5), Vector3(x, 0.07, z + 0.7), path_mat, false)
	_add_box(prefix + "Keep", Vector3(7.5, 6.8, 5.5), Vector3(x, 3.4, z + 5.5), dark_stone_mat, true)
	_add_label(display_name, Vector3(x, 12.5, z + 1.0), Color("#f0d5a1"), 36)

func set_weather(weather_id: String, center: Vector3 = Vector3.ZERO) -> void:
	current_weather = weather_id if weather_id in ["clear", "rain", "fog", "snow"] else "clear"
	if is_instance_valid(world_environment) and is_instance_valid(world_environment.environment):
		var environment := world_environment.environment
		environment.fog_enabled = current_weather in ["rain", "fog", "snow"]
		environment.fog_density = 0.0028 if current_weather == "fog" else (0.0020 if current_weather == "rain" else (0.0018 if current_weather == "snow" else 0.0011))
		environment.fog_light_color = Color("#a5afb1") if current_weather == "fog" else (Color("#697d8d") if current_weather == "rain" else (Color("#c4d6e1") if current_weather == "snow" else Color("#b3a18b")))
		environment.ambient_light_energy = 0.46 if current_weather == "rain" else (0.52 if current_weather == "fog" else (0.66 if current_weather == "snow" else 0.78))
	if is_instance_valid(sun_light):
		sun_light.light_energy = 0.52 if current_weather == "rain" else (0.62 if current_weather == "fog" else (0.68 if current_weather == "snow" else 1.15))
		sun_light.light_color = Color("#8ca3bb") if current_weather == "rain" else (Color("#c6d3d6") if current_weather == "fog" else (Color("#e0ebf2") if current_weather == "snow" else Color("#ffe1b5")))
	if current_weather in ["rain", "snow"]:
		_ensure_weather_particles(current_weather)
		if is_instance_valid(weather_particles):
			weather_particles.emitting = true
			weather_particles.position = center + Vector3(0.0, 10.0, 0.0)
	else:
		if is_instance_valid(weather_particles):
			weather_particles.emitting = false

func update_weather_center(center: Vector3) -> void:
	if is_instance_valid(weather_particles) and weather_particles.emitting:
		weather_particles.position = center + Vector3(0.0, 10.0, 0.0)

func _ensure_weather_particles(weather_id: String) -> void:
	if not is_instance_valid(weather_particles):
		weather_particles = CPUParticles3D.new()
		weather_particles.name = "DynamicWeatherParticles"
		weather_particles.amount = 260
		weather_particles.lifetime = 2.2
		weather_particles.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
		weather_particles.emission_box_extents = Vector3(22.0, 2.0, 22.0)
		weather_particles.direction = Vector3(0.0, -1.0, 0.0)
		weather_particles.spread = 8.0
		weather_particles.draw_order = CPUParticles3D.DRAW_ORDER_VIEW_DEPTH
		var drop := BoxMesh.new()
		weather_particles.draw_pass_1 = drop
		add_child(weather_particles)
	var material := ParticleProcessMaterial.new()
	material.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX
	material.emission_box_extents = Vector3(22.0, 2.0, 22.0)
	material.direction = Vector3(0.0, -1.0, 0.0)
	material.spread = 8.0
	if weather_id == "rain":
		material.initial_velocity_min = 18.0
		material.initial_velocity_max = 25.0
		material.gravity = Vector3(0.0, -12.0, 0.0)
		material.scale_min = 0.025
		material.scale_max = 0.045
		var drop := BoxMesh.new()
		drop.size = Vector3(0.025, 0.72, 0.025)
		weather_particles.draw_pass_1 = drop
		weather_particles.amount = 300 if Engine.max_fps >= 45 else 150
	else:
		material.initial_velocity_min = 1.0
		material.initial_velocity_max = 3.2
		material.gravity = Vector3(0.0, -0.8, 0.0)
		material.scale_min = 0.07
		material.scale_max = 0.16
		var flake := BoxMesh.new()
		flake.size = Vector3(0.09, 0.09, 0.09)
		weather_particles.draw_pass_1 = flake
		weather_particles.amount = 200 if Engine.max_fps >= 45 else 90
	weather_particles.process_material = material

func _make_siege_engine() -> void:
	# A visual-only siege catapult; siege_manager owns firing, cooldown and damage.
	_add_box("CatapultBase", Vector3(5.8, 0.55, 2.6), Vector3(-24.0, 1.05, -18.0), wood_mat, false)
	_add_box("CatapultLeftRail", Vector3(0.5, 1.2, 3.4), Vector3(-26.2, 1.7, -18.0), wood_mat, false)
	_add_box("CatapultRightRail", Vector3(0.5, 1.2, 3.4), Vector3(-21.8, 1.7, -18.0), wood_mat, false)
	_add_cylinder("CatapultWheelLeft", 0.95, 0.95, 0.32, Vector3(-26.4, 0.78, -18.0), dark_stone_mat, false).rotation.x = PI * 0.5
	_add_cylinder("CatapultWheelRight", 0.95, 0.95, 0.32, Vector3(-21.6, 0.78, -18.0), dark_stone_mat, false).rotation.x = PI * 0.5
	_add_box("CatapultThrowArm", Vector3(0.42, 6.3, 0.42), Vector3(-24.0, 3.8, -18.0), wood_mat, false).rotation.x = -0.38
	_add_box("CatapultCounterweight", Vector3(1.4, 1.4, 1.1), Vector3(-24.0, 1.8, -20.0), dark_stone_mat, false)
	_add_sphere("CatapultSlingStone", 0.48, Vector3(-24.0, 7.0, -15.7), rock_mat)
	_add_label("KUŞATMA MANCINIĞI", Vector3(-24.0, 5.4, -21.0), Color("#e6c58c"), 25)

func _make_village() -> void:
	# Village of Yeldeğirmeni: houses, well, market, smithy, fences, signs and lights.
	var homes: Array[Vector3] = [Vector3(70, 0, 18), Vector3(91, 0, 10), Vector3(111, 0, 24), Vector3(79, 0, 45), Vector3(105, 0, 48), Vector3(63, 0, 38)]
	for i in range(homes.size()):
		_make_house(homes[i], i == 2 or i == 4, i)
	# Market awnings and stock tables.
	for stand in [Vector3(93, 0, 32), Vector3(105, 0, 34)]:
		_add_box("MarketTable", Vector3(3.3, 0.18, 1.25), stand + Vector3(0, 0.95, 0), wood_mat, false)
		for sx in [-1.2, 1.2]:
			for sz in [-0.4, 0.4]:
				_add_box("MarketLeg", Vector3(0.16, 0.9, 0.16), stand + Vector3(sx, 0.45, sz), dark_stone_mat, false)
		var canopy := _add_box("MarketAwning", Vector3(3.8, 0.14, 1.9), stand + Vector3(0, 2.15, 0), banner_red if stand.x < 100 else banner_blue, false)
		canopy.rotation.z = -0.035
	# Village well.
	_add_cylinder("VillageWellStone", 2.0, 2.35, 0.9, Vector3(88, 0.45, 30), stone_mat, false)
	_add_cylinder("WellDarkWater", 1.45, 1.45, 0.08, Vector3(88, 0.93, 30), water_mat, false)
	_add_box("WellBeam", Vector3(0.18, 2.2, 0.18), Vector3(88, 2.0, 28.1), wood_mat, false)
	_add_box("WellRoof", Vector3(2.2, 0.16, 1.65), Vector3(88, 3.05, 28.1), roof_mat, false)
	# Village edge fencing, intentionally broken at the road.
	for i in range(21):
		var x := 55.0 + float(i) * 3.4
		if absf(x - 88.0) < 8.0:
			continue
		_add_box("VillageFencePost", Vector3(0.18, 1.25, 0.18), Vector3(x, 0.63, 55), wood_mat, false)
		if i < 20:
			_add_box("VillageFenceRail", Vector3(3.35, 0.11, 0.11), Vector3(x + 1.65, 0.42, 55), wood_mat, false)
			_add_box("VillageFenceRail", Vector3(3.35, 0.11, 0.11), Vector3(x + 1.65, 0.92, 55), wood_mat, false)
	_add_label("YELDEĞİRMENİ KÖYÜ", Vector3(88, 10.5, 25), Color("#f5ddb1"), 48)
	_add_box("VillageNoticeBoard", Vector3(1.4, 1.7, 0.18), Vector3(73, 1.2, 28), wood_mat, false)
	_add_box("NoticePaper", Vector3(0.9, 1.05, 0.04), Vector3(73, 1.35, 27.88), _mat(Color("#d9c69b"), 0.95), false)
	# Extra barrels, sacks and crates bring life to the street.
	for i in range(16):
		var p := homes[i % homes.size()] + Vector3(rng.randf_range(-3.0, 3.0), 0.45, rng.randf_range(-3.0, 3.0))
		if i % 2 == 0:
			_add_cylinder("VillageBarrel", 0.38, 0.42, 0.9, p, wood_mat, false)
		else:
			var crate := _add_box("VillageCrate", Vector3(0.72, 0.72, 0.72), p, wood_mat, false)
			crate.rotation.y = rng.randf_range(0.0, 0.6)

func _make_house(pos: Vector3, is_smithy: bool, index: int) -> void:
	var wall_color := _mat(Color("#a99b7b") if index % 2 == 0 else Color("#847f6d"), 0.95)
	_add_box("CottageStoneBase", Vector3(9.0, 0.6, 7.5), pos + Vector3(0, 0.3, 0), dark_stone_mat, true)
	_add_box("CottageWalls", Vector3(8.4, 3.9, 6.9), pos + Vector3(0, 2.25, 0), wall_color, true)
	# Gabled roof with deep eaves.
	var left_roof := _add_box("CottageRoofLeft", Vector3(5.1, 0.28, 8.0), pos + Vector3(-1.95, 4.55, 0), roof_mat, false)
	left_roof.rotation.z = -0.42
	var right_roof := _add_box("CottageRoofRight", Vector3(5.1, 0.28, 8.0), pos + Vector3(1.95, 4.55, 0), roof_mat, false)
	right_roof.rotation.z = 0.42
	_add_box("CottageDoor", Vector3(1.1, 2.25, 0.13), pos + Vector3(0, 1.25, -3.52), wood_mat, false)
	_add_sphere("DoorKnob", 0.08, pos + Vector3(0.34, 1.32, -3.62), gold_mat)
	for side in [-1.0, 1.0]:
		_add_box("CottageWindowFrame", Vector3(1.18, 1.0, 0.13), pos + Vector3(side * 2.5, 2.65, -3.53), wood_mat, false)
		_add_box("CottageWindowGlow", Vector3(0.82, 0.68, 0.04), pos + Vector3(side * 2.5, 2.65, -3.61), _mat(Color("#efc77e"), 0.35), false)
	if is_smithy:
		_add_box("ForgeStack", Vector3(1.3, 3.8, 1.3), pos + Vector3(2.5, 5.0, 1.0), dark_stone_mat, false)
		_add_box("ForgeGlow", Vector3(0.7, 0.65, 0.12), pos + Vector3(0.9, 1.2, -3.55), _glow_mat(Color("#ff7b39")), false)
		_add_cylinder("SmithyAnvil", 0.45, 0.5, 0.65, pos + Vector3(5.0, 0.35, 1.7), dark_stone_mat, false)

func _make_biome_landmarks() -> void:
	# Ancient ruins in the north-east: cracked arch, columns, rune obelisk and crystals.
	var ruin_center := Vector3(145, 0, -188)
	for i in range(7):
		var x := -15.0 + float(i) * 5.0
		var height := rng.randf_range(4.2, 7.2)
		var column := _add_cylinder("AncientBrokenColumn", 0.68, 0.88, height, ruin_center + Vector3(x, height * 0.5, rng.randf_range(-5.0, 5.0)), stone_mat, false)
		column.rotation.z = rng.randf_range(-0.12, 0.12)
	_add_box("RuinedLintel", Vector3(18.0, 1.0, 1.45), ruin_center + Vector3(0, 7.0, -2.0), dark_stone_mat, false)
	_add_box("RuinedAltar", Vector3(4.2, 1.4, 3.4), ruin_center + Vector3(0, 0.7, 3), stone_mat, false)
	_add_cylinder("RuneObelisk", 0.18, 1.0, 7.5, ruin_center + Vector3(0, 3.75, -9), glow_purple, false)
	_add_label("KAYIP KRALLIĞIN HARABELERİ", ruin_center + Vector3(0, 11.0, -4), Color("#d1b8ff"), 42)
	for i in range(9):
		var angle := float(i) * TAU / 9.0
		var crystal := _add_cylinder("RunestoneCrystal", 0.03, 0.36, rng.randf_range(1.2, 2.8), ruin_center + Vector3(cos(angle) * 12.0, 0.9, sin(angle) * 12.0), glow_purple, false)
		crystal.rotation.z = rng.randf_range(-0.18, 0.18)
	# Frozen north: tall mountain cones and snowy shoulders.
	var peak_points: Array[Vector3] = [Vector3(-70, 0, -252), Vector3(-30, 0, -278), Vector3(18, 0, -254), Vector3(65, 0, -280), Vector3(92, 0, -240), Vector3(-104, 0, -226)]
	for i in range(peak_points.size()):
		var peak: Vector3 = peak_points[i]
		var height := rng.randf_range(28.0, 46.0)
		var base := rng.randf_range(17.0, 26.0)
		_add_cylinder("FrostfangMountain", 0.4, base, height, peak + Vector3(0, height * 0.5 - 1.0, 0), _mat(Color("#536b78"), 0.98), false)
		_add_cylinder("SnowCap", 0.05, base * 0.43, height * 0.38, peak + Vector3(0, height * 0.77, 0), snow_mat, false)
	_add_label("AYAZ DİŞİ ZİNCİRİ", Vector3(0, 39, -264), Color("#e2f2f1"), 48)
	# Desert badlands: weathered pillars and a buried temple entrance.
	for i in range(13):
		var x := -260.0 + float(i) * 7.3
		var z := -162.0 + sin(float(i) * 1.15) * 22.0
		var h := rng.randf_range(5.0, 13.0)
		var pillar := _add_box("SandstoneMonolith", Vector3(rng.randf_range(1.1, 2.8), h, rng.randf_range(1.2, 3.0)), Vector3(x, h * 0.5, z), _mat(Color("#b08c5c"), 0.94), false)
		pillar.rotation.z = rng.randf_range(-0.08, 0.08)
	_add_box("BuriedTempleFacade", Vector3(17, 6, 2), Vector3(-218, 3, -194), _mat(Color("#92744f"), 0.98), false)
	_add_box("TempleDoorDarkness", Vector3(4, 4.7, 0.1), Vector3(-218, 2.35, -192.85), dark_stone_mat, false)
	_add_label("KIZIL KUM HARABELERİ", Vector3(-218, 15, -194), Color("#f1d1a2"), 42)
	# Eastern marsh huts, dead trees, mushrooms and luminous pools.
	for hut in [Vector3(183, 0, 83), Vector3(213, 0, 101), Vector3(171, 0, 116)]:
		_add_cylinder("MarshHutBody", 2.0, 2.5, 3.2, hut + Vector3(0, 1.6, 0), wood_mat, false)
		_add_cylinder("MarshHutThatchedRoof", 0.1, 3.1, 2.5, hut + Vector3(0, 4.1, 0), _mat(Color("#67573a"), 1.0), false)
		_add_box("MarshHutDoor", Vector3(0.9, 1.9, 0.12), hut + Vector3(0, 0.95, -2.4), dark_stone_mat, false)
	for i in range(24):
		var x := rng.randf_range(150, 230)
		var z := rng.randf_range(48, 132)
		var trunk := _add_cylinder("SwampDeadTree", 0.16, 0.38, rng.randf_range(3.5, 6.0), Vector3(x, 2, z), _mat(Color("#3c4037"), 1.0), false)
		trunk.rotation.z = rng.randf_range(-0.12, 0.12)
		for branch in [-1.0, 1.0]:
			var arm := _add_cylinder("SwampTreeBranch", 0.05, 0.12, 1.6, Vector3(x + branch * 0.6, 3.5, z), wood_mat, false)
			arm.rotation.z = branch * 0.55
		if i % 3 == 0:
			_add_sphere("MarshGlowMushroom", 0.28, Vector3(x + 0.8, 0.4, z + 0.7), glow_blue)
	_add_label("SİS BATAKLIĞI", Vector3(190, 12, 74), Color("#a9e8e0"), 44)
	# Southern lakeside fishing pier and small watchtower.
	for i in range(9):
		_add_box("FishingPierPlank", Vector3(2.4, 0.16, 1.2), Vector3(-5.0 + float(i) * 0.0, 0.0, 188.0 + float(i) * 2.0), wood_mat, false)
	for x in [-6.0, -3.0, 0.0]:
		for z in [190.0, 204.0]:
			_add_cylinder("PierPiling", 0.12, 0.16, 1.2, Vector3(x, -0.25, z), wood_mat, false)
	_add_label("AY IŞIĞI GÖLÜ", Vector3(0, 8, 188), Color("#d4edf2"), 45)

func _make_v09_landmarks() -> void:
	# Kara Pençe outlaw camp: tents, palisade, weapon racks and campfire.
	var camp_ground := _mat(Color("#514638"), 0.98)
	var hide_mat := _mat(Color("#554034"), 0.95)
	var banner_mat := _mat(Color("#6e2929"), 0.82)
	for i in range(17):
		var x := -286.0 + float(i) * 3.8
		if absf(x + 256.0) < 10.0:
			continue
		var post := _add_box("BanditPalisadePost", Vector3(0.28, 2.0, 0.32), Vector3(x, 1.0, 103.0), wood_mat, true)
		post.rotation.z = rng.randf_range(-0.04, 0.04)
	for i in range(9):
		var x := -278.0 + float(i) * 5.0
		_add_box("BanditFenceRail", Vector3(4.9, 0.16, 0.16), Vector3(x, 0.95, 103.2), wood_mat, false)
	for tent_pos in [Vector3(-273, 0, 116), Vector3(-248, 0, 117), Vector3(-267, 0, 135)]:
		_add_box("BanditTentCanvas", Vector3(5.3, 2.1, 4.6), tent_pos + Vector3(0, 1.1, 0), hide_mat, false)
		var roof_mesh := PrismMesh.new()
		roof_mesh.size = Vector3(5.8, 2.0, 5.0)
		var roof := MeshInstance3D.new()
		roof.name = "BanditTentRoof"
		roof.mesh = roof_mesh
		roof.position = tent_pos + Vector3(0, 2.25, 0)
		roof.material_override = banner_mat
		add_child(roof)
	_add_cylinder("OutlawCampfirePit", 1.1, 1.35, 0.28, Vector3(-256, 0.18, 122), dark_stone_mat, false)
	_add_sphere("OutlawCampfireGlow", 0.48, Vector3(-256, 0.72, 122), _glow_mat(Color("#ff843f")))
	var fire_light := OmniLight3D.new()
	fire_light.name = "BanditFireLight"
	fire_light.position = Vector3(-256, 1.0, 122)
	fire_light.light_color = Color("#ff9c54")
	fire_light.light_energy = 1.6
	fire_light.omni_range = 13.0
	add_child(fire_light)
	_add_box("BanditWeaponRack", Vector3(2.5, 1.5, 0.24), Vector3(-239, 0.75, 128), wood_mat, false)
	for i in range(4):
		var spear := _add_box("BanditRackSpear", Vector3(0.07, 1.9, 0.07), Vector3(-239.9 + float(i) * 0.6, 1.7, 128), dark_stone_mat, false)
		spear.rotation.z = -0.13
	_add_box("BanditBannerPole", Vector3(0.14, 5.4, 0.14), Vector3(-286, 2.7, 126), wood_mat, false)
	_add_box("BanditBanner", Vector3(1.7, 1.15, 0.08), Vector3(-285.2, 4.4, 126), banner_mat, false)
	_add_label("KARA PENÇE KAMPI", Vector3(-257, 8.2, 100), Color("#f0bd9b"), 38)
	# Broken Spear battlefield: trenches, spent spears, burial markers and torn standards.
	var battlefield_center := Vector3(265, 0, -72)
	for i in range(7):
		var trench := _add_box("BattlefieldTrench", Vector3(8.0, 0.18, 1.2), battlefield_center + Vector3(-18.0 + float(i) * 6.0, 0.08, sin(float(i)) * 9.0), camp_ground, false)
		trench.rotation.y = rng.randf_range(-0.25, 0.25)
	for i in range(18):
		var spear := _add_box("BrokenSpearShaft", Vector3(0.055, 0.055, rng.randf_range(1.0, 2.2)), battlefield_center + Vector3(rng.randf_range(-24, 24), 0.15, rng.randf_range(-20, 20)), wood_mat, false)
		spear.rotation.y = rng.randf_range(0, TAU)
		spear.rotation.x = rng.randf_range(-0.16, 0.16)
	for i in range(8):
		var marker := _add_box("WarGraveMarker", Vector3(0.3, 0.85, 0.15), battlefield_center + Vector3(-13.0 + float(i) * 3.6, 0.42, 16.0), dark_stone_mat, false)
		marker.rotation.z = rng.randf_range(-0.13, 0.13)
	_add_box("BrokenBattleStandardPole", Vector3(0.16, 4.5, 0.16), battlefield_center + Vector3(0, 2.25, -12), wood_mat, false)
	_add_box("BrokenBattleStandard", Vector3(1.5, 0.95, 0.08), battlefield_center + Vector3(0.7, 3.55, -12), banner_blue, false)
	_add_label("KIRIK MIZRAK MEYDANI", battlefield_center + Vector3(0, 8.5, -18), Color("#d7d8d6"), 34)
	# Crystal-marked cave mouth beneath the Frostfang ridge.
	_add_box("FrostCaveLeftPillar", Vector3(2.2, 5.5, 2.4), Vector3(104, 2.75, -226), dark_stone_mat, false)
	_add_box("FrostCaveRightPillar", Vector3(2.2, 5.5, 2.4), Vector3(113, 2.75, -226), dark_stone_mat, false)
	_add_box("FrostCaveLintel", Vector3(10.0, 1.8, 2.8), Vector3(108.5, 5.6, -226), snow_mat, false)
	_add_box("FrostCaveDarkness", Vector3(5.2, 3.8, 0.12), Vector3(108.5, 2.1, -224.55), _mat(Color("#1c2832"), 1.0), false)
	for i in range(5):
		_add_cylinder("FrostCaveCrystal", 0.02, 0.24, 1.5 + float(i % 2) * 0.8, Vector3(103.5 + float(i) * 2.5, 0.7, -223.1), glow_blue, false)
	_add_label("AYAZ MAĞARASI", Vector3(108.5, 9.2, -229), Color("#c8f2fa"), 30)

func _make_v10_landmarks() -> void:
	# A linked ring of new destinations gives the expanded map landmarks beyond the original central valley.
	var weathered_stone := _mat(Color("#646b67"), 0.98)
	var dark_wood := _mat(Color("#362b25"), 0.98)
	var ash_mat := _mat(Color("#514d49"), 1.0)
	var brass_mat := _mat(Color("#b89b63"), 0.7, 0.25)

	# Westwatch: a lookout tower and the remains of an old road bridge.
	var west := Vector3(-345, get_ground_height(-345, 42), 42)
	_add_cylinder("WestwatchTowerBase", 3.2, 4.1, 7.2, west + Vector3(0, 3.6, 0), weathered_stone, false)
	_add_cylinder("WestwatchTowerRim", 4.4, 4.4, 0.8, west + Vector3(0, 7.3, 0), stone_mat, false)
	_add_cylinder("WestwatchRoof", 0.2, 4.0, 4.0, west + Vector3(0, 9.7, 0), banner_blue, false)
	_add_box("WestwatchArrowSlit", Vector3(0.28, 1.25, 0.12), west + Vector3(0, 4.9, 4.02), dark_stone_mat, false)
	_add_box("WestwatchBannerPole", Vector3(0.12, 4.1, 0.12), west + Vector3(0, 10.8, 3.0), wood_mat, false)
	_add_box("WestwatchBanner", Vector3(1.3, 1.8, 0.08), west + Vector3(0.48, 11.6, 3.0), banner_blue, false)
	_add_label("BATI GÖZETLEME KULESİ", west + Vector3(0, 15.0, -2), Color("#d9e3cf"), 30)
	for i in range(8):
		var plank := _add_box("WestwatchBridgePlank", Vector3(2.0, 0.18, 2.5), Vector3(-336.0 - float(i) * 2.6, get_ground_height(-336.0 - float(i) * 2.6, 56.0) + 0.16, 56.0), dark_wood, false)
		plank.rotation.y = -0.1
	for x in [-339.0, -354.0]:
		_add_box("WestwatchBridgePost", Vector3(0.26, 2.6, 0.26), Vector3(x, get_ground_height(x, 56.0) + 1.3, 56.0), wood_mat, false)

	# Frostbound monastery: a collapsed cloister, prayer stones and a quiet blue rune.
	var monastery := Vector3(-292, get_ground_height(-292, -325), -325)
	_add_box("FrostMonasteryFoundation", Vector3(24, 0.5, 19), monastery + Vector3(0, 0.25, 0), dark_stone_mat, false)
	for i in range(6):
		var x := -10.0 + float(i) * 4.0
		var col_h := 3.0 + float((i * 7) % 4) * 0.7
		var column := _add_cylinder("FrostMonasteryPillar", 0.48, 0.68, col_h, monastery + Vector3(x, col_h * 0.5 + 0.25, -4.0), weathered_stone, false)
		if i % 2 == 0:
			column.rotation.z = -0.1
	_add_box("FrostMonasteryBrokenLintel", Vector3(17, 0.8, 1.2), monastery + Vector3(-1.0, 4.7, -4.0), snow_mat, false)
	_add_box("FrostMonasteryAltar", Vector3(4.0, 1.2, 2.8), monastery + Vector3(0, 0.85, 3.2), stone_mat, false)
	_add_cylinder("FrostMonasteryRune", 0.12, 0.62, 3.6, monastery + Vector3(0, 2.5, 5.8), glow_blue, false)
	_add_label("KARAKIŞ MANASTIRI", monastery + Vector3(0, 8.5, -7), Color("#d5ecf2"), 34)

	# Ashen Fields: scorched trees, burnt carts and a ring of blackened standing stones.
	var ashen := Vector3(8, get_ground_height(8, 350), 350)
	_add_box("AshenCampFoundation", Vector3(31, 0.18, 24), ashen + Vector3(0, 0.05, 0), ash_mat, false)
	for i in range(9):
		var angle := float(i) * TAU / 9.0
		var px := cos(angle) * 12.0
		var pz := sin(angle) * 9.0
		var monolith_h := rng.randf_range(2.0, 5.0)
		var monolith := _add_box("AshenStandingStone", Vector3(0.8, monolith_h, 1.0), ashen + Vector3(px, monolith_h * 0.5 + 0.1, pz), dark_stone_mat, false)
		monolith.rotation.z = rng.randf_range(-0.13, 0.13)
	for tree_spec in [Vector2(-15, -7), Vector2(17, -5), Vector2(-19, 11), Vector2(18, 13), Vector2(-5, 17)]:
		var trunk := _add_cylinder("AshenBurntTree", 0.13, 0.38, 4.8, ashen + Vector3(tree_spec.x, 2.4, tree_spec.y), dark_wood, false)
		trunk.rotation.z = rng.randf_range(-0.18, 0.18)
		_add_cylinder("AshenTreeBranch", 0.04, 0.13, 2.0, ashen + Vector3(tree_spec.x + 0.8, 3.2, tree_spec.y), dark_wood, false).rotation.z = 0.7
	_add_box("AshenBrokenCartBed", Vector3(3.3, 0.2, 1.8), ashen + Vector3(22, 0.65, 0), wood_mat, false)
	for x in [-1.2, 1.2]:
		_add_cylinder("AshenCartWheel", 0.85, 0.85, 0.18, ashen + Vector3(22 + x, 0.7, 1.05), dark_wood, false).rotation.x = PI * 0.5
	_add_label("KÜL OVASI", ashen + Vector3(0, 9.0, -13), Color("#e0c7aa"), 42)

	# Eastern watchpost: stone customs tower beside the eastern watercourse.
	var east := Vector3(362, get_ground_height(362, -20), -20)
	_add_cylinder("EasternWatchBase", 3.6, 4.4, 6.0, east + Vector3(0, 3.0, 0), weathered_stone, false)
	_add_cylinder("EasternWatchCrown", 4.1, 4.1, 0.75, east + Vector3(0, 6.2, 0), stone_mat, false)
	_add_cylinder("EasternWatchRoof", 0.18, 3.5, 3.2, east + Vector3(0, 8.0, 0), banner_red, false)
	_add_box("EasternWatchDoor", Vector3(1.35, 2.4, 0.18), east + Vector3(0, 1.25, 4.1), dark_wood, false)
	_add_box("EasternWatchSignpost", Vector3(0.22, 2.8, 0.22), east + Vector3(5.0, 1.4, 3.0), wood_mat, false)
	_add_box("EasternWatchSign", Vector3(3.0, 0.85, 0.18), east + Vector3(5.0, 2.4, 3.0), brass_mat, false)
	_add_label("DOĞU SINIR GÖZETİMİ", east + Vector3(0, 12.0, -5), Color("#d8e7ea"), 32)
	for i in range(7):
		var z := -1.0 + float(i) * 1.35
		_add_box("EasternDockPlank", Vector3(2.2, 0.15, 1.25), east + Vector3(14.0, 0.12, z), dark_wood, false)

	# Sunken Caravan Stop: broken wagons and weather-beaten shade cloth along the southern trade road.
	var caravan := Vector3(295, get_ground_height(295, 298), 298)
	_add_box("CaravanStopGround", Vector3(27, 0.12, 22), caravan + Vector3(0, 0.06, 0), path_mat, false)
	for cart_x in [-8.0, 7.0]:
		_add_box("CaravanWagonBed", Vector3(4.8, 0.24, 2.4), caravan + Vector3(cart_x, 1.0, -1.0), dark_wood, false)
		_add_box("CaravanWagonAxle", Vector3(5.6, 0.16, 0.18), caravan + Vector3(cart_x, 0.9, -1.0), wood_mat, false)
		for wheel_x in [-1.65, 1.65]:
			_add_cylinder("CaravanWagonWheel", 0.9, 0.9, 0.2, caravan + Vector3(cart_x + wheel_x, 0.8, -2.0), dark_wood, false).rotation.x = PI * 0.5
	for post_pos in [Vector3(-8, 0, 7), Vector3(8, 0, 7)]:
		_add_box("CaravanShadePost", Vector3(0.18, 3.6, 0.18), caravan + post_pos + Vector3(0, 1.8, 0), wood_mat, false)
	_add_box("CaravanShadeCloth", Vector3(18, 0.18, 6.4), caravan + Vector3(0, 3.6, 7), banner_red, false)
	_add_cylinder("CaravanWaystone", 0.25, 0.8, 2.1, caravan + Vector3(0, 1.05, -8.0), brass_mat, false)
	_add_label("BATIK KERVAN DURAĞI", caravan + Vector3(0, 8.0, -10.0), Color("#f1d7a7"), 34)

func _make_forests_and_rocks() -> void:
	# Deliberately keep the town, main roads and fortress approaches readable.
	for i in range(285):
		var x := rng.randf_range(-412.0, 412.0)
		var z := rng.randf_range(-412.0, 412.0)
		var point := Vector2(x, z)
		var in_forest := point.distance_to(Vector2(-160, 70)) < 165.0 or point.distance_to(Vector2(-60, 170)) < 118.0 or point.distance_to(Vector2(-330, 42)) < 132.0
		var in_snow := point.distance_to(Vector2(10, -245)) < 130.0 or point.distance_to(Vector2(-292, -325)) < 82.0
		var in_village := point.distance_to(Vector2(88, 30)) < 31.0
		var near_keep_road := absf(x) < 11.0 and z > -66.0 and z < 40.0
		var near_landmark := point.distance_to(Vector2(-345, 42)) < 28.0 or point.distance_to(Vector2(-292, -325)) < 37.0 or point.distance_to(Vector2(8, 350)) < 40.0 or point.distance_to(Vector2(362, -20)) < 34.0 or point.distance_to(Vector2(295, 298)) < 38.0
		if in_village or near_keep_road or near_landmark:
			continue
		if not in_forest and rng.randf() > 0.28:
			continue
		var scale := rng.randf_range(0.72, 1.42)
		if in_snow:
			_add_tree(x, z, scale, true)
		else:
			_add_tree(x, z, scale, in_forest)
	for i in range(190):
		var x := rng.randf_range(-418.0, 418.0)
		var z := rng.randf_range(-418.0, 418.0)
		var point := Vector2(x, z)
		if point.length() < 16.0 or point.distance_to(Vector2(88.0, 30.0)) < 23.0:
			continue
		if point.distance_to(Vector2(-345, 42)) < 22.0 or point.distance_to(Vector2(-292, -325)) < 28.0 or point.distance_to(Vector2(8, 350)) < 31.0 or point.distance_to(Vector2(362, -20)) < 28.0 or point.distance_to(Vector2(295, 298)) < 29.0:
			continue
		var rock := MeshInstance3D.new()
		rock.name = "WeatheredBoulder"
		rock.add_to_group("quality_rocks")
		rock.mesh = rock_mesh
		rock.material_override = snow_mat if Vector2(x - 10.0, z + 245.0).length() < 130.0 else rock_mat
		rock.position = Vector3(x, get_ground_height(x, z) + 0.25, z)
		rock.scale = Vector3(rng.randf_range(0.4, 2.8), rng.randf_range(0.25, 1.7), rng.randf_range(0.4, 2.5))
		rock.rotation.y = rng.randf_range(0.0, TAU)
		add_child(rock)
	# Ancient forest stumps and fallen logs.
	for i in range(38):
		var x := rng.randf_range(-235.0, -80.0)
		var z := rng.randf_range(15.0, 145.0)
		_add_cylinder("MossyTreeStump", 0.35, 0.52, rng.randf_range(0.35, 0.9), Vector3(x, 0.3, z), wood_mat, false)
		if i % 3 == 0:
			var log := _add_cylinder("FallenForestLog", 0.22, 0.25, rng.randf_range(2.0, 4.2), Vector3(x + 1.4, 0.28, z + 0.8), wood_mat, false)
			log.rotation.z = PI * 0.5

func _add_tree(x: float, z: float, scale: float, snowy: bool = false) -> void:
	# A parent cluster lets the low profile hide complete trees rather than isolated canopy parts.
	var tree_cluster := Node3D.new()
	tree_cluster.name = "QualityTreeCluster"
	tree_cluster.add_to_group("quality_foliage_cluster")
	add_child(tree_cluster)
	var trunk := MeshInstance3D.new()
	trunk.name = "ProceduralTreeTrunk"
	trunk.mesh = trunk_mesh
	trunk.material_override = wood_mat
	trunk.add_to_group("quality_foliage")
	trunk.position = Vector3(x, get_ground_height(x, z) + 1.2 * scale, z)
	trunk.scale = Vector3(scale, scale, scale)
	tree_cluster.add_child(trunk)
	var leaf_material := snow_mat if snowy else (leaf_mat if scale < 1.0 else pine_mat)
	var lower := MeshInstance3D.new()
	lower.name = "PineCanopyLower"
	lower.mesh = pine_lower_mesh
	lower.material_override = leaf_material
	lower.add_to_group("quality_foliage")
	lower.position = Vector3(x, get_ground_height(x, z) + 2.7 * scale, z)
	lower.scale = Vector3(scale, scale, scale)
	tree_cluster.add_child(lower)
	var upper := MeshInstance3D.new()
	upper.name = "PineCanopyUpper"
	upper.mesh = pine_upper_mesh
	upper.material_override = leaf_material
	upper.add_to_group("quality_foliage")
	upper.position = Vector3(x, get_ground_height(x, z) + 3.75 * scale, z)
	upper.scale = Vector3(scale, scale, scale)
	tree_cluster.add_child(upper)

func _make_boundary_ridges() -> void:
	# Layered hills fade into the atmospheric fog instead of ending abruptly at the terrain edge.
	for i in range(54):
		var angle := float(i) * TAU / 54.0
		var radius := 414.0 + rng.randf_range(-12.0, 14.0)
		var x := cos(angle) * radius
		var z := sin(angle) * radius
		var hill := MeshInstance3D.new()
		hill.name = "FarHorizonRidge"
		hill.add_to_group("quality_horizon")
		hill.mesh = rock_mesh
		hill.material_override = _mat(Color("#435650"), 1.0)
		hill.position = Vector3(x, get_ground_height(x, z) + rng.randf_range(3.0, 8.0), z)
		hill.scale = Vector3(rng.randf_range(10.0, 24.0), rng.randf_range(8.0, 20.0), rng.randf_range(8.0, 20.0))
		add_child(hill)

func _make_world_boundaries() -> void:
	# Invisible collision barriers sit behind the distant ridge line to keep the party in the playable region.
	var half := WORLD_SIZE * 0.5 - 4.0
	var wall_specs: Array[Dictionary] = [
		{"p": Vector3(-half, 30.0, 0.0), "s": Vector3(8.0, 60.0, WORLD_SIZE)},
		{"p": Vector3(half, 30.0, 0.0), "s": Vector3(8.0, 60.0, WORLD_SIZE)},
		{"p": Vector3(0.0, 30.0, -half), "s": Vector3(WORLD_SIZE, 60.0, 8.0)},
		{"p": Vector3(0.0, 30.0, half), "s": Vector3(WORLD_SIZE, 60.0, 8.0)}
	]
	for spec in wall_specs:
		var wall := StaticBody3D.new()
		wall.name = "InvisibleWorldBoundary"
		wall.position = spec["p"]
		var collision := CollisionShape3D.new()
		var shape := BoxShape3D.new()
		shape.size = spec["s"]
		collision.shape = shape
		wall.add_child(collision)
		add_child(wall)

func _make_torches_and_runes() -> void:
	for position in [Vector3(-5, 1.6, -26), Vector3(5, 1.6, -26), Vector3(85, 2.0, 20), Vector3(107, 2.0, 29), Vector3(142, 1.0, -178)]:
		_add_cylinder("TorchPole", 0.075, 0.1, 2.5, position + Vector3(0, -0.35, 0), dark_stone_mat, false)
		_add_sphere("TorchFlame", 0.19, position + Vector3(0, 1.0, 0), _glow_mat(Color("#ff963e")))
		var light := OmniLight3D.new()
		light.name = "WarmTorchLight"
		light.position = position + Vector3(0, 1.1, 0)
		light.light_color = Color("#ffac5a")
		light.light_energy = 1.15
		light.omni_range = 8.0
		add_child(light)
	for i in range(7):
		var angle := float(i) * TAU / 7.0
		var crystal := _add_cylinder("MeadowRune", 0.05, 0.24, 0.8, Vector3(cos(angle) * 24.0, 0.42, 18.0 + sin(angle) * 24.0), glow_blue, false)
		crystal.rotation.z = 0.1 * sin(angle)


func apply_settlement_visual_state(summary: Dictionary) -> void:
	var previous := get_node_or_null("SettlementUpgradeVisuals")
	if is_instance_valid(previous):
		previous.free()
	if not bool(summary.get("castle_owned", false)):
		return
	var visuals := Node3D.new()
	visuals.name = "SettlementUpgradeVisuals"
	add_child(visuals)
	var levels: Variant = summary.get("building_levels", {})
	if not levels is Dictionary:
		levels = {}
	var barracks_level := clampi(int(levels.get("barracks", 0)), 0, 3)
	var wall_level := clampi(int(levels.get("walls", 0)), 0, 3)
	var market_level := clampi(int(levels.get("market", 0)), 0, 3)
	var wood := _mat(Color("#4b3929"), 0.96)
	var pale_wood := _mat(Color("#8a6d42"), 0.9)
	var roof_mat := _mat(Color("#6c3830"), 0.9)
	var stone := _mat(Color("#858680"), 0.98)
	var cloth := _mat(Color("#c5a154"), 0.85)
	if barracks_level > 0:
		_settlement_box(visuals, "BarracksFoundation", Vector3(5.2, 0.35, 4.5), Vector3(-6.7, 0.2, -46.5), stone)
		_settlement_box(visuals, "BarracksBody", Vector3(4.5, 2.3 + float(barracks_level) * 0.22, 3.8), Vector3(-6.7, 1.45, -46.5), wood)
		_settlement_box(visuals, "BarracksRoof", Vector3(5.1, 0.38, 4.25), Vector3(-6.7, 2.85 + float(barracks_level) * 0.22, -46.5), roof_mat)
		for x_offset in [-1.5, 1.5]:
			_settlement_box(visuals, "BarracksDoorFrame", Vector3(0.22, 1.65, 0.18), Vector3(-6.7 + x_offset, 1.0, -44.55), pale_wood)
		if barracks_level >= 2:
			_settlement_box(visuals, "BarracksWatchDeck", Vector3(1.0, 0.8, 0.95), Vector3(-6.7, 3.35, -46.5), stone)
		if barracks_level >= 3:
			_settlement_box(visuals, "BarracksBannerPole", Vector3(0.13, 2.2, 0.13), Vector3(-6.7, 4.2, -46.5), pale_wood)
			_settlement_box(visuals, "BarracksBanner", Vector3(1.15, 0.75, 0.08), Vector3(-6.7, 4.75, -46.5), cloth)
	if market_level > 0:
		for x_offset in [-1.35, 1.35]:
			_settlement_box(visuals, "MarketPost", Vector3(0.16, 2.0, 0.16), Vector3(6.8 + x_offset, 1.0, -46.5), pale_wood)
		_settlement_box(visuals, "MarketCounter", Vector3(3.5, 0.8, 1.0), Vector3(6.8, 0.55, -46.5), wood)
		_settlement_box(visuals, "MarketAwning", Vector3(4.0, 0.18, 3.0), Vector3(6.8, 2.0, -46.5), cloth)
		if market_level >= 2:
			_settlement_box(visuals, "MarketBackWall", Vector3(3.6, 1.8, 0.18), Vector3(6.8, 1.0, -48.0), pale_wood)
		if market_level >= 3:
			_settlement_box(visuals, "MarketStorage", Vector3(1.4, 1.1, 1.1), Vector3(8.1, 0.55, -45.2), wood)
	if wall_level > 0:
		var merlons := 2 + wall_level * 2
		for side in [-1.0, 1.0]:
			for index in range(merlons):
				var z := -51.5 + float(index) * (17.0 / float(maxi(1, merlons - 1)))
				_settlement_box(visuals, "WallMerlon", Vector3(0.9, 0.75 + float(wall_level) * 0.12, 0.72), Vector3(side * 12.6, 6.25 + float(wall_level) * 0.12, z), stone)
		if wall_level >= 2:
			_settlement_box(visuals, "WallWalkLeft", Vector3(1.35, 0.22, 19.0), Vector3(-12.6, 6.15, -44.0), stone)
			_settlement_box(visuals, "WallWalkRight", Vector3(1.35, 0.22, 19.0), Vector3(12.6, 6.15, -44.0), stone)
		if wall_level >= 3:
			for x in [-8.0, -4.0, 4.0, 8.0]:
				_settlement_box(visuals, "GatehouseReinforcement", Vector3(0.7, 0.9, 2.7), Vector3(x, 6.6, -33.5), stone)
	var management_label := Label3D.new()
	management_label.name = "SettlementManagementLabel"
	management_label.text = "KALE YÖNETİMİ AKTİF"
	management_label.position = Vector3(0, 15.8, -51)
	management_label.font_size = 26
	management_label.outline_size = 8
	management_label.outline_modulate = Color(0.02, 0.035, 0.045, 0.94)
	management_label.modulate = Color("#f4d595")
	management_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	visuals.add_child(management_label)

func _settlement_box(parent: Node3D, node_name: String, dimensions: Vector3, at: Vector3, material: Material) -> void:
	var mesh := BoxMesh.new()
	mesh.size = dimensions
	var instance := MeshInstance3D.new()
	instance.name = node_name
	instance.mesh = mesh
	instance.material_override = material
	instance.position = at
	parent.add_child(instance)

func _add_label(text_value: String, at: Vector3, color: Color, font_size: int) -> void:
	var label := Label3D.new()
	label.text = text_value
	label.position = at
	label.font_size = font_size
	label.outline_size = 10
	label.outline_modulate = Color(0.02, 0.035, 0.045, 0.94)
	label.modulate = color
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	label.no_depth_test = false
	add_child(label)

func _mat(color: Color, roughness: float = 0.9, metallic: float = 0.0) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.roughness = roughness
	material.metallic = metallic
	return material

func _glow_mat(color: Color) -> StandardMaterial3D:
	var material := _mat(color, 0.28, 0.08)
	material.emission_enabled = true
	material.emission = color
	material.emission_energy_multiplier = 1.45
	return material

func _add_box(node_name: String, dimensions: Vector3, at: Vector3, material: Material, collision: bool = false) -> MeshInstance3D:
	var holder := Node3D.new()
	holder.name = node_name + "Root"
	holder.position = at
	add_child(holder)
	var mesh := BoxMesh.new()
	mesh.size = dimensions
	var instance := MeshInstance3D.new()
	instance.name = node_name
	instance.mesh = mesh
	instance.material_override = material
	holder.add_child(instance)
	if collision:
		var body := StaticBody3D.new()
		body.name = "WorldSolidBody"
		holder.add_child(body)
		var shape := CollisionShape3D.new()
		var box := BoxShape3D.new()
		box.size = dimensions
		shape.shape = box
		body.add_child(shape)
		_register_navigation_obstacle(at, dimensions)
	return instance

func _add_sphere(node_name: String, radius: float, at: Vector3, material: Material) -> MeshInstance3D:
	var mesh := SphereMesh.new()
	mesh.radius = radius
	mesh.height = radius * 2.0
	var instance := MeshInstance3D.new()
	instance.name = node_name
	instance.mesh = mesh
	instance.material_override = material
	instance.position = at
	add_child(instance)
	return instance

func _add_cylinder(node_name: String, top_radius: float, bottom_radius: float, height: float, at: Vector3, material: Material, collision: bool = false) -> MeshInstance3D:
	var mesh := CylinderMesh.new()
	mesh.top_radius = top_radius
	mesh.bottom_radius = bottom_radius
	mesh.height = height
	var holder := Node3D.new()
	holder.name = node_name + "Root"
	holder.position = at
	add_child(holder)
	var instance := MeshInstance3D.new()
	instance.name = node_name
	instance.mesh = mesh
	instance.material_override = material
	holder.add_child(instance)
	if collision:
		var body := StaticBody3D.new()
		holder.add_child(body)
		var shape := CollisionShape3D.new()
		var cylinder_shape := CylinderShape3D.new()
		cylinder_shape.radius = maxf(top_radius, bottom_radius)
		cylinder_shape.height = height
		shape.shape = cylinder_shape
		body.add_child(shape)
		var diameter := maxf(top_radius, bottom_radius) * 2.0
		_register_navigation_obstacle(at, Vector3(diameter, height, diameter))
	return instance
