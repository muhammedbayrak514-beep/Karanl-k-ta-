extends Control

var world_position := Vector2.ZERO
var map_scale: float = 0.14

func _ready() -> void:
	custom_minimum_size = Vector2(164, 125)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	queue_redraw()

func set_world_position(position_3d: Vector3) -> void:
	world_position = Vector2(position_3d.x, position_3d.z)
	queue_redraw()

func _draw() -> void:
	var bounds := Rect2(Vector2.ZERO, size)
	draw_rect(bounds, Color(0.025, 0.045, 0.055, 0.86), true)
	draw_rect(bounds, Color("#c4a96c"), false, 2.0)
	var center := size * 0.5
	# Miniature region silhouettes, trade routes and newly reachable outer landmarks.
	_draw_world_point(center, Vector2(-160, 70), 19, Color("#31563d"))
	_draw_world_point(center, Vector2(0, -245), 17, Color("#9baeb2"))
	_draw_world_point(center, Vector2(188, 88), 16, Color("#385f5b"))
	_draw_world_point(center, Vector2(-218, -160), 16, Color("#90704e"))
	_draw_world_point(center, Vector2(145, -188), 14, Color("#777670"))
	_draw_world_point(center, Vector2(0, 220), 10, Color("#25677b"))
	_draw_world_point(center, Vector2(-330, 42), 17, Color("#294337"))
	_draw_world_point(center, Vector2(-292, -325), 13, Color("#a8b8bc"))
	_draw_world_point(center, Vector2(8, 350), 16, Color("#625b50"))
	_draw_world_point(center, Vector2(362, -20), 13, Color("#526b73"))
	_draw_world_point(center, Vector2(295, 298), 14, Color("#9b825c"))
	var castle := _map_point(center, Vector2(0, -33))
	var village := _map_point(center, Vector2(88, 30))
	var ruins := _map_point(center, Vector2(145, -188))
	var forest := _map_point(center, Vector2(-160, 70))
	var snow := _map_point(center, Vector2(10, -245))
	var marsh := _map_point(center, Vector2(188, 88))
	var westwatch := _map_point(center, Vector2(-345, 42))
	var monastery := _map_point(center, Vector2(-292, -325))
	var ashen := _map_point(center, Vector2(8, 350))
	var eastwatch := _map_point(center, Vector2(362, -20))
	var caravan := _map_point(center, Vector2(295, 298))
	draw_line(castle, village, Color("#c8b18a"), 1.4)
	draw_line(village, ruins, Color("#b7a37d"), 1.0)
	draw_line(castle, westwatch, Color("#c8b18a"), 1.0)
	draw_line(westwatch, monastery, Color("#c8b18a"), 1.0)
	draw_line(castle, ashen, Color("#c8b18a"), 1.0)
	draw_line(ashen, caravan, Color("#c8b18a"), 1.0)
	draw_line(village, eastwatch, Color("#c8b18a"), 1.0)
	draw_line(eastwatch, caravan, Color("#c8b18a"), 1.0)
	for marker in [castle, village, ruins, westwatch, monastery, ashen, eastwatch, caravan]:
		draw_circle(marker, 2.6, Color("#e6c374"))
	draw_circle(forest, 2.1, Color("#5d945f"))
	draw_circle(snow, 2.2, Color("#e5eeee"))
	draw_circle(marsh, 2.1, Color("#65b9b0"))
	var player_point := _map_point(center, world_position)
	draw_circle(player_point, 5.0, Color(0.0, 0.0, 0.0, 0.9))
	draw_circle(player_point, 3.2, Color("#ff6c4e"))
	draw_line(player_point + Vector2(-6, 0), player_point + Vector2(6, 0), Color("#fff0d5"), 1.0)
	draw_line(player_point + Vector2(0, -6), player_point + Vector2(0, 6), Color("#fff0d5"), 1.0)
	draw_string(ThemeDB.fallback_font, Vector2(7, 14), "KUZEY ↑", HORIZONTAL_ALIGNMENT_LEFT, -1, 10, Color("#e0e6db"))
	draw_string(ThemeDB.fallback_font, Vector2(7, size.y - 7), "AÇIK DÜNYA • 900 m", HORIZONTAL_ALIGNMENT_LEFT, -1, 9, Color("#c7d0c9"))

func _map_point(center: Vector2, world: Vector2) -> Vector2:
	return center + Vector2(world.x, world.y) * map_scale

func _draw_world_point(center: Vector2, world: Vector2, radius: float, color: Color) -> void:
	var p := _map_point(center, world)
	draw_circle(p, radius, Color(color.r, color.g, color.b, 0.55))
