extends Node3D

# Lightweight moving caravan used by the living-world simulation.
var game_ref: Variant = null
var caravan_id: String = "west_route"
var caravan_name: String = "Tüccar Kervanı"
var route: Array[Vector3] = []
var route_index: int = 0
var move_speed: float = 3.1
var trade_modifier: float = 1.0
var elapsed: float = 0.0
var cart_root: Node3D = null
var nameplate: Label3D = null

func configure(game: Variant, id_value: String, name_value: String, route_points: Array[Vector3], saved: Dictionary = {}) -> void:
	game_ref = game
	caravan_id = id_value
	caravan_name = name_value
	route = route_points.duplicate()
	if route.is_empty():
		route = [Vector3.ZERO, Vector3(20.0, 0.0, 20.0)]
	route_index = clampi(int(saved.get("route_index", 0)), 0, route.size() - 1)
	move_speed = clampf(float(saved.get("move_speed", 3.1)), 1.0, 6.0)
	var saved_position: Variant = saved.get("position", {})
	if saved_position is Dictionary and not saved_position.is_empty():
		position = Vector3(float(saved_position.get("x", route[route_index].x)), float(saved_position.get("y", route[route_index].y)), float(saved_position.get("z", route[route_index].z)))
	else:
		position = route[route_index]

func _ready() -> void:
	add_to_group("interactables")
	add_to_group("traveling_caravans")
	_build_cart()
	if is_instance_valid(game_ref) and is_instance_valid(game_ref.world_ref):
		position.y = game_ref.world_ref.get_ground_height(position.x, position.z)

func _process(delta: float) -> void:
	if route.size() < 2 or not is_instance_valid(game_ref):
		return
	elapsed += delta
	var target: Vector3 = route[route_index]
	var horizontal := Vector3(target.x - global_position.x, 0.0, target.z - global_position.z)
	if horizontal.length() <= 1.8:
		route_index = (route_index + 1) % route.size()
		target = route[route_index]
		horizontal = Vector3(target.x - global_position.x, 0.0, target.z - global_position.z)
	if horizontal.length() > 0.01:
		var step := minf(horizontal.length(), move_speed * delta)
		global_position.x += horizontal.normalized().x * step
		global_position.z += horizontal.normalized().z * step
		if is_instance_valid(game_ref.world_ref) and game_ref.world_ref.has_method("get_ground_height"):
			global_position.y = game_ref.world_ref.get_ground_height(global_position.x, global_position.z)
		if is_instance_valid(cart_root):
			cart_root.rotation.y = atan2(-horizontal.x, -horizontal.z)
	if is_instance_valid(nameplate):
		nameplate.position.y = 4.0 + sin(elapsed * 2.0) * 0.12

func interact(game: Variant) -> void:
	if is_instance_valid(game) and game.has_method("interact_with_caravan"):
		game.interact_with_caravan(self)

func get_save_state() -> Dictionary:
	return {"route_index": route_index, "move_speed": move_speed, "position": {"x": global_position.x, "y": global_position.y, "z": global_position.z}}

func _build_cart() -> void:
	cart_root = Node3D.new()
	cart_root.name = "CaravanCart"
	add_child(cart_root)
	var wood := _material(Color("#68462e"))
	var iron := _material(Color("#657078"), 0.4, 0.45)
	var cloth := _material(Color("#b28b4c"))
	_add_box(cart_root, "CartBed", Vector3(2.2, 0.22, 1.55), Vector3(0, 1.0, 0), wood)
	_add_box(cart_root, "CartFrontRail", Vector3(2.15, 0.75, 0.12), Vector3(0, 1.35, -0.72), wood)
	_add_box(cart_root, "CartBackRail", Vector3(2.15, 0.75, 0.12), Vector3(0, 1.35, 0.72), wood)
	_add_box(cart_root, "CartLeftRail", Vector3(0.12, 0.75, 1.35), Vector3(-1.03, 1.35, 0), wood)
	_add_box(cart_root, "CartRightRail", Vector3(0.12, 0.75, 1.35), Vector3(1.03, 1.35, 0), wood)
	for pack_index in range(3):
		var pack := _add_box(cart_root, "GoodsCrate_%d" % pack_index, Vector3(0.6, 0.6, 0.58), Vector3(float(pack_index - 1) * 0.65, 1.55, 0.0), cloth if pack_index == 1 else wood)
		pack.rotation.y = float(pack_index) * 0.18
	for side in [-1.0, 1.0]:
		var axle := MeshInstance3D.new()
		var axle_mesh := CylinderMesh.new()
		axle_mesh.top_radius = 0.09
		axle_mesh.bottom_radius = 0.09
		axle_mesh.height = 2.8
		axle.mesh = axle_mesh
		axle.material_override = iron
		axle.position = Vector3(0, 0.68, side * 0.8)
		axle.rotation.z = PI * 0.5
		cart_root.add_child(axle)
		for wheel_side in [-1.0, 1.0]:
			var wheel := MeshInstance3D.new()
			var wheel_mesh := CylinderMesh.new()
			wheel_mesh.top_radius = 0.47
			wheel_mesh.bottom_radius = 0.47
			wheel_mesh.height = 0.2
			wheel.mesh = wheel_mesh
			wheel.material_override = iron
			wheel.position = Vector3(wheel_side * 1.15, 0.66, side * 0.8)
			wheel.rotation.x = PI * 0.5
			cart_root.add_child(wheel)
	nameplate = Label3D.new()
	nameplate.text = caravan_name + "  •  ETKİLEŞ"
	nameplate.font_size = 24
	nameplate.outline_size = 7
	nameplate.modulate = Color("#f5d8a4")
	nameplate.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	nameplate.position = Vector3(0, 4.0, 0)
	add_child(nameplate)

func _add_box(parent: Node3D, node_name: String, dimensions: Vector3, at: Vector3, material: Material) -> MeshInstance3D:
	var item := MeshInstance3D.new()
	item.name = node_name
	var mesh := BoxMesh.new()
	mesh.size = dimensions
	item.mesh = mesh
	item.material_override = material
	item.position = at
	parent.add_child(item)
	return item

func _material(color_value: Color, roughness_value: float = 0.86, metallic_value: float = 0.0) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = color_value
	material.roughness = roughness_value
	material.metallic = metallic_value
	return material
