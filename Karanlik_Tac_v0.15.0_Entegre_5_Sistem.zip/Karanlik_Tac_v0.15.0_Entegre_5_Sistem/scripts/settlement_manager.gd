extends Node

# Lightweight settlement layer for the player-owned frontier castle.
# All values are plain data and are serialized into the existing save slots.
const BUILDING_IDS: Array[String] = ["barracks", "walls", "market"]
const BUILDING_NAMES: Dictionary = {
	"barracks": "Kışla",
	"walls": "Taş Surlar",
	"market": "Pazar"
}
const UPGRADE_COSTS: Dictionary = {
	"barracks": [220, 380, 600],
	"walls": [200, 360, 580],
	"market": [180, 320, 500]
}
const GARRISON_RECRUIT_COST: int = 40
const TAX_INTERVAL_SECONDS: float = 180.0
const MAX_BUILDING_LEVEL: int = 3

var game_ref: Variant = null
var arena_ref: Variant = null
var castle_owned: bool = false
var building_levels: Dictionary = {"barracks": 0, "walls": 0, "market": 0}
var garrison_units: int = 0
var tax_cooldown: float = 0.0
var taxes_collected: int = 0

func initialize(game: Variant, arena: Variant, saved_state: Dictionary = {}, owns_castle: bool = false) -> void:
	game_ref = game
	arena_ref = arena
	castle_owned = owns_castle
	building_levels = {"barracks": 0, "walls": 0, "market": 0}
	var saved_levels: Variant = saved_state.get("building_levels", {})
	if saved_levels is Dictionary:
		for building_id in BUILDING_IDS:
			building_levels[building_id] = clampi(int(saved_levels.get(building_id, 0)), 0, MAX_BUILDING_LEVEL)
	garrison_units = clampi(int(saved_state.get("garrison_units", 0)), 0, get_garrison_capacity())
	tax_cooldown = clampf(float(saved_state.get("tax_cooldown", 0.0)), 0.0, TAX_INTERVAL_SECONDS)
	taxes_collected = maxi(0, int(saved_state.get("taxes_collected", 0)))
	_apply_visuals()

func _process(delta: float) -> void:
	if not castle_owned or tax_cooldown <= 0.0:
		return
	var was_cooling := tax_cooldown > 0.0
	tax_cooldown = maxf(0.0, tax_cooldown - delta)
	if was_cooling and tax_cooldown <= 0.0:
		_mark_dirty()
		_refresh_panel_if_open()

func set_castle_owned(value: bool) -> void:
	if castle_owned == value:
		return
	castle_owned = value
	_apply_visuals()
	_mark_dirty()
	_refresh_panel_if_open()

func get_building_level(building_id: String) -> int:
	return clampi(int(building_levels.get(building_id, 0)), 0, MAX_BUILDING_LEVEL)

func get_upgrade_cost(building_id: String) -> int:
	if not UPGRADE_COSTS.has(building_id):
		return -1
	var level := get_building_level(building_id)
	if level >= MAX_BUILDING_LEVEL:
		return -1
	var costs: Array = UPGRADE_COSTS[building_id]
	return int(costs[level])

func get_garrison_capacity() -> int:
	return 8 + get_building_level("barracks") * 4

func get_tax_income() -> int:
	return 20 + get_building_level("market") * 18

func get_defense_rating() -> int:
	if not castle_owned:
		return 0
	return 20 + get_building_level("walls") * 20 + get_building_level("barracks") * 5 + garrison_units * 2

func upgrade_building(building_id: String, current_gold: int) -> Dictionary:
	if not castle_owned:
		return _failure("Önce Karanlık Taç Kalesi'ni ele geçirmelisin.")
	if not BUILDING_IDS.has(building_id):
		return _failure("Bilinmeyen yapı.")
	var level := get_building_level(building_id)
	if level >= MAX_BUILDING_LEVEL:
		return _failure("%s zaten en yüksek seviyede." % str(BUILDING_NAMES[building_id]))
	var cost := get_upgrade_cost(building_id)
	if current_gold < cost:
		return _failure("%s için %d altın gerekiyor." % [str(BUILDING_NAMES[building_id]), cost])
	building_levels[building_id] = level + 1
	_apply_visuals()
	_mark_dirty()
	_refresh_panel_if_open()
	return {"ok": true, "gold": current_gold - cost, "message": "%s %d. seviyeye yükseltildi. (-%d altın)" % [str(BUILDING_NAMES[building_id]), level + 1, cost], "building_id": building_id, "level": level + 1}

func recruit_garrison(current_gold: int) -> Dictionary:
	if not castle_owned:
		return _failure("Garnizon kurmak için kaleyi ele geçirmelisin.")
	if garrison_units >= get_garrison_capacity():
		return _failure("Garnizon dolu. Kışlayı yükselterek kapasiteyi artır.")
	if current_gold < GARRISON_RECRUIT_COST:
		return _failure("Bir muhafız toplamak için %d altın gerekiyor." % GARRISON_RECRUIT_COST)
	garrison_units += 1
	_apply_visuals()
	_mark_dirty()
	_refresh_panel_if_open()
	return {"ok": true, "gold": current_gold - GARRISON_RECRUIT_COST, "message": "Bir kale muhafızı garnizona katıldı. (%d/%d)" % [garrison_units, get_garrison_capacity()]}

func collect_taxes(current_gold: int) -> Dictionary:
	if not castle_owned:
		return _failure("Vergi toplamak için kaleyi ele geçirmelisin.")
	if tax_cooldown > 0.0:
		return _failure("Vergi sandığı %d saniye sonra hazır." % ceili(tax_cooldown))
	var income := get_tax_income()
	tax_cooldown = TAX_INTERVAL_SECONDS
	taxes_collected += income
	_mark_dirty()
	_refresh_panel_if_open()
	return {"ok": true, "gold": current_gold + income, "message": "Yerleşim vergisi toplandı: +%d altın. Sonraki tahsilat 3 dakika sonra." % income}

func get_summary() -> Dictionary:
	var costs: Dictionary = {}
	for building_id in BUILDING_IDS:
		costs[building_id] = get_upgrade_cost(building_id)
	return {
		"castle_owned": castle_owned,
		"building_levels": building_levels.duplicate(true),
		"upgrade_costs": costs,
		"garrison_units": garrison_units,
		"garrison_capacity": get_garrison_capacity(),
		"garrison_recruit_cost": GARRISON_RECRUIT_COST,
		"tax_cooldown": tax_cooldown,
		"tax_income": get_tax_income(),
		"taxes_collected": taxes_collected,
		"defense_rating": get_defense_rating()
	}

func to_dict() -> Dictionary:
	return {
		"building_levels": building_levels.duplicate(true),
		"garrison_units": garrison_units,
		"tax_cooldown": tax_cooldown,
		"taxes_collected": taxes_collected
	}

func _apply_visuals() -> void:
	if is_instance_valid(arena_ref) and arena_ref.has_method("apply_settlement_visual_state"):
		arena_ref.apply_settlement_visual_state(get_summary())

func _mark_dirty() -> void:
	if is_instance_valid(game_ref) and game_ref.has_method("_mark_progress_dirty"):
		game_ref._mark_progress_dirty()

func _refresh_panel_if_open() -> void:
	if is_instance_valid(game_ref) and game_ref.has_method("_refresh_settlement_panel_if_open"):
		game_ref._refresh_settlement_panel_if_open()

func _failure(message: String) -> Dictionary:
	return {"ok": false, "gold": int(game_ref.gold) if is_instance_valid(game_ref) else 0, "message": message}
