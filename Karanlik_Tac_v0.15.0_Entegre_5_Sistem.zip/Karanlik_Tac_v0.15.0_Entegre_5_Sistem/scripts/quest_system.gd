extends Node

# Data-driven quest journal. State is serialized through game.gd so legacy saves remain readable.
const QUEST_DEFINITIONS: Array[Dictionary] = [
	{"id":"main_01", "chain":"main", "title":"Sınırda Bir Yabancı", "description":"Yeldeğirmeni'nin batısındaki kurt sürüsü köyü tehdit ediyor.", "objective_event":"wolf_kill", "target":3, "objective":"3 kurt avla", "turn_in_role":"elder", "turn_in_name":"Eren", "reward_gold":90, "reward_xp":120, "next":"main_02"},
	{"id":"main_02", "chain":"main", "title":"Kırılan Sancaklar", "description":"Kara Pençe haydutları ticaret yolunu kapattı. Koral'ın verdiği bilgiyi doğrula.", "objective_event":"bandit_kill", "target":5, "objective":"5 haydut yen", "turn_in_role":"scout", "turn_in_name":"Koral", "reward_gold":180, "reward_xp":240, "next":"main_03"},
	{"id":"main_03", "chain":"main", "title":"Kayıp Krallığın İzleri", "description":"Kadim kalıntılar eski krallığın çöküşüne dair bir ipucu taşıyor.", "objective_event":"relic_found", "target":2, "objective":"2 kadim kalıntı bul", "turn_in_role":"guard", "turn_in_name":"Sınır Muhafızı Orven", "reward_gold":200, "reward_xp":280, "next":"main_04"},
	{"id":"main_04", "chain":"main", "title":"Tahtın Kaderi", "description":"Sınır Kalesi'nin kontrolünü ele geçir ve Eren'e haber ver.", "objective_event":"castle_captured", "target":1, "objective":"Sınır Kalesi'ni fethet", "turn_in_role":"elder", "turn_in_name":"Eren", "reward_gold":300, "reward_xp":400, "next":""},
	{"id":"side_01", "chain":"side", "title":"Sınırları Haritalamak", "description":"Diyarın farklı bölgelerini gez ve güvenli yolları kaydet.", "objective_event":"region_visit", "target":5, "objective":"5 farklı bölge keşfet", "turn_in_role":"scout", "turn_in_name":"Koral", "reward_gold":80, "reward_xp":110, "next":""},
	{"id":"side_02", "chain":"side", "title":"Kayıp Kervanın Emaneti", "description":"Terk edilmiş sandıklardan kervana ait eşyaları ara.", "objective_event":"chest_opened", "target":3, "objective":"3 hazine sandığı aç", "turn_in_role":"villager", "turn_in_name":"Köylüler", "reward_gold":70, "reward_xp":85, "next":""},
	{"id":"side_03", "chain":"side", "title":"İpek ve Zehir", "description":"Sis Bataklığı'ndaki örümcekler ticaret için gereken ipeği taşıyor.", "objective_event":"spider_kill", "target":3, "objective":"3 örümcek yen", "turn_in_role":"herbalist", "turn_in_name":"Lale", "reward_gold":90, "reward_xp":100, "next":""},
	{"id":"side_04", "chain":"side", "title":"Kara Maden", "description":"Demirci Boran için harabelerdeki iskeletlerden kemik parçaları topla.", "objective_event":"skeleton_kill", "target":3, "objective":"3 kadim iskelet yen", "turn_in_role":"blacksmith", "turn_in_name":"Boran", "reward_gold":110, "reward_xp":130, "next":""},
	{"id":"side_05", "chain":"side", "title":"Bataklığın Efendisi", "description":"Sis Bataklığı'ndaki dev yaratık geçişleri tehlikeli hâle getiriyor.", "objective_event":"bog_troll_kill", "target":1, "objective":"Bataklık devini yen", "turn_in_role":"guard", "turn_in_name":"Sınır Muhafızı Orven", "reward_gold":120, "reward_xp":160, "next":""},
	{"id":"side_06", "chain":"side", "title":"Ayaz Dişi'nin Kanadı", "description":"Kuzey zincirinde görülen ejder yavrusunun tehdidini ortadan kaldır.", "objective_event":"drake_kill", "target":1, "objective":"Ejder yavrusunu yen", "turn_in_role":"elder", "turn_in_name":"Eren", "reward_gold":220, "reward_xp":320, "next":""},
	{"id":"side_07", "chain":"side", "title":"Post Tüccarı", "description":"Lale için ormandaki kurtlardan sağlam post elde et.", "objective_event":"wolf_kill", "target":5, "objective":"5 kurt avla", "turn_in_role":"herbalist", "turn_in_name":"Lale", "reward_gold":100, "reward_xp":120, "next":""},
	{"id":"side_08", "chain":"side", "title":"Eski Taşların Sırrı", "description":"Mira, kayıp krallığın iki kalıntısını görmek istiyor.", "objective_event":"relic_found", "target":2, "objective":"2 kadim kalıntı bul", "turn_in_role":"merchant", "turn_in_name":"Mira", "reward_gold":130, "reward_xp":180, "next":""}
]
const VALID_STATES: Array[String] = ["locked", "active", "ready", "complete"]
const COMPANION_STORY_DATA: Dictionary = {
	"darian": {"title": "Son Nöbet", "description": "Darian'ın eski birliğini dağıtan haydutları bul ve üç akıncıyı yen.", "event": "bandit_kill", "target": 3, "objective": "3 haydut yen"},
	"runa": {"title": "Şifa Borcu", "description": "Runa'nın bataklık köyüne yardım edebilmesi için örümcek zehrinin kaynağını temizle.", "event": "spider_kill", "target": 3, "objective": "3 bataklık örümceği yen"},
	"taren": {"title": "Sınırın Ötesi", "description": "Taren'in kayıp keşif işaretlerini bulmak için dört ayrı bölgeyi dolaş.", "event": "region_visit", "target": 4, "objective": "4 farklı bölge keşfet"},
	"selka": {"title": "Kızıl İz", "description": "Selka'nın avladığı sürüyü tehdit eden kurtları takip et.", "event": "wolf_kill", "target": 4, "objective": "4 kurt yen"}
}
var quest_states: Dictionary = {}
var visited_regions: Array[String] = []
var story_branch: String = ""
var choice_flags: Dictionary = {}
var companion_stories: Dictionary = {}

func initialize(saved_state: Dictionary = {}) -> void:
	quest_states.clear()
	visited_regions.clear()
	var saved_regions: Variant = saved_state.get("visited_regions", [])
	if saved_regions is Array:
		for region_value in saved_regions:
			var region_name := str(region_value).strip_edges()
			if not region_name.is_empty() and not visited_regions.has(region_name):
				visited_regions.append(region_name)
	var saved_states: Variant = saved_state.get("quests", {})
	for definition in QUEST_DEFINITIONS:
		var quest_id := str(definition["id"])
		var default_status := "active" if str(definition["chain"]) == "side" else "locked"
		var row: Dictionary = {"state": default_status, "progress": 0}
		if saved_states is Dictionary and saved_states.get(quest_id, {}) is Dictionary:
			var stored: Dictionary = saved_states.get(quest_id, {})
			var safe_state := str(stored.get("state", default_status))
			row["state"] = safe_state if VALID_STATES.has(safe_state) else default_status
			row["progress"] = clampi(int(stored.get("progress", 0)), 0, int(definition["target"]))
		quest_states[quest_id] = row
	story_branch = str(saved_state.get("story_branch", ""))
	if story_branch not in ["people_first", "warlord"]:
		story_branch = ""
	choice_flags = {}
	var saved_flags: Variant = saved_state.get("choice_flags", {})
	if saved_flags is Dictionary:
		choice_flags = saved_flags.duplicate(true)
	companion_stories = {}
	var saved_companion_stories: Variant = saved_state.get("companion_stories", {})
	for companion_id in COMPANION_STORY_DATA.keys():
		var default_story: Dictionary = {"state": "inactive", "progress": 0, "choice": "", "loyalty": 50}
		if saved_companion_stories is Dictionary and saved_companion_stories.get(companion_id, {}) is Dictionary:
			var stored_story: Dictionary = saved_companion_stories.get(companion_id, {})
			var stored_state := str(stored_story.get("state", "inactive"))
			default_story["state"] = stored_state if stored_state in ["inactive", "active", "ready", "complete"] else "inactive"
			default_story["progress"] = clampi(int(stored_story.get("progress", 0)), 0, int(COMPANION_STORY_DATA[companion_id]["target"]))
			default_story["choice"] = str(stored_story.get("choice", ""))
			default_story["loyalty"] = clampi(int(stored_story.get("loyalty", 50)), 0, 100)
		companion_stories[companion_id] = default_story
	_update_region_quest_progress()

func activate_quest(quest_id: String) -> bool:
	if not quest_states.has(quest_id):
		return false
	var row: Dictionary = quest_states[quest_id]
	if str(row.get("state", "locked")) != "locked":
		return false
	row["state"] = "active"
	row["progress"] = 0
	quest_states[quest_id] = row
	return true

func seed_progress(quest_id: String, amount: int) -> bool:
	# Import progress earned before a sequential quest was unlocked; old progress never regresses.
	if not quest_states.has(quest_id):
		return false
	var definition: Dictionary = {}
	for candidate in QUEST_DEFINITIONS:
		if str(candidate.get("id", "")) == quest_id:
			definition = candidate
			break
	if definition.is_empty():
		return false
	var row: Dictionary = quest_states[quest_id]
	var state := str(row.get("state", "locked"))
	if state not in ["active", "ready"]:
		return false
	var target := int(definition.get("target", 1))
	var old_progress := int(row.get("progress", 0))
	var next_progress := clampi(maxi(old_progress, amount), 0, target)
	var next_state := "ready" if next_progress >= target else "active"
	if next_progress == old_progress and state == next_state:
		return false
	row["progress"] = next_progress
	row["state"] = next_state
	quest_states[quest_id] = row
	return true

func record_event(event_id: String, amount: int = 1) -> bool:
	if amount <= 0:
		return false
	var changed := false
	for definition in QUEST_DEFINITIONS:
		if str(definition.get("objective_event", "")) != event_id:
			continue
		var quest_id := str(definition["id"])
		var row: Dictionary = quest_states.get(quest_id, {})
		if str(row.get("state", "locked")) != "active":
			continue
		var target := int(definition["target"])
		var old_progress := int(row.get("progress", 0))
		var next_progress := mini(target, old_progress + amount)
		if next_progress == old_progress:
			continue
		row["progress"] = next_progress
		if next_progress >= target:
			row["state"] = "ready"
		quest_states[quest_id] = row
		changed = true
	var companion_changed := record_companion_event(event_id, amount)
	return changed or companion_changed

func record_region_visit(region_name: String) -> bool:
	var safe_name := region_name.strip_edges()
	if safe_name.is_empty() or visited_regions.has(safe_name):
		return false
	visited_regions.append(safe_name)
	_update_region_quest_progress()
	record_companion_event("region_visit", 1)
	return true

func _update_region_quest_progress() -> void:
	for definition in QUEST_DEFINITIONS:
		if str(definition.get("objective_event", "")) != "region_visit":
			continue
		var quest_id := str(definition["id"])
		var row: Dictionary = quest_states.get(quest_id, {})
		if str(row.get("state", "locked")) != "active":
			continue
		var target := int(definition["target"])
		row["progress"] = mini(target, visited_regions.size())
		if int(row["progress"]) >= target:
			row["state"] = "ready"
		quest_states[quest_id] = row

func has_active_main_quest_for_role(role: String) -> bool:
	for definition in QUEST_DEFINITIONS:
		if str(definition.get("chain", "")) != "main" or str(definition.get("turn_in_role", "")) != role:
			continue
		var row: Dictionary = quest_states.get(str(definition["id"]), {})
		if str(row.get("state", "")) in ["active", "ready"]:
			return true
	return false

func has_ready_quest_for_role(role: String) -> bool:
	for definition in QUEST_DEFINITIONS:
		var row: Dictionary = quest_states.get(str(definition["id"]), {})
		if str(definition.get("turn_in_role", "")) == role and str(row.get("state", "")) == "ready":
			return true
	return false

func claim_next_for_role(role: String) -> Dictionary:
	for definition in QUEST_DEFINITIONS:
		var quest_id := str(definition["id"])
		var row: Dictionary = quest_states.get(quest_id, {})
		if str(definition.get("turn_in_role", "")) != role or str(row.get("state", "")) != "ready":
			continue
		row["state"] = "complete"
		quest_states[quest_id] = row
		var next_id := str(definition.get("next", ""))
		if not next_id.is_empty():
			activate_quest(next_id)
		return {
			"ok": true,
			"id": quest_id,
			"title": str(definition.get("title", "Görev")),
			"gold": int(definition.get("reward_gold", 0)),
			"xp": int(definition.get("reward_xp", 0)),
			"next_id": next_id,
			"message": "Görev tamamlandı: %s" % str(definition.get("title", "Görev"))
		}
	return {"ok": false, "message": "Bu kişi için hazır bir görev yok."}

func get_primary_objective_text() -> String:
	for definition in QUEST_DEFINITIONS:
		if str(definition.get("chain", "")) != "main":
			continue
		var row: Dictionary = quest_states.get(str(definition["id"]), {})
		var status := str(row.get("state", "locked"))
		if status == "locked" or status == "complete":
			continue
		if status == "ready":
			return "ANA GÖREV: %s • %s'ye dön" % [str(definition["title"]).to_upper(), str(definition.get("turn_in_name", "görev verene"))]
		return "ANA GÖREV: %s • %d/%d" % [str(definition["title"]).to_upper(), int(row.get("progress", 0)), int(definition["target"])]
	return ""

func get_journal_text() -> String:
	var lines: Array[String] = ["KARANLIK TAÇ  /  GÖREV DEFTERİ", "Ana hikâye dört bölümden; yan görevler keşif ve ganimetlerden oluşur.", ""]
	for definition in QUEST_DEFINITIONS:
		var row: Dictionary = quest_states.get(str(definition["id"]), {})
		var status := str(row.get("state", "locked"))
		var marker := "[KİLİTLİ]" if status == "locked" else ("[TAMAM]" if status == "complete" else ("[TESLİM ET]" if status == "ready" else "[AKTİF]"))
		var progress_line := ""
		if status == "active" or status == "ready":
			progress_line = "\n   Hedef: %s (%d/%d)" % [str(definition.get("objective", "İlerle")), int(row.get("progress", 0)), int(definition["target"])]
		elif status == "locked":
			progress_line = "\n   Önceki ana görev tamamlanınca açılır."
		lines.append("%s %s%s\n   %s\n   Ödül: %d altın • %d XP" % [marker, str(definition["title"]), progress_line, str(definition["description"]), int(definition["reward_gold"]), int(definition["reward_xp"])])
	return "\n".join(PackedStringArray(lines))

func get_active_count() -> int:
	var count := 0
	for row_value in quest_states.values():
		if row_value is Dictionary and str(row_value.get("state", "")) in ["active", "ready"]:
			count += 1
	return count

func start_companion_story(companion_id: String) -> bool:
	if not COMPANION_STORY_DATA.has(companion_id):
		return false
	var row: Dictionary = companion_stories.get(companion_id, {"state": "inactive", "progress": 0, "choice": "", "loyalty": 50})
	if str(row.get("state", "inactive")) != "inactive":
		return false
	row["state"] = "active"
	row["progress"] = 0
	if companion_id == "taren":
		row["progress"] = mini(int(COMPANION_STORY_DATA[companion_id]["target"]), visited_regions.size())
		if int(row["progress"]) >= int(COMPANION_STORY_DATA[companion_id]["target"]):
			row["state"] = "ready"
	companion_stories[companion_id] = row
	return true

func record_companion_event(event_id: String, amount: int = 1) -> bool:
	if amount <= 0:
		return false
	var changed := false
	for companion_id in COMPANION_STORY_DATA.keys():
		var definition: Dictionary = COMPANION_STORY_DATA[companion_id]
		if str(definition.get("event", "")) != event_id:
			continue
		var row: Dictionary = companion_stories.get(companion_id, {})
		if str(row.get("state", "inactive")) != "active":
			continue
		var target := int(definition.get("target", 1))
		var next_progress := mini(target, int(row.get("progress", 0)) + amount)
		if next_progress == int(row.get("progress", 0)):
			continue
		row["progress"] = next_progress
		if next_progress >= target:
			row["state"] = "ready"
		companion_stories[companion_id] = row
		changed = true
	return changed

func get_companion_story(companion_id: String) -> Dictionary:
	if not COMPANION_STORY_DATA.has(companion_id):
		return {}
	var result: Dictionary = COMPANION_STORY_DATA[companion_id].duplicate(true)
	var state: Dictionary = companion_stories.get(companion_id, {"state": "inactive", "progress": 0, "loyalty": 50, "choice": ""}).duplicate(true)
	result.merge(state, true)
	return result

func resolve_companion_story(companion_id: String, choice_id: String) -> Dictionary:
	if not COMPANION_STORY_DATA.has(companion_id):
		return {"ok": false, "message": "Yoldaş hikâyesi bulunamadı."}
	if choice_id.is_empty():
		return {"ok": false, "message": "Bir karar seçmelisin."}
	var row: Dictionary = companion_stories.get(companion_id, {})
	if str(row.get("state", "")) != "ready":
		return {"ok": false, "message": "Kişisel görev henüz tamamlanmaya hazır değil."}
	row["state"] = "complete"
	row["choice"] = choice_id
	var loyalty_delta := 10 if choice_id.ends_with("_mercy") or choice_id.ends_with("_share") or choice_id.ends_with("_warn") or choice_id.ends_with("_forgive") else -5
	row["loyalty"] = clampi(int(row.get("loyalty", 50)) + loyalty_delta, 0, 100)
	companion_stories[companion_id] = row
	choice_flags["companion_" + companion_id] = choice_id
	return {"ok": true, "loyalty": int(row["loyalty"]), "loyalty_delta": loyalty_delta, "choice": choice_id, "message": "%s hikâyesi tamamlandı. Sadakat %d/100." % [str(COMPANION_STORY_DATA[companion_id].get("title", companion_id)), int(row["loyalty"])]}

func set_main_story_branch(branch_id: String) -> bool:
	if branch_id not in ["people_first", "warlord"] or not story_branch.is_empty():
		return false
	story_branch = branch_id
	choice_flags["main_final_path"] = branch_id
	return true

func to_dict() -> Dictionary:
	return {"quests": quest_states.duplicate(true), "visited_regions": visited_regions.duplicate(), "story_branch": story_branch, "choice_flags": choice_flags.duplicate(true), "companion_stories": companion_stories.duplicate(true)}
