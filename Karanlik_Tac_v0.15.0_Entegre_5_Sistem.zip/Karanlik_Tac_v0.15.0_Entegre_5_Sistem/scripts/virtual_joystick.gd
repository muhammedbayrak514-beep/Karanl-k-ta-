extends Control

signal value_changed(value: Vector2)

var value: Vector2 = Vector2.ZERO
var _touch_index: int = -1
var _mouse_down: bool = false
var _stick_radius: float = 58.0
var _dead_zone: float = 0.13

func _ready() -> void:
	custom_minimum_size = Vector2(190, 190)
	mouse_filter = Control.MOUSE_FILTER_STOP
	queue_redraw()

func _draw() -> void:
	var center := size * 0.5
	draw_circle(center, 78.0, Color(0.025, 0.04, 0.055, 0.48))
	draw_arc(center, 77.0, 0.0, TAU, 64, Color(0.68, 0.75, 0.8, 0.62), 3.0, true)
	draw_circle(center, 40.0, Color(0.3, 0.38, 0.43, 0.15))
	draw_circle(center + value * _stick_radius, 31.0, Color(0.78, 0.82, 0.84, 0.78))
	draw_arc(center + value * _stick_radius, 31.0, 0.0, TAU, 48, Color(0.96, 0.78, 0.39, 0.95), 3.0, true)

func _gui_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed and get_global_rect().has_point(event.position):
			_touch_index = event.index
			_update_value(event.position)
			accept_event()
		elif not event.pressed and event.index == _touch_index:
			_touch_index = -1
			_set_value(Vector2.ZERO)
			accept_event()
	elif event is InputEventScreenDrag and event.index == _touch_index:
		_update_value(event.position)
		accept_event()
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		_mouse_down = event.pressed
		if _mouse_down:
			_update_value(get_global_mouse_position())
		else:
			_set_value(Vector2.ZERO)
		accept_event()
	elif event is InputEventMouseMotion and _mouse_down:
		_update_value(get_global_mouse_position())
		accept_event()

func _update_value(global_position: Vector2) -> void:
	var offset := to_local(global_position) - size * 0.5
	var next_value := (offset / _stick_radius).limit_length(1.0)
	if next_value.length() < _dead_zone:
		next_value = Vector2.ZERO
	_set_value(next_value)

func _set_value(next_value: Vector2) -> void:
	if value.is_equal_approx(next_value):
		return
	value = next_value
	value_changed.emit(value)
	queue_redraw()
