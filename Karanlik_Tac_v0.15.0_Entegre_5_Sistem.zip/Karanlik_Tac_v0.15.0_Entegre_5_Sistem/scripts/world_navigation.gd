extends RefCounted

# Coarse A* navigation grid for an obstacle-rich open world. Grid points are cell centres.
const DEFAULT_WORLD_SIZE: float = 900.0
const DEFAULT_CELL_SIZE: float = 2.5
const UNIT_CLEARANCE: float = 0.45

var world_size: float = DEFAULT_WORLD_SIZE
var cell_size: float = DEFAULT_CELL_SIZE
var cells_per_side: int = 288
var grid: AStarGrid2D
var registered_obstacles: int = 0
var _obstacle_specs: Array[Dictionary] = []

func configure(size: float = DEFAULT_WORLD_SIZE, step: float = DEFAULT_CELL_SIZE) -> void:
	world_size = size
	cell_size = step
	cells_per_side = maxi(1, int(ceil(world_size / cell_size)))
	_obstacle_specs.clear()
	_create_grid()

func _create_grid() -> void:
	grid = AStarGrid2D.new()
	grid.region = Rect2i(0, 0, cells_per_side, cells_per_side)
	grid.cell_size = Vector2(cell_size, cell_size)
	grid.offset = Vector2(-world_size * 0.5, -world_size * 0.5)
	grid.default_compute_heuristic = AStarGrid2D.HEURISTIC_OCTILE
	grid.diagonal_mode = AStarGrid2D.DIAGONAL_MODE_ONLY_IF_NO_OBSTACLES
	grid.update()
	# Keep path destinations away from the solid boundary walls around the world.
	for edge in range(4):
		for i in range(cells_per_side):
			grid.set_point_solid(Vector2i(edge, i), true)
			grid.set_point_solid(Vector2i(cells_per_side - 1 - edge, i), true)
			grid.set_point_solid(Vector2i(i, edge), true)
			grid.set_point_solid(Vector2i(i, cells_per_side - 1 - edge), true)
	registered_obstacles = 0

func register_obstacle(center: Vector3, dimensions: Vector3, extra_clearance: float = UNIT_CLEARANCE) -> void:
	if grid == null:
		return
	_obstacle_specs.append({"center": center, "dimensions": dimensions, "clearance": extra_clearance})
	_paint_obstacle(center, dimensions, extra_clearance)
	registered_obstacles = _obstacle_specs.size()

func unregister_obstacle(center: Vector3, dimensions: Vector3) -> void:
	# Rebuild the coarse grid after removing a dynamic blocker so overlapping walls stay solid.
	var removed := false
	for i in range(_obstacle_specs.size() - 1, -1, -1):
		var spec: Dictionary = _obstacle_specs[i]
		var saved_center: Vector3 = spec["center"]
		var saved_dimensions: Vector3 = spec["dimensions"]
		if saved_center.distance_to(center) <= 0.1 and saved_dimensions.distance_to(dimensions) <= 0.1:
			_obstacle_specs.remove_at(i)
			removed = true
			break
	if not removed:
		return
	var saved_specs := _obstacle_specs.duplicate(true)
	_create_grid()
	for spec in saved_specs:
		var obstacle_center: Vector3 = spec["center"]
		var obstacle_dimensions: Vector3 = spec["dimensions"]
		_paint_obstacle(obstacle_center, obstacle_dimensions, float(spec["clearance"]))
	registered_obstacles = _obstacle_specs.size()

func _paint_obstacle(center: Vector3, dimensions: Vector3, extra_clearance: float = UNIT_CLEARANCE) -> void:
	if grid == null:
		return
	var half_world := world_size * 0.5
	var radius_x := maxf(0.25, dimensions.x * 0.5 + extra_clearance)
	var radius_z := maxf(0.25, dimensions.z * 0.5 + extra_clearance)
	var min_x := clampi(int(floor((center.x - radius_x + half_world) / cell_size)), 0, cells_per_side - 1)
	var max_x := clampi(int(floor((center.x + radius_x + half_world) / cell_size)), 0, cells_per_side - 1)
	var min_z := clampi(int(floor((center.z - radius_z + half_world) / cell_size)), 0, cells_per_side - 1)
	var max_z := clampi(int(floor((center.z + radius_z + half_world) / cell_size)), 0, cells_per_side - 1)
	if center.x + radius_x < -half_world or center.x - radius_x > half_world:
		return
	if center.z + radius_z < -half_world or center.z - radius_z > half_world:
		return
	for z in range(min_z, max_z + 1):
		var cell_center_z := -half_world + (float(z) + 0.5) * cell_size
		if absf(cell_center_z - center.z) > radius_z:
			continue
		for x in range(min_x, max_x + 1):
			var cell_center_x := -half_world + (float(x) + 0.5) * cell_size
			if absf(cell_center_x - center.x) <= radius_x:
				grid.set_point_solid(Vector2i(x, z), true)

func find_path(start: Vector3, destination: Vector3) -> PackedVector3Array:
	var result := PackedVector3Array()
	if grid == null:
		result.append(destination)
		return result
	var start_id := _nearest_walkable_id(start)
	var goal_id := _nearest_walkable_id(destination)
	if start_id.x < 0 or goal_id.x < 0:
		result.append(destination)
		return result
	var ids: Array[Vector2i] = grid.get_id_path(start_id, goal_id)
	if ids.is_empty():
		# Retain basic movement if an uncommon map edge or blocked pocket has no route.
		result.append(destination)
		return result
	for i in range(1, ids.size()):
		var id: Vector2i = ids[i]
		result.append(Vector3(
			-world_size * 0.5 + (float(id.x) + 0.5) * cell_size,
			0.0,
			-world_size * 0.5 + (float(id.y) + 0.5) * cell_size
		))
	# Use the exact destination only when its own grid cell is traversable.
	var destination_id := _world_to_id(destination)
	if _inside_grid(destination_id) and not grid.is_point_solid(destination_id):
		if result.is_empty() or Vector2(result[result.size() - 1].x - destination.x, result[result.size() - 1].z - destination.z).length() > 0.55:
			result.append(destination)
	return result

func is_world_position_walkable(position: Vector3) -> bool:
	if grid == null:
		return true
	var id := _world_to_id(position)
	return _inside_grid(id) and not grid.is_point_solid(id)

func _nearest_walkable_id(position: Vector3) -> Vector2i:
	var raw_id := _world_to_id(position)
	# Clamp world-edge requests to the innermost playable band of cells.
	var start := Vector2i(
		clampi(raw_id.x, 4, cells_per_side - 5),
		clampi(raw_id.y, 4, cells_per_side - 5)
	)
	if not grid.is_point_solid(start):
		return start
	var best := Vector2i(-1, -1)
	var best_distance := INF
	for radius in range(1, 9):
		for z in range(start.y - radius, start.y + radius + 1):
			for x in range(start.x - radius, start.x + radius + 1):
				if abs(x - start.x) != radius and abs(z - start.y) != radius:
					continue
				var candidate := Vector2i(x, z)
				if not _inside_grid(candidate) or grid.is_point_solid(candidate):
					continue
				var distance := Vector2(float(x - start.x), float(z - start.y)).length_squared()
				if distance < best_distance:
					best = candidate
					best_distance = distance
		if best.x >= 0:
			return best
	return best

func _world_to_id(position: Vector3) -> Vector2i:
	var half_world := world_size * 0.5
	return Vector2i(
		int(floor((position.x + half_world) / cell_size)),
		int(floor((position.z + half_world) / cell_size))
	)

func _inside_grid(id: Vector2i) -> bool:
	return id.x >= 0 and id.y >= 0 and id.x < cells_per_side and id.y < cells_per_side
