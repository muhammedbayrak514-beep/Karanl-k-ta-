# Karanlık Taç v0.7.0 — A* Yol Bulma ve Takım Hareketi

## Yeni özellikler
- `world_navigation.gd`: AStarGrid2D tabanlı, 2.5 metre hücre boyutlu açık dünya yol ağı.
- Kale, ev, kapı kulesi ve çarpışmalı mimari engeller oluşturulurken rota ızgarasında yürünemez hücreler işaretlenir.
- Askerler rota hedefini önbelleğe alır; hedef belirgin biçimde değişince, yol bittiğinde veya asker takılınca kontrollü biçimde yeniden rota hesaplar.
- Piyade ve süvari, hedefin tam merkezinde üst üste binmek yerine hedef çevresinde farklı yaklaşma noktalarına yönelir.
- Savaş takibi de A* yol ara noktalarını kullanır; v0.6'nın kısa menzilli ışınla yerel kaçınması son katman olarak korunur.
- Yol bulunamazsa birlik eski doğrudan hareket davranışına düşer; tek bir erişilemeyen hedef oyunun tamamını kilitlemez.
- Android sürümü 0.7.0 / sürüm kodu 7 olarak güncellendi.

## Kayıt uyumluluğu
- Yeni kayıt alanı eklenmediği için kayıt biçimi v4 olarak kaldı.
- v0.4/v0.5/v0.6 kayıt uyumluluğu korunur; yeni kayıtlarda oyun sürümü `0.7.0` yazılır.

## Bilinen sınırlar
- Bu, sahne genelindeki gerçek bir NavigationServer3D navmesh'i değil; engel hücreleri işaretlenmiş AStarGrid2D ızgarasıdır.
- Grid, çarpışma şekli olan mimari öğeleri kapsar; her görsel ağaç, kaya, masa veya dekorasyon otomatik olarak yürünemez hücre sayılmaz.
- Birimler hâlâ birbirlerine fiziksel olarak çarpabilir; dar kapıların otomatik formasyon oluşturması ve gelişmiş grup koordinasyonu sonraki sürüm işidir.
- Hedefin kendisi kapalı bir bölgede veya tamamen çevrili bir alandaysa en yakın erişilebilir hücreye kadar yaklaşma ya da doğrudan hareket geri dönüşü görülebilir.
- Godot motor parse/açılış testi ve APK derlemesi, bu ortamda Godot yürütücüsü bulunmadığı için ayrıca doğrulanmalıdır.

## Doğrulama
`python3 tools/validate_project.py` yol bulma scriptini, entegrasyonları, yerel kaynak yollarını ve sürüm metadatasını kontrol eder. Bu test, gerçek Godot motor doğrulamasının yerini tutmaz.
