# Karanlık Taç: Sınır Savaşı — v0.9.0

## Genel oyun geliştirmesi

### Dünya ve keşif
- 720 × 720 metrelik prosedürel dünya; orman, bataklık, karlı bölge, harabe, göl ve kale alanları korunup üç belirgin keşif noktasıyla zenginleştirildi.
- Kara Pençe Haydut Kampı: kazık çitler, giriş açıklığı, üç çadır, silah rafı, sancak ve kamp ateşi ışığı.
- Kırık Mızrak Meydanı: siper izleri, kırık mızraklar, savaş mezarları ve yıpranmış sancak.
- Ayaz Mağarası: buzlu giriş çerçevesi ve parlayan kristaller.
- 360 saniyelik gün-gece ışık döngüsü; yönlü ışık, ortam aydınlığı, ışık rengi ve sis yoğunluğu güncellenir.

### Silah sistemi ve çatışma
- Dört değiştirilebilir silah profili eklendi: uzun kılıç, uzun mızrak, ağır kılıç ve savaş baltası.
- Her profilin hasarı, menzili, saldırı bekleme süresi ve dayanıklılık maliyeti ayrıdır; oyuncunun silah modeli ve saldırı menzili seçime göre yenilenir.
- Masaüstünde R, dokunmatik HUD'da SİLAH düğmesiyle silahlar arasında geçiş yapılır.
- Shift ile koşma ve dayanıklılık tüketimi; boşta veya normal hareket sırasında dayanıklılığın geri kazanılması eklendi.
- Savunma başlangıcında 0,22 saniyelik zamanlamalı savuşturma penceresi bulunur. Başarılı zamanlamada hasar büyük ölçüde azaltılır.
- Kritik vuruş olasılığı ve kritik hasar çarpanı eklendi; hasar sayıları 3D alanda kısa süreli görünür.

### NPC ve görev
- Köylüler, muhafızlar ve izci kısa, yerel günlük dolaşım hedefleriyle daha az durağan görünür.
- İzcibaşı Koral, Kara Pençe haydut kampında beş düşmanı yenme görevi verir. Ödül: 180 altın, 240 XP ve Haydut Sancağı.
- İzciye daha görünür bir görev işareti eklendi.
- Harabe Hazinesi ve Kum Tapınağı Sandığı birer Kadim Kalıntı da verir.

### HUD, kayıt ve sürüm
- HUD'a dayanıklılık çubuğu, seçili silah adı ve dokunmatik silah değiştirme kontrolü bağlandı.
- Kayıt biçimi v6: silah tipi, dayanıklılık, haydut görevi ve yeni envanter öğeleri saklanır.
- Önceki v1–v5 kayıtlarının yüklenme yolu korunur; eksik yeni alanlar varsayılan değerlerle tamamlanır.
- Android export adı 0.9.0, sürüm kodu 9 olarak ayarlandı.
- Yapısal doğrulama betiği v0.9 sistemleri için güncellendi.

## Doğrulama durumu

- Kaynak dosya bağlantıları, sürüm ayarları, kayıt şeması, HUD-sinyal bağlantıları ve yeni sistemlerin kodda bulunması `tools/validate_project.py` ile kontrol edilir.
- ZIP bütünlüğü ayrıca `unzip -t` ile kontrol edilmelidir.
- Bu çalışma ortamında Godot yürütülebilir dosyası bulunmadığı için GDScript'in gerçek motor ayrıştırması, oynanış doğrulaması ve Android APK dışa aktarımı yerel ortamda yapılmış sayılmaz. GitHub Actions iş akışı bu motor testlerini çalıştırmak üzere korunmuştur.

## Bilinen sınırlar

- Dünya ve donanım modelleri stilize prosedürel geometri kullanır; harici yüksek çözünürlüklü model/doku paketleri ve hareket yakalama animasyonları yoktur.
- NPC günlük rutinleri küçük bir alan içindeki gezinme davranışıdır; tam diyalog ağacı veya saat bazlı görev takvimi değildir.
- Silah modelleri ve istatistikleri değişir ancak her silah için ayrı profesyonel saldırı animasyonu veya fizik tabanlı yakın dövüş çarpışması yoktur.
- Harita içeriği büyük ölçüde sabit yerleştirilmiştir; dinamik dünya ekonomisi, çevrimiçi çok oyuncu, prosedürel görev zinciri ve her nesne için fiziksel yıkım bu sürümün kapsamı dışındadır.
