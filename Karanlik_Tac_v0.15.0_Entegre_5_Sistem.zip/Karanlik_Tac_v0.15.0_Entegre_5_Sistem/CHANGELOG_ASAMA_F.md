# Aşama F — Grafik, performans ve Android kalite kapısı

## v0.14.0

- HUD'a GRAFİK paneli ve Düşük / Dengeli / Yüksek profilleri eklendi.
- Profil tercihi `user://karanlik_tac_graphics.cfg` dosyasında saklanır; oyun kayıt dosyasının biçimi değiştirilmez.
- Düşük profilde gölge, sis ve parıltı kapatılır; ağaç kümelerinin ve kayaların dörtte biri gizlenir; kalan dekoratif ağaç, kaya ve ufuk öğelerinin görünürlük mesafeleri azaltılır.
- Dengeli profilde daha kısa gölge mesafesi ve parıltısız atmosfer kullanılır. Yüksek profilde tam gölge, sis ve parıltı korunur.
- HUD'da gerçek zamanlı FPS ve işletim sistemi adı gösterilir.
- Yardımcı işlem paneli istatistik satırına çakışmayacak şekilde aşağı kaydırıldı ve GRAFİK düğmesi için genişletildi.
- Android build iş akışı APK arşiv bütünlüğünü kontrol eder, motor günlüklerini ve SHA-256 dosyasını ayrı tanılama artefaktı olarak yükler.
- Oyun sürümü 0.14.0, Android version code 14. Kayıt biçimi v9 olarak kalır; grafik tercihi ayrı dosyadadır.

## Test sınırları

Yerel yapısal doğrulayıcı ve Python testleri çalıştırılabilir. Bu geliştirme ortamında `godot` çalıştırıcısı yüklü değildir ve GitHub alan adına DNS/bağlantı kurulamadığından Godot parse/başlangıç testi veya APK dışa aktarma burada çalıştırılamadı. Bunlar `.github/workflows/build-android.yml` içinde GitHub Actions tarafından yürütülmelidir.
