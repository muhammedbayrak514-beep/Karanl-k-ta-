# Karanlık Taç v0.11.0 — Aşama C

Krallıklar ve ordu geliştirmesi. Ayrıntılar için `CHANGELOG_ASAMA_C.md` ve `docs/ASAMA_C_KRALLIKLAR_ORDULAR.md`.

- Beş krallık/grup, oyuncu itibarı ve fraksiyon ilişkileri.
- Krallığa yemin etme ve yeterli itibarla bağlılık değiştirme.
- Faction kontrollü bölge listesi ve kuşatmayla Sınır Kalesi'ni ele geçirme kaydı.
- Diplomasi paneli, bir kez verilen NPC tanışma itibarı ve itibar tabanlı hizmet fiyatları.
- 10 askerlik ordu kapasitesi, 10 konumlu formasyonlar, kalkanlı muhafız ve arbaletçi. Yeminli olduğun fraksiyonla savaşta dostluk hedef seçimine yansır.
- Kayıt v7; krallık verileri ve asker sınıfı/faksiyon kimliği saklanır.

Godot motoru ve Android cihaz testleri bu kod paketindeki statik testlerden ayrı olarak çalıştırılmalıdır.
