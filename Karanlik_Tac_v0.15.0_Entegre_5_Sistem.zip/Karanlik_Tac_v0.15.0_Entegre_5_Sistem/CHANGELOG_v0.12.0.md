# Karanlık Taç v0.12.0 — Aşama D

Aşama D; kuşatma akışını belirginleştirir, fetih ilerlemesini kayda alır, 10 birlik için ayrı kapı yaklaşım noktaları ekler ve kale ele geçirildikten sonra yerleşim yönetimini açar. Kışla/sur/pazar geliştirmeleri, garnizon askeri toplama, bekleme süreli vergi tahsilatı, avlu görselleri ve kayıt formatı v8 bu sürümün ana parçalarıdır.
