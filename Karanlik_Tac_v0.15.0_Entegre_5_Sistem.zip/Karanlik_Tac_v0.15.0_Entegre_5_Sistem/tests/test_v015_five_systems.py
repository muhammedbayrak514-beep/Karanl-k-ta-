"""Structural integration checks for the five v0.15.0 systems.

These tests verify source wiring and persistence; they are not Godot runtime tests.
"""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]

def read(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")

class V015FiveSystemsTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.project = read("project.godot")
        cls.export = read("export_presets.cfg")
        cls.game = read("scripts/game.gd")
        cls.kingdoms = read("scripts/kingdom_system.gd")
        cls.siege = read("scripts/siege_manager.gd")
        cls.arena = read("scripts/arena.gd")
        cls.quests = read("scripts/quest_system.gd")
        cls.hud = read("scripts/hud.gd")
        cls.world = read("scripts/world_life.gd")
        cls.caravan = read("scripts/caravan_agent.gd")

    def test_release_and_save_schema_are_aligned(self):
        self.assertIn('config/version="0.15.0"', self.project)
        self.assertIn('version/name="0.15.0"', self.export)
        self.assertIn('version/code=15', self.export)
        self.assertIn('SAVE_FORMAT_VERSION: int = 10', self.game)
        self.assertIn('"game_version": "0.15.0"', self.game)

    def test_kingdom_ai_has_war_peace_alliance_territory_and_persistence(self):
        for token in ('func advance_ai_turn()', 'func declare_war(', 'func make_peace(', 'func form_alliance(', 'func break_alliance('):
            self.assertIn(token, self.kingdoms)
        self.assertIn('"wars": faction_wars.duplicate(true)', self.kingdoms)
        self.assertIn('"alliances": faction_alliances.duplicate(true)', self.kingdoms)
        self.assertIn('"territories": territories.duplicate(true)', self.kingdoms)
        self.assertIn('kingdom_system.advance_ai_turn()', self.game)

    def test_three_siege_sites_have_separate_gates_and_saved_states(self):
        for site in ('frontier_castle', 'eastwatch_fort', 'frost_hold'):
            self.assertIn(f'"{site}"', self.siege)
        self.assertIn('"GateEastWatch"', self.siege)
        self.assertIn('"GateFrostHold"', self.siege)
        self.assertIn('"sites": site_states.duplicate(true)', self.siege)
        self.assertIn('"sieges": siege_manager.get_save_state()', self.game)
        self.assertIn('func _make_campaign_forts()', self.arena)

    def test_main_story_choices_and_endings_are_persistent(self):
        self.assertIn('func show_story_choices(', self.hud)
        self.assertIn('signal story_choice_pressed', self.hud)
        self.assertIn('hud.story_choice_pressed.connect(_on_story_choice_pressed)', self.game)
        self.assertIn('func set_main_story_branch(', self.quests)
        self.assertIn('"story_branch": story_branch', self.quests)
        self.assertIn('FİNAL · SINIRLARDA BARIŞ', self.game)
        self.assertIn('FİNAL · DEMİR TAÇ', self.game)

    def test_companion_stories_progress_persist_and_loyalty_affects_passives(self):
        for companion in ('darian', 'runa', 'taren', 'selka'):
            self.assertIn(f'"{companion}"', self.quests)
        self.assertIn('func record_companion_event(', self.quests)
        self.assertIn('func resolve_companion_story(', self.quests)
        self.assertIn('"companion_stories": companion_stories.duplicate(true)', self.quests)
        self.assertIn('func _companion_loyalty_scale(', self.game)
        self.assertIn('_companion_loyalty_scale("selka")', self.game)
        self.assertIn('_companion_loyalty_scale("darian")', self.game)
        self.assertIn('_companion_loyalty_scale("taren")', self.game)

    def test_living_world_has_weather_events_trade_and_moving_caravans(self):
        for weather in ('"clear"', '"rain"', '"fog"', '"snow"'):
            self.assertIn(weather, self.world)
        for event in ('"harvest_festival"', '"trade_boom"', '"bandit_surge"', '"lost_cache"'):
            self.assertIn(event, self.world)
        self.assertIn('func _create_caravans(', self.world)
        self.assertIn('func get_buy_price(', self.world)
        self.assertIn('func get_sell_price(', self.world)
        self.assertIn('add_to_group("traveling_caravans")', self.caravan)
        self.assertIn('"living_world": world_life.get_save_state()', self.game)
        self.assertIn('"lost_cache_id": lost_cache_id', self.world)
        self.assertIn('begins_with("world_event_bandit_")', self.game)

    def test_world_simulation_is_created_and_caravans_are_interactable(self):
        self.assertIn('const WorldLifeScript = preload("res://scripts/world_life.gd")', self.game)
        self.assertIn('world_life.initialize(self, world_ref', self.game)
        self.assertIn('func interact_with_caravan(', self.game)
        self.assertIn('func interact(game: Variant)', self.caravan)

if __name__ == "__main__":
    unittest.main()
