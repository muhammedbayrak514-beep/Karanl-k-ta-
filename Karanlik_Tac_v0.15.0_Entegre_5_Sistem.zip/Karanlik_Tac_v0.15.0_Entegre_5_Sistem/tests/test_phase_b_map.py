"""Offline structural tests for the Karanlık Taç v0.11.0 Phase B map."""
from __future__ import annotations

import re
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class PhaseBWorldTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.arena = (ROOT / "scripts/arena.gd").read_text(encoding="utf-8")
        cls.navigation = (ROOT / "scripts/world_navigation.gd").read_text(encoding="utf-8")
        cls.radar = (ROOT / "scripts/world_radar.gd").read_text(encoding="utf-8")
        cls.game = (ROOT / "scripts/game.gd").read_text(encoding="utf-8")
        cls.project = (ROOT / "project.godot").read_text(encoding="utf-8")
        cls.export = (ROOT / "export_presets.cfg").read_text(encoding="utf-8")

    def test_world_dimensions_and_navigation_resolution(self) -> None:
        self.assertIn("const WORLD_SIZE := 900.0", self.arena)
        self.assertIn("const GRID_CELLS := 180", self.arena)
        self.assertIn("navigation.configure(WORLD_SIZE, 2.5)", self.arena)
        self.assertIn("const DEFAULT_WORLD_SIZE: float = 900.0", self.navigation)

    def test_all_main_road_points_are_within_world_bounds(self) -> None:
        section = self.arena.split("const ROAD_SEGMENTS = [", 1)[1].split("\n]\nconst BIOME_ZONES", 1)[0]
        points = re.findall(r"Vector2\(\s*(-?\d+(?:\.\d+)?)\s*,\s*(-?\d+(?:\.\d+)?)\s*\)", section)
        self.assertGreaterEqual(len(points), 20)
        for x_raw, z_raw in points:
            x, z = float(x_raw), float(z_raw)
            with self.subTest(point=(x, z)):
                self.assertGreaterEqual(x, -450.0)
                self.assertLessEqual(x, 450.0)
                self.assertGreaterEqual(z, -450.0)
                self.assertLessEqual(z, 450.0)

    def test_five_new_landmarks_are_built_and_reported_as_regions(self) -> None:
        labels = (
            "BATI GÖZETLEME KULESİ",
            "KARAKIŞ MANASTIRI",
            "KÜL OVASI",
            "DOĞU SINIR GÖZETİMİ",
            "BATIK KERVAN DURAĞI",
        )
        self.assertIn("func _make_v10_landmarks()", self.arena)
        self.assertIn("\t_make_v10_landmarks()", self.arena)
        for label in labels:
            with self.subTest(label=label):
                self.assertIn(label, self.arena)
                self.assertIn(label, self.game)

    def test_radar_tracks_expanded_world(self) -> None:
        self.assertIn("var map_scale: float = 0.14", self.radar)
        for point in ("Vector2(-345, 42)", "Vector2(-292, -325)", "Vector2(8, 350)", "Vector2(362, -20)", "Vector2(295, 298)"):
            with self.subTest(point=point):
                self.assertIn(point, self.radar)

    def test_android_update_version_and_save_schema_are_aligned(self) -> None:
        self.assertIn('config/version="0.15.0"', self.project)
        self.assertIn('version/name="0.15.0"', self.export)
        self.assertIn("version/code=15", self.export)
        self.assertIn('"game_version": "0.15.0"', self.game)
        self.assertIn("SAVE_FORMAT_VERSION: int = 10", self.game)


if __name__ == "__main__":
    unittest.main(verbosity=2)
