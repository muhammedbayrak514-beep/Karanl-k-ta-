"""Offline structural checks for Karanlık Taç v0.11.0 kingdoms and armies."""
from __future__ import annotations
import re
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class PhaseCKingdomTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.kingdoms = (ROOT / "scripts/kingdom_system.gd").read_text(encoding="utf-8")
        cls.game = (ROOT / "scripts/game.gd").read_text(encoding="utf-8")
        cls.unit = (ROOT / "scripts/battle_unit.gd").read_text(encoding="utf-8")
        cls.hud = (ROOT / "scripts/hud.gd").read_text(encoding="utf-8")
        cls.project = (ROOT / "project.godot").read_text(encoding="utf-8")
        cls.export = (ROOT / "export_presets.cfg").read_text(encoding="utf-8")

    def test_five_factions_and_relations_exist(self) -> None:
        for faction in ("north_crown", "aurel_empire", "red_banner", "mountain_clans", "black_seal"):
            with self.subTest(faction=faction):
                self.assertIn(f'"{faction}"', self.kingdoms)
        self.assertIn("const BASE_RELATIONS: Dictionary", self.kingdoms)
        self.assertIn("func get_faction_relation", self.kingdoms)
        self.assertIn("func change_faction_relation", self.kingdoms)

    def test_reputation_oath_and_territories_are_saved(self) -> None:
        for method in ("func change_standing", "func record_hostile_kill", "func record_npc_meeting", "func can_pledge", "func pledge", "func capture_frontier_castle", "func get_territory_rows"):
            with self.subTest(method=method):
                self.assertIn(method, self.kingdoms)
        self.assertIn('"kingdoms": kingdom_system.to_dict()', self.game)
        self.assertIn('saved_state.get("relation_overrides", {})', self.kingdoms)
        restore_line = next(line for line in self.kingdoms.splitlines() if "relation_overrides[faction_a][faction_b] = clampi" in line)
        self.assertEqual(len(restore_line) - len(restore_line.lstrip("\t")), 6)

    def test_army_has_five_classes_and_sixteen_formation_slots_with_leadership_growth(self) -> None:
        self.assertIn("MAX_ALLIES: int = 10", self.game)
        for troop in ("infantry", "archer", "cavalry", "shield_guard", "crossbowman"):
            with self.subTest(troop=troop):
                self.assertIn(f'"{troop}"', self.game)
                self.assertIn(f'"{troop}"', self.unit)
        formation_block = self.unit.split("func _get_formation_target", 1)[1].split("func set_army_order", 1)[0]
        array_lines = [line for line in formation_block.splitlines() if "offsets = [" in line]
        self.assertEqual(len(array_lines), 3)
        for line in array_lines:
            with self.subTest(formation=line[:40]):
                positions = re.findall(r"Vector2\(([^,]+), ([^)]+)\)", line)
                self.assertEqual(len(positions), 16)
                self.assertEqual(len(set(positions)), 16, "formation offsets must be unique")
        self.assertIn("clampi(new_index, 0, 15)", self.unit)
        self.assertIn('MAX_ALLIES + int(skill_levels.get("leadership", 0)) * 2', self.game)

    def test_diplomacy_hud_and_recruitment_are_wired(self) -> None:
        self.assertIn('signal kingdom_panel_pressed', self.hud)
        self.assertIn('signal kingdom_pledge_pressed(faction_id: String)', self.hud)
        self.assertIn("func refresh_kingdom_panel", self.hud)
        self.assertIn("hud.kingdom_panel_pressed.connect", self.game)
        self.assertIn("hud.kingdom_pledge_pressed.connect", self.game)
        self.assertIn("_get_recruitment_cost", self.game)
        self.assertIn("ally.faction_id = kingdom_system.player_oath", self.game)
        self.assertIn("func is_faction_friendly_to_player", self.game)
        self.assertIn("is_faction_friendly_to_player(str(unit.faction_id))", self.game)
        self.assertIn("unit.team == 2", (ROOT / "scripts/player.gd").read_text(encoding="utf-8"))
        self.assertIn("is_faction_friendly_to_player(str(faction_id))", (ROOT / "scripts/battle_unit.gd").read_text(encoding="utf-8"))

    def test_android_version_and_save_format_match(self) -> None:
        self.assertIn('config/version="0.15.0"', self.project)
        self.assertIn('version/name="0.15.0"', self.export)
        self.assertIn("version/code=15", self.export)
        self.assertIn('"game_version": "0.15.0"', self.game)
        self.assertIn("SAVE_FORMAT_VERSION: int = 10", self.game)


if __name__ == "__main__":
    unittest.main(verbosity=2)
