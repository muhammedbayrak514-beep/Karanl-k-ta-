"""Offline structural tests for Karanlık Taç v0.14.0 Phase D-compatible tests."""
from __future__ import annotations
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

class PhaseDSiegeSettlementTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.game = (ROOT / "scripts/game.gd").read_text(encoding="utf-8")
        cls.siege = (ROOT / "scripts/siege_manager.gd").read_text(encoding="utf-8")
        cls.settlement = (ROOT / "scripts/settlement_manager.gd").read_text(encoding="utf-8")
        cls.hud = (ROOT / "scripts/hud.gd").read_text(encoding="utf-8")
        cls.arena = (ROOT / "scripts/arena.gd").read_text(encoding="utf-8")
        cls.project = (ROOT / "project.godot").read_text(encoding="utf-8")
        cls.export = (ROOT / "export_presets.cfg").read_text(encoding="utf-8")

    def test_settlement_management_core_systems(self) -> None:
        for method in ("func upgrade_building", "func recruit_garrison", "func collect_taxes", "func get_summary", "func to_dict"):
            with self.subTest(method=method):
                self.assertIn(method, self.settlement)
        for building_id in ("barracks", "walls", "market"):
            with self.subTest(building_id=building_id):
                self.assertIn(f'"{building_id}"', self.settlement)
        self.assertIn("TAX_INTERVAL_SECONDS: float = 180.0", self.settlement)
        self.assertIn('8 + get_building_level("barracks") * 4', self.settlement)

    def test_ui_actions_are_wired_to_game(self) -> None:
        self.assertIn("signal settlement_panel_pressed", self.hud)
        self.assertIn("signal settlement_action_pressed(action_id: String)", self.hud)
        self.assertIn("func refresh_settlement_panel", self.hud)
        self.assertIn("settlement_panel_pressed.connect(_on_settlement_panel_pressed)", self.game)
        self.assertIn("settlement_action_pressed.connect(_on_settlement_action_pressed)", self.game)
        for action_id in ("upgrade_barracks", "upgrade_walls", "upgrade_market", "recruit_garrison", "collect_taxes"):
            with self.subTest(action_id=action_id):
                self.assertIn(f'"{action_id}"', self.hud)
                self.assertIn(f'"{action_id}"', self.game)

    def test_building_upgrades_have_visible_world_effects(self) -> None:
        self.assertIn("func apply_settlement_visual_state", self.arena)
        for visual in ("BarracksBody", "MarketAwning", "WallMerlon"):
            with self.subTest(visual=visual):
                self.assertIn(visual, self.arena)
        self.assertIn("_apply_visuals()", self.settlement)
        self.assertIn("func get_settlement_defense_multiplier", self.game)
        self.assertIn("get_settlement_defense_multiplier(global_position)", (ROOT / "scripts/player.gd").read_text(encoding="utf-8"))

    def test_siege_progression_and_all_sixteen_approach_slots(self) -> None:
        self.assertIn("func get_current_phase_name", self.siege)
        self.assertIn("capture_attempt_active", self.siege)
        self.assertIn('"gate_assault_active": siege_manager.gate_assault_active', self.game)
        self.assertIn('"capture_progress": capture_progress', self.siege)
        block = self.siege.split("func get_gate_approach_position", 1)[1].split("func apply_gate_damage", 1)[0]
        for offset in ("-8.4", "-7.28", "-6.16", "-5.04", "-3.92", "-2.8", "-1.68", "-0.56", "0.56", "1.68", "2.8", "3.92", "5.04", "6.16", "7.28", "8.4"):
            with self.subTest(offset=offset):
                self.assertIn(offset, block)

    def test_save_and_android_version_migration(self) -> None:
        self.assertIn('"settlement": settlement_manager.to_dict()', self.game)
        self.assertIn("SAVE_FORMAT_VERSION: int = 10", self.game)
        self.assertIn('config/version="0.15.0"', self.project)
        self.assertIn('version/name="0.15.0"', self.export)
        self.assertIn("version/code=15", self.export)

if __name__ == "__main__":
    unittest.main(verbosity=2)
