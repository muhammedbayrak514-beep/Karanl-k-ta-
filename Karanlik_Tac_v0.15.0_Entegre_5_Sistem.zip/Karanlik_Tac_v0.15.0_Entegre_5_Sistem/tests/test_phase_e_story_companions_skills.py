"""Offline structural tests for Phase E story quests, companions and character progression."""
from __future__ import annotations
import unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]

class PhaseEStoryCompanionSkillTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.game = (ROOT / "scripts/game.gd").read_text(encoding="utf-8")
        cls.hud = (ROOT / "scripts/hud.gd").read_text(encoding="utf-8")
        cls.quests = (ROOT / "scripts/quest_system.gd").read_text(encoding="utf-8")
        cls.player = (ROOT / "scripts/player.gd").read_text(encoding="utf-8")

    def test_twelve_quest_definitions_and_states(self) -> None:
        self.assertGreaterEqual(self.quests.count('"id":"main_'), 4)
        self.assertGreaterEqual(self.quests.count('"id":"side_'), 8)
        for state in ("locked", "active", "ready", "complete"):
            self.assertIn(state, self.quests)
        self.assertIn("func claim_next_for_role", self.quests)
        self.assertIn("func seed_progress", self.quests)
        self.assertIn("func has_active_main_quest_for_role", self.quests)
        self.assertIn("visited_regions", self.quests)

    def test_story_events_and_legacy_progress_are_connected(self) -> None:
        for event in ("wolf_kill", "bandit_kill", "chest_opened", "relic_found", "castle_captured", "region_visit"):
            self.assertIn(event, self.game + self.quests)
        self.assertIn('"story": quest_system.to_dict()', self.game)
        self.assertIn('seed_progress("main_02", bandit_quest_count)', self.game)
        self.assertIn('seed_progress("main_03", int(inventory.get("ancient_relic", 0)))', self.game)

    def test_four_companions_have_real_ally_identity_and_passives(self) -> None:
        for companion in ("darian", "runa", "taren", "selka"):
            self.assertIn(companion, self.game)
        self.assertIn('"companion_id": str(unit.companion_id)', self.game)
        self.assertIn('"companion_name": str(unit.companion_name)', self.game)
        for method in ("get_companion_outgoing_damage_multiplier", "get_companion_incoming_damage_multiplier", "get_companion_move_multiplier"):
            self.assertIn(method, self.game)
            self.assertIn(method, self.player)

    def test_skill_tree_is_functional_and_saved(self) -> None:
        for skill in ("combat", "leadership", "survival"):
            self.assertIn(skill, self.game)
            self.assertIn(skill, self.hud)
        self.assertIn("skill_points += 1", self.game)
        self.assertIn('"skill_levels": skill_levels.duplicate(true)', self.game)
        self.assertIn("get_max_allies()", self.game)
        self.assertIn("offsets.size() - 1", (ROOT / "scripts/battle_unit.gd").read_text(encoding="utf-8"))
        self.assertIn('"army_count": count_units(2)', self.game)
        self.assertIn('summary.get("army_count", summary.get("count", 0))', self.hud)

    def test_gdscript_files_have_no_duplicate_top_level_members(self) -> None:
        import re
        from collections import Counter
        for script_path in (ROOT / "scripts").glob("*.gd"):
            source = script_path.read_text(encoding="utf-8")
            functions = re.findall(r"^func\s+(\w+)", source, re.MULTILINE)
            members = re.findall(r"^var\s+(\w+)", source, re.MULTILINE)
            duplicate_functions = [name for name, count in Counter(functions).items() if count > 1]
            duplicate_members = [name for name, count in Counter(members).items() if count > 1]
            with self.subTest(script=script_path.name):
                self.assertEqual(duplicate_functions, [], f"duplicate functions: {duplicate_functions}")
                self.assertEqual(duplicate_members, [], f"duplicate top-level variables: {duplicate_members}")

    def test_mobile_ui_signals_and_version_alignment(self) -> None:
        for signal in ("quest_journal_pressed", "companion_panel_pressed", "skills_panel_pressed", "skill_purchase_pressed"):
            self.assertIn(f"signal {signal}", self.hud)
            self.assertIn(f"hud.{signal}.connect", self.game)
        project = (ROOT / "project.godot").read_text(encoding="utf-8")
        export = (ROOT / "export_presets.cfg").read_text(encoding="utf-8")
        self.assertIn('config/version="0.15.0"', project)
        self.assertIn('version/name="0.15.0"', export)
        self.assertIn("version/code=15", export)
        self.assertIn("SAVE_FORMAT_VERSION: int = 10", self.game)

if __name__ == "__main__":
    unittest.main(verbosity=2)
