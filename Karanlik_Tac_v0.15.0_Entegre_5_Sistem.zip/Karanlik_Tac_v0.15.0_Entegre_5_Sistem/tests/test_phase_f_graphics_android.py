"""Offline structural checks for Phase F mobile graphics, performance and APK QA."""
from __future__ import annotations
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

class PhaseFGraphicsAndroidTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.game = (ROOT / "scripts/game.gd").read_text(encoding="utf-8")
        cls.hud = (ROOT / "scripts/hud.gd").read_text(encoding="utf-8")
        cls.arena = (ROOT / "scripts/arena.gd").read_text(encoding="utf-8")
        cls.project = (ROOT / "project.godot").read_text(encoding="utf-8")
        cls.export = (ROOT / "export_presets.cfg").read_text(encoding="utf-8")
        cls.workflow = (ROOT / ".github/workflows/build-android.yml").read_text(encoding="utf-8")

    def test_graphics_settings_ui_is_wired(self) -> None:
        self.assertIn('signal graphics_panel_pressed', self.hud)
        self.assertIn('signal graphics_quality_selected(quality_id: String)', self.hud)
        self.assertIn('hud.graphics_panel_pressed.connect(_on_graphics_panel_pressed)', self.game)
        self.assertIn('hud.graphics_quality_selected.connect(_on_graphics_quality_selected)', self.game)
        self.assertIn('graphics_panel_pressed.emit()', self.hud)
        self.assertIn('graphics_quality_selected.emit(id_for_callback)', self.hud)

    def test_quality_profiles_cover_lighting_and_decor_distance(self) -> None:
        self.assertIn('func apply_graphics_quality(quality_id: String)', self.arena)
        for quality in ('"low"', '"balanced"', '"high"'):
            self.assertIn(quality, self.arena)
        for group in ('quality_foliage', 'quality_foliage_cluster', 'quality_rocks', 'quality_horizon'):
            self.assertIn(group, self.arena)
        self.assertIn('sun_light.shadow_enabled = false', self.arena)
        self.assertIn('world_environment.environment.glow_enabled = false', self.arena)
        self.assertIn('rock.add_to_group("quality_rocks")', self.arena)
        self.assertIn('cluster.visible = quality != "low" or index % 4 != 0', self.arena)
        self.assertIn('rock_node.visible = quality != "low" or index % 4 != 0', self.arena)

    def test_quality_preference_is_stored_outside_game_save(self) -> None:
        self.assertIn('GRAPHICS_CONFIG_PATH: String = "user://karanlik_tac_graphics.cfg"', self.game)
        self.assertIn('ConfigFile.new()', self.game)
        self.assertIn('config.save(GRAPHICS_CONFIG_PATH)', self.game)
        self.assertIn('Engine.max_fps = 30 if graphics_quality == "low"', self.game)
        self.assertIn('SAVE_FORMAT_VERSION: int = 10', self.game)

    def test_live_fps_and_device_info_are_visible(self) -> None:
        self.assertIn('Engine.get_frames_per_second()', self.hud)
        self.assertIn('OS.get_name()', self.hud)
        self.assertIn('GraphicsPerformanceWindow', self.hud)
        self.assertIn('"GRAFİK"', self.hud)

    def test_project_and_android_version_alignment(self) -> None:
        self.assertIn('config/version="0.15.0"', self.project)
        self.assertIn('version/name="0.15.0"', self.export)
        self.assertIn('version/code=15', self.export)
        self.assertIn('window/handheld/orientation=0', self.project)
        self.assertIn('renderer/rendering_method.mobile="gl_compatibility"', self.project)

    def test_ci_checks_exported_apk_and_preserves_diagnostics(self) -> None:
        self.assertIn('godot --headless --editor --path . --quit', self.workflow)
        self.assertIn('godot --headless --path . --quit-after 180', self.workflow)
        self.assertIn('unzip -t build/KaranlikTac-debug.apk', self.workflow)
        self.assertIn('Karanlik-Tac-v0.15-build-diagnostics', self.workflow)
        self.assertIn('Karanlik-Tac-Android-APK', self.workflow)

if __name__ == "__main__":
    unittest.main(verbosity=2)
