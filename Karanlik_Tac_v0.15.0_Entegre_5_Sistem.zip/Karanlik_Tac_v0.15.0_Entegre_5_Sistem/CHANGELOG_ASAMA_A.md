# Aşama A — v0.9 sağlamlaştırma düzeltmeleri

Bu değişiklikler yeni oyun mekaniği eklemez; v0.9'un Godot/Android doğrulama hattını daha güvenilir hâle getirmeye odaklanır.

- Godot 4.7.2 ikilisi ve export templates indirme adresi resmî `godotengine/godot-builds` sürüm deposuna çevrildi.
- İndirmelere üç denemeye kadar yeniden deneme eklendi.
- Godot ikilisinin ve Android debug export template dosyalarının varlığı dışa aktarımdan önce kontrol ediliyor.
- Proje içe aktarma ve sahne başlatma çıktıları taranarak GDScript parse/runtime ve kaynak yükleme hataları CI işini başarısız kılıyor.
- Başsız sahne başlangıç kontrolü 10 kareden 180 kareye uzatıldı.
- Yapısal doğrulayıcı bu CI kontrollerini de denetliyor.
- `docs/ASAMA_A_V0.9_KALITE_KONTROLU.md` içine gerçek motor ve cihaz testleri için işaretlenebilir kontrol listesi eklendi.

## Doğrulama durumu

- Yapısal doğrulayıcı: geçti.
- Python doğrulayıcı sözdizimi kontrolü: geçti.
- ZIP içerik bütünlüğü: paket hazırlanırken ayrıca denetlenecek.
- Godot içe aktarma, başsız çalışma ve APK dışa aktarma: bu ortamda Godot çalıştırıcısı bulunmadığından henüz çalıştırılmadı.
- Gerçek Android cihaz testi: henüz yapılmadı.
