# Aşama D — Kuşatma ve Yerleşim Yönetimi

## Yeni sürüm: v0.12.0

- Kale kuşatması üç açık aşama adıyla gösterilir: hazırlık, ana kapı muhasarası, iç avlu/fetih.
- Kuşatma kaydı artık kapı saldırısı, fetih girişimi ve fetih ilerlemesini de saklar; eski v0.11 kayıtları varsayılan değerlerle yüklenir.
- Kapı önünde 10 askere kadar ayrı formasyon noktası tanımlandı.
- Kale ilk kez ele geçirilince oyuncuya 250 altın ve 220 XP verilir.
- Kale yönetim paneli eklendi: kışla, taş sur ve pazar 3 seviyeye kadar geliştirilebilir.
- Garnizona en fazla kışla seviyesiyle artan kapasite içinde muhafız alınabilir.
- Vergiler her 180 saniyede bir toplanabilir; pazar seviyesi geliri artırır.
- Yapı yükseltmeleri kalenin avlusuna düşük maliyetli görsel eklemeler uygular; sur ve garnizon bonusları iç avluda oyuncunun aldığı hasarı da azaltır.
- Yerleşim verileri kayıt yuvalarına yazılır. Kayıt biçimi v7'den v8'e yükseltildi.
- Android sürüm adı 0.12.0, sürüm kodu 12 oldu.

## Kontrol durumu

Bu pakette Python tabanlı yapısal kontroller ve ZIP bütünlük kontrolü yapılır. Godot GDScript ayrıştırma, gerçek 3D oynanış ve APK çalışma testi GitHub Actions'ta doğrulanmalıdır; çevrimdışı kontroller bunun yerine geçmez.
