# Karanlık Taç: Sınır Savaşı — Açık Dünya RPG

**Geliştirme sürümü:** 0.15.0 — Aşamalar A–F üzerine beş yeni sistem: krallık AI diplomasisi, üç bağımsız kuşatma sahası, dallanan hikâye, yoldaş kişisel görevleri ve yaşayan dünya simülasyonu. Godot motoru ve gerçek cihaz testi GitHub Actions üzerinde ayrıca doğrulanmalıdır.  
**Motor hedefi:** Godot 4.7.2 Stable  
**Hedef platformlar:** Android telefon/tablet ve masaüstü testleri  
**Görsel yaklaşım:** Kodla oluşturulan stilize 3D çevre, sınıfa göre farklılaştırılmış birlik modelleri, süvari bineği ve uçan ok mermileri


## v0.15.0 — Beş yeni oyun sistemi

- **Krallık yapay zekâsı:** Beş krallığın ilişki puanları, savaşları, barışları, ittifakları ve savaş sonuçlarına bağlı sınır değişimleri kampanya günlerinde simüle edilir. Oyuncunun sahip olduğu bölgeler otomatik olarak AI savaşlarında kaybedilmez. Diplomasi ve bölge sahipliği kaydedilir.
- **Üç bağımsız kuşatma:** Karanlık Taç Kalesi, Doğu Gözetleme Kalesi ve Karakış Kal'ası farklı kapılar, konumlar, avlu sınırları ve ayrı kaydedilen kapı/fetih ilerlemesi kullanır. Kuşatma paneli oyuncunun yaklaştığı sahaya geçer. Liderlikle 16 birliğe kadar kapı hattında ayrı yaklaşma konumları bulunur.
- **Kararlarla değişen ana hikâye:** Kadim kalıntı görevinden sonra “halkı koru” veya “demir taç” yolu seçilir. Seçim krallık itibarını, ödülleri/savaş avantajını ve son görevdeki final mesajını değiştirir; seçim kayıt dosyasında tutulur.
- **Yoldaşların kişisel hikâyeleri:** Darian, Runa, Taren ve Selka'nın farklı hedefleri vardır. Haydut yenme, örümcek temizleme ve yeni bölgeler keşfetme ilerlemeyi artırır. Görev sonunda verilen karar sadakati ve bazı yoldaş pasiflerinin gücünü değiştirir.
- **Yaşayan dünya:** Yağmur, sis, kar ve açık hava durumu değişebilir; hasat şenliği, ticaret hareketliliği, haydut akını ve kayıp erzak sandığı gibi olaylar başlar/sona erer. Üç hareketli kervan güzergâh kullanır, malzeme alım-satımı yapar ve dünya durumu kaydedilir.
- **Kayıt uyumluluğu:** Kayıt biçimi v10'a yükseltildi. Eski kayıtlarda bulunmayan alanlar varsayılanlarla oluşturulur; yeni savaş/diplomasi, kuşatma sahaları, hikâye kararları, yoldaş sadakati, hava, olay ve kervan verileri kaydedilir.

**Doğrulama notu:** `python3 tools/validate_project.py` ve `python3 -m unittest discover -s tests -v` yapısal kaynak kontrollerinden geçmelidir. Bunlar Godot motorunda çalıştırma veya APK testi değildir; gerçek motor açılışı ve Android çıktısı GitHub Actions üzerinde doğrulanmalıdır.

## Aşama B — açık dünya genişletmesi (ön sürüm)

- Oynanabilir alanın boyutu 720 × 720 metreden **900 × 900 metreye** çıkarıldı; A* yol bulma ızgarası aynı 2.5 metre hücre adımını korur.
- Merkez bölgeden çıkan ana yollar artık Batı Gözetleme Kulesi, Karakış Manastırı, Kül Ovası, Doğu Sınır Gözetimi ve Batık Kervan Durağı'na bağlanır.
- Bu beş yeni keşif noktasına kendine özgü stilize yapılar, tabelalar ve çevre ayrıntıları eklendi.
- Arazi renk haritasına karakış, kül, kıyı ve kervan bölgesi renk alanları eklendi; yeni alanlarda bitki ve taş dağılımı genişletildi.
- Mini harita ölçeği büyütülmüş alanı kapsayacak şekilde ayarlandı; ana yollar ve yeni işaret noktaları çiziliyor.
- Oyuncunun konumuna göre HUD bölge adı yeni yerler için güncellenir.
- Bu sürümde yeni yerlerin çoğu **keşif/çevre içeriğidir**; henüz bu noktaların tamamına özel görev, iç mekân veya etkileşimli zindan eklenmiş değildir.

Aşama B teknik kontrol listesi: `docs/ASAMA_B_ACIK_DUNYA.md`. Godot motor testi bu dosya kontrollerinden ayrıdır ve GitHub Actions/gerçek cihazda ayrıca yapılmalıdır.

## Önceki sürümlerden gelen savaş ve hareket sistemleri

### Gelişmiş savaş yapay zekâsı ve hareket
- Müttefik ve düşman askerler hedeflerini her karede taramak yerine kısa aralıklarla yeniler; hedef ölürse veya kaybolursa yeniden hedef aranır.
- Hedef seçimi mesafeye ek olarak hedefin kalan canını ve asker sınıfı tehdidini değerlendirir.
- Askerlerin önüne fizik ışınları gönderilerek duvar, kaya ve katı çevre engelleri algılanır; uygun olduğunda sağa/sola yerel kaçınma denenir.
- Uzun süre ilerleyemeyen birimlerde daha uzun yan kaçınma testi yapılır; birliklerin aynı noktada üst üste yığılması azaltılmaya çalışılır.
- Bu sistem tam A*/NavMesh rota planlaması değildir; dar kapılar ve karmaşık kale içleri hâlâ test gerektirir.


### A* yol bulma ve takım hareketi
- `scripts/world_navigation.gd`, Aşama B ile 900 × 900 metrelik dünyada 2.5 metre hücreli AStarGrid2D ızgarası kurar.
- Çarpışmalı kale duvarları, kuleler ve evler rota hücrelerine engel olarak kaydedilir.
- Askerler hedefe doğru doğrudan ilerlemek yerine önbelleğe alınan rota ara noktalarını takip eder. Hedef yeterince değişirse, yol biterse veya birim takılırsa yeniden planlama yapılır.
- Piyade ve süvari hedefin merkezine koşmak yerine hedef çevresindeki farklı yaklaşma noktalarını kullanır; aynı koordinata yığılma azaltılır.
- v0.6'dan gelen ışın tabanlı yerel kaçınma korunmuştur. A* rota bulamadığında temel doğrudan hareket geri dönüşü vardır.
- Teknik ayrıntılar: `docs/ASTAR_YOL_BULMA_v1.md`.

## Ordu komutanlığı
- HUD'daki **ORDU** panelinden birlik sayısı, asker sınıfları, aktif emir, formasyon ve altın görülebilir.
- **Takip et:** Birlik oyuncunun gerisinde seçili formasyon düzeninde hareket eder ve yakındaki düşmanlarla savaşır.
- **Mevzi tut:** Her asker bulunduğu noktayı savunma çapası olarak tutar. Yakına giren düşmana saldırır; daha uzaktaki düşmanın peşine sınırsız düşmez.
- **Hücum et:** Birlik daha geniş bir alanda düşman arar ve hedefe yönelir.
- **Geri çekil:** Askerler saldırıyı bırakır, komutana yaklaşır ve çok yakındaki düşmandan uzaklaşmaya çalışır.
- Emirler tüm müttefik askerlerine uygulanır; asker isim etiketleri sınıf ve emir bilgisini gösterir.

### Asker sınıfları (Aşama C)
| Sınıf | Özellik | Temel toplama maliyeti |
|---|---|---:|
| Piyade | Dengeli sağlık ve yakın dövüş | 25 altın |
| Okçu | Daha az sağlık, uzun menzilli ok mermisi | 35 altın |
| Süvari | Daha yüksek sağlık/hız/hasar; stilize at modeli | 50 altın |
| Kalkanlı muhafız | Yüksek sağlık, düşük hız ve güçlü savunma rolü | 60 altın |
| Arbaletçi | Uzun menzilli, yüksek hasarlı, daha yavaş atış | 55 altın |

- Temel ordu kapasitesi **10 canlı müttefiktir**. Aşama E’de Liderlik yeteneği her seviyede +2 kapasite verir; en üst seviyede kapasite **16 müttefike** çıkar ve hat, kama, sütun formasyonlarının her birinde 16 ayrı yerleşim noktası bulunur.
- Yeminli gruba göre bazı asker sınıflarının maliyeti düşer; tabloda bağlılık öncesi temel maliyetler gösterilir.
- Mevcut **DESTEK** düğmesi / masaüstünde **E** iki piyadeye kadar ücretsiz geçici takviye çağırır; 18 saniyelik bekleme süresi korunur.
- Okçuların hedefe ilerleyen görsel ok mermileri vardır; mermi hedefe ulaştığında hasar verir.
- Farklı sınıflar farklı can, hareket hızı, saldırı hasarı ve menzile sahiptir.

### Formasyonlar
- **Hat düzeni:** Üç asker genişliğinde iki sıra; açık arazide cephe oluşturur.
- **Kama:** Öne daralan, arkaya doğru genişleyen düzen.
- **Sütun:** Dar yollar için sıkı ve uzun yürüyüş düzeni.
- Formasyon konumları komutanın yönüne göre hesaplanır. Birimler A* hücre ızgarasıyla engel çevresinden rota arar; dar geçit ve karmaşık kale içi davranışları yine test gerektirir.

### Kayıt ve eski kayıtlarla uyumluluk
- Kayıt biçimi **v10** kullanılır. Kapı dayanıklılığı, kuşatma/fetih ilerlemesi, kale sahipliği, krallık ilişkileri, yerleşim yükseltmeleri, görev durumları, keşfedilen bölgeler, yetenek puanları ve yetenek seviyeleri kaydedilir. v1–v8 eski kayıtları varsayılan değerlerle yüklenebilir; yeni kayıtlar oyun sürümü 0.15.0 bilgisini taşır.
- Komutanın konumu/canı/istatistikleri, altın, XP, ekipman, envanter, görevler, açılmış sandıklar ve yenilmiş sabit yaratıklar korunur.
- Birliklerin sınıfı, canı, temel istatistikleri, konumu, formasyon indeksi, emir durumu, mevzi çapası; genel ordu emri ve formasyonu kaydedilir.
- Kayıt sırasında mevcut ordu kaydedilir; Liderlik yeteneğine göre kapasite 10–16 müttefik arasındadır. Kuşatmalarda 16 askere kadar ayrı kapı yaklaşım noktası bulunur.

## v0.9.0 — Dünyanın her tarafında geliştirme

### Harita ve atmosfer
- Dünya, 720 × 720 metre ölçüsündeki mevcut açık alanını korurken üç belirgin keşif noktasıyla zenginleştirildi: **Kara Pençe Haydut Kampı**, **Kırık Mızrak Meydanı** ve **Ayaz Mağarası**.
- Haydut kampına kazık çitler, çadırlar, silah rafı, sancak ve ışık veren kamp ateşi eklendi.
- Kırık Mızrak Meydanı'na siper izleri, kırık mızraklar, mezar işaretleri ve yırtık savaş sancağı eklendi.
- Ayaz Mağarası'nın girişinde buzlu taş çerçeve ve parlayan kristaller bulunur.
- Altı dakikalık gün-gece döngüsü yönlü ışık, ışık rengi, ortam aydınlığı ve sis yoğunluğunu değiştirir. Harita ve malzemeler yine kodla üretilir; dışarıdan model/doku indirme gerektirmez.

### Kılıçlar, silahlar ve savaş hissi
| Silah | Hasar çarpanı | Menzil | Saldırı beklemesi | Dayanıklılık bedeli |
|---|---:|---:|---:|---:|
| Uzun kılıç | 1.00× | 2.25 m | 0.78 sn | 12 |
| Uzun mızrak | 0.88× | 3.05 m | 1.03 sn | 10 |
| Ağır kılıç | 1.32× | 2.55 m | 1.12 sn | 18 |
| Savaş baltası | 1.18× | 2.12 m | 0.96 sn | 14 |

- **R** veya ekrandaki **SİLAH** düğmesi silahlar arasında geçiş yapar; model, menzil ve saldırı değerleri birlikte güncellenir.
- **Shift** koşar; koşma dayanıklılık harcar. Dayanıklılık saldırıda ve savunmada da kullanılır, dinlenirken yenilenir.
- Savunmanın başındaki 0.22 saniyelik doğru zamanlama penceresinde alınan hasar büyük ölçüde azaltılır. Bu pencere kaçırılırsa normal savunma devam eder.
- Kritik vuruşlar ek hasar verir. Darbe sayıları karakterlerin üzerinde belirip kaybolur; güçlü darbeler farklı renkle vurgulanır.

### NPC’ler, görevler ve ganimet
- Köylüler, muhafızlar ve izci kendi ev/iş noktalarının yakınında küçük günlük hareket rotaları kullanır; görsel boşta bekleme hareketleri de iyileştirildi.
- **İzcibaşı Koral**, Kara Pençe kampı görevini verir. Beş haydudu yen, Koral'a dön ve **180 altın, 240 XP ve Haydut Sancağı** ödülünü al.
- Harabe Hazinesi ve Kum Tapınağı Sandığı artık altın/XP yanında birer **Kadim Kalıntı** verir.
- Yeni silah seçimi, dayanıklılık, görev durumu ve yeni envanter öğeleri kayıt sistemine dahil edildi.

### Arayüz ve uyumluluk
- HUD'a dayanıklılık çubuğu ve seçili silah adı eklendi; silah değiştirme düğmesi dokunmatik ekranda da çalışır.
- Kayıt biçimi **v6**, Android sürüm kodu **9**, oyun sürümü **0.9.0** oldu. Eski v1–v5 kayıtlarını yükleme yolu korunur.
- Önceki sistemler de yerinde: A* yol bulma, ordu emirleri/formasyonları, üç temel asker sınıfı (Aşama C ile iki yeni sınıf eklendi), yıkılabilir kale kapısı, mancınık, kule savunması ve kale fethi.

Teknik ayrıntılar: `docs/GENEL_GELISTIRMELER_v0.9.0.md`.

## Projeyi açma

1. Godot **4.7.2 Standard** sürümünü aç.
2. Project Manager içinden `project.godot` dosyasını içe aktar.
3. Projeyi açıp `F5` ile çalıştır.
4. **ORDU** ile birliklerine emir ver; **KUŞAT** ile kaleye yaklaşınca kuşatma komutlarını aç. Kapıyı yık, iç avluyu temizle ve fetih emrini uygula.
5. `YUVALAR` ekranından ilerlemeyi ayrı kayıt yuvasına kaydet; v0.5'ten beri askerlerin durumu da kayıt altına alınır.

## Kontroller

| İşlem | Telefon/tablet | Bilgisayar |
|---|---|---|
| Hareket | Sol alttaki joystick | WASD veya ok tuşları |
| Kamera | Sağdaki boş alanı sürükle | Sağ fare tuşunu basılı tutup sürükle |
| Saldırı | SALDIR | Space |
| Savunma | SAVUN düğmesini basılı tut | Q veya Ctrl |
| Takviye | DESTEK | E |
| Koşma | KOŞU düğmesini basılı tut | Shift basılı tut |
| Silah değiştir | Üst araç çubuğundaki SİLAH | R |
| Etkileşim | ETKİLEŞ | F |
| Ordu menüsü | Sağ üstte ORDU | Sağ üstte ORDU |
| Kuşatma paneli | Sağ üstte KUŞAT | Sağ üstte KUŞAT |
| Kale/yerleşim yönetimi | ÜS düğmesi | ÜS düğmesi |
| Takip / mevzi / hücum / çekil | ORDU menüsü | F1 / F2 / F3 / F4 |
| Hat / kama / sütun | ORDU menüsü | 1 / 2 / 3 |
| Kayıt / yükleme | KAYDET / YÜKLE | KAYDET / YÜKLE |

## Android APK üretme — telefon/tabletten GitHub ile

Projede `.github/workflows/build-android.yml` iş akışı bulunur.

1. ZIP içindeki klasörün **içeriğini** GitHub deposunun köküne yükle. `project.godot` ve `.github/workflows/build-android.yml` doğru yerde olmalı.
2. GitHub'da **Actions → Build Android APK → Run workflow** yolunu izle.
3. İş akışı bağımsız proje kontrolü, Godot script/sahne içe aktarma ve 180 karelik başsız açılış testini çalıştırır; günlüklerde script/kaynak hatası arar ve ardından Android debug APK üretir. Godot ikilisi resmî `godotengine/godot-builds` sürüm deposundan alınır.
4. Başarılı çalıştırmada **Artifacts** bölümünden `Karanlik-Tac-Android-APK` paketini indir.

## Bilinen sınırlar

- Harita, aydınlatma ve silah modelleri prosedürel 3D geometri kullanır. Bu sürümde harici fotogerçekçi modeller, yüksek çözünürlüklü PBR doku paketi veya profesyonel hareket yakalama animasyonları yoktur.
- Gün-gece döngüsü görsel aydınlatmayı değiştirir; görevler henüz saat/uyku takvimine göre dallanmaz. NPC rotaları kısa ve ev çevresindeki gezinme hareketleridir; tam konuşma takvimi veya karmaşık günlük AI değildir.
- Silah değiştirme silahın görünüşünü ve savaş istatistiklerini değiştirir; her silahın ayrı hareket yakalama animasyonu ya da gerçek fizik tabanlı çarpışma şekli henüz yoktur.
- Haydut kampı karşılaşması sabittir; geniş kapsamlı sefer haritası, çevrimiçi çok oyuncu, tüm krallıklar için ayrı ekonomik üretim tabloları ve tam seslendirilmiş diyalog ağacı henüz yoktur. v0.15.0'daki diplomasi/ekonomi olayları hafif bir kampanya simülasyonudur.

- Bu hâlâ bir 3D RPG prototipidir; tam teşekküllü gerçek zamanlı strateji motoru değildir.
- A* ızgarası çarpışmalı mimari öğeleri kaydeder; her ağaç, kaya ve dekor öğesini otomatik engel saymaz. Yıkılan ana kapının engel hücreleri yeniden hesaplanır; diğer kapıların ve tüm mimari öğelerin dinamik yıkımı henüz yoktur. Dar geçitlerde otomatik formasyon geçişi de henüz yoktur.
- Süvari, kodla oluşturulmuş stilize bir at ve mızrak görseli kullanır; profesyonel rig/animasyonlu bineğe henüz sahip değildir.
- Oklar görsel 3D mermilerdir; çarpışma hedefe olan uzaklıkla hesaplanır, fizik tabanlı projectile collision değildir.
- Oyun varlıkları büyük harici model/doku paketleri yerine kodla oluşturulur; bu da görsel kaliteyi sınırlar.
- Bu çalışma ortamında Godot çalıştırıcısı bulunmadığı için motor parse/startup testi ve APK derlemesi burada yürütülemedi. GitHub Actions sonucuna bakılmalıdır.
- Kayıtlar `user://` uygulama alanındadır. Uygulama verilerini silmek veya uygulamayı kaldırmak dosyaları silebilir.

## v0.14.0 — Aşama F: grafik, performans ve Android

- Kuşatma ekranı hazırlık, ana kapı muhasarası ve iç avlu/fetih aşamalarını açıkça gösterir.
- Ana kale kapısı yaklaşımında ilk sürümde 10 müttefik için ayrı konumlar kullanılır; v0.15.0'da 16 birliğe çıkarıldı.
- Kale ilk kez fethedildiğinde 250 altın ve 220 XP verilir.
- **ÜS** panelinden kışla, taş sur ve pazar 3 seviyeye kadar yükseltilebilir; garnizon muhafızı alınabilir ve vergiler 180 saniyelik aralıkla toplanabilir.
- Yükseltmeler kale avlusunda hafif 3D görsel değişiklikler oluşturur. Garnizon henüz kendi başına gezen/savaşan ayrı NPC ordusu değildir; bina iç mekânları ve birden fazla bağımsız fethedilebilir kale sonraki geliştirmelerdir.
- Kayıt biçimi v8, Android version code 12 oldu; v1–v7 kayıtları yeni alanlar için varsayılanlarla okunur.

Teknik ayrıntılar: `docs/ASAMA_D_KUSATMA_YERLESIM.md`. Statik testler Godot motor testi yerine geçmez.

## Aşama A — sağlamlaştırma kontrol listesi

Aşama A testleri ve bu pakette yapılan CI düzeltmeleri için `docs/ASAMA_A_V0.9_KALITE_KONTROLU.md` dosyasına bak. Statik doğrulayıcı geçse bile Godot motor testi ve gerçek Android cihaz testi ayrıca yapılmalıdır.

## Proje kontrolü

```bash
python3 tools/validate_project.py
```

Bu bağımsız kontrol ana sahneyi, `res://` referanslarını, aktif sürüm numaralarını, silah/dayanıklılık/savuşturma sistemlerini, keşif bölgelerini, NPC görevini, A* yol bulma bağlantılarını, komutanlık/kuşatma/yerleşim sistemlerini, kayıt şemasını ve Android iş akışını denetler. Godot GDScript parse ve başsız oyun açılışı kontrolleri GitHub Actions içinde çalışır.

## Önceki sürüm: v0.8.0 — Kale kuşatması

- **Kuşatma paneli:** HUD üstündeki **KUŞAT** düğmesinden kuşatma komutlarına erişilir.
- **Kapı dayanıklılığı:** Kapıya yaklaşınca saldırı düğmesiyle hasar verilebilir; birlikler kapı önüne gönderilebilir.
- **Mancınık:** Kuşatma başladıktan sonra 25 altın karşılığında balistik mermi ateşlenir. Atışın yeniden hazırlanması 12 saniye sürer.
- **Savunma kuleleri:** Kuşatma sürerken kuleler kapı çevresindeki komutan ve dost askerlere belirli aralıklarla ok atar.
- **Fetih:** Kapı yıkıldıktan sonra iç avluya gir, savunmacıları temizle ve **FETİH EMRİ VER**. Avluda 10 saniye tutunmak kaleyi senin kontrolüne geçirir.
- **Kayıt uyumluluğu:** Kayıt formatı v5; kapı canı, kuşatmanın başlatılması ve kale sahipliği kayıt yuvasında tutulur. Eski v1–v4 kayıtlarının yüklenmesi korunur.

### Kuşatma test sınırı

Kuşatma mekanikleri kaynak koduna ve HUD komutlarına bağlanmıştır. Yapısal doğrulama yerel olarak yapılabilir; bu ortamda Godot çalıştırıcısı bulunmadığı için gerçek motor içi oynanış ve APK üretimi ayrıca GitHub Actions üzerinde doğrulanmalıdır.



## v0.13.0 — Aşama D: Kuşatma ve Yerleşim

- Üç aşamalı kuşatma durumu ve devam eden fetih ilerlemesi için kayıt desteği.
- 10 asker için ayrı kapı yaklaşım noktaları.
- Fetih ödülü: 250 altın ve 220 XP.
- Kale ele geçirildikten sonra kışla, sur, pazar, garnizon ve vergi yönetimi.
- Kayıt biçimi v8; Android version code 12.

Ayrıntılar: `docs/ASAMA_D_KUSATMA_YERLESIM.md`. Godot motor testi/Android APK testi GitHub Actions ile yapılmalıdır.


## Aşama E — Hikâye, yoldaşlar ve yetenekler

- Görev defteri için GÖREVLER düğmesini aç. Hazır görevi, ilgili NPC ile etkileşime girerek teslim et.
- Haritadaki parlayan yoldaş işaretlerinden Darian, Runa, Taren ve Selka'yı bul; yaklaş ve ETKİLEŞ ile ücret karşılığında ekibine al.
- Seviye atlayınca gelen yetenek puanlarını YETENEK ekranında kullan.
- GÖREVLER, YOLDAŞ ve YETENEK panelleri Android yatay ekranda HUD üzerinden açılır.
- Kayıt sürümü v9; eski kayıtlardaki eksik yeni alanlar varsayılanlarla tamamlanır.


# Aşama E Teknik Tasarımı

## Görev sistemi
`quest_system.gd` görev tanımlarını ve `locked/active/ready/complete` durumlarını merkezi olarak yönetir. Oyun sistemi olayları (wolf_kill, bandit_kill, spider_kill, skeleton_kill, bog_troll_kill, drake_kill, chest_opened, relic_found, region_visit, castle_captured) yayınlar. Her görev bir hedef NPC rolüne teslim edilir. Ana görevler `main_01`–`main_04` sırasında açılır; yan görevler bağımsız ilerler. Farklı bölge görevi ziyaret edilen benzersiz bölge adlarını sayar.

## Yoldaşlar
Dört yoldaş `battle_units` grubu içindeki mevcut müttefik AI'ını kullanır, böylece takip/hücum/mevzi komutları ve formasyonlar desteklenir. Her yoldaşın `companion_id` / `companion_name` alanı ordu kaydında tutulur.

- Darian: %8 alınan hasar azaltma.
- Runa: 24 saniyede bir komutana 12 can iyileştirme.
- Taren: %8 hareket hızı.
- Selka: %10 komutan saldırı hasarı.

Bu pasifler yalnızca ilgili yoldaş hayattaysa aktif sayılır.

## Yetenek ağacı
Her seviye atlamada 1 puan verilir. Her yetenek en fazla 3 seviyedir: Savaş Ustalığı (+%8 saldırı hasarı/seviye), Liderlik (+2 ordu kapasitesi/seviye), Hayatta Kalma (+15 azami can ve %4 hasar azaltma/seviye). Yetenek puanı ve seviyeler kayıt dosyasına yazılır.

## Kayıt uyumluluğu
Kayıt formatı v9'dur. `world.story` alanı görev durumu ve benzersiz ziyaretleri tutar. Önceki kayıtlarda `story` veya `skill_levels` bulunmazsa güvenli varsayılanlar yüklenir. Yoldaş kimlikleri `army` kayıtlarında tutulur; ayrı roster kopyası olmadığından yükleme çift yoldaş üretmez.

## Test sınırı
Python testleri dosya yapısı ve entegrasyon noktalarını doğrular; gerçek GDScript motor derlemesi için workflow'daki Godot import/startup adımları zorunludur.


## v0.15.0 — Beş büyük sistem entegrasyonu

- **Krallık diplomasisi:** kampanya günü ilerledikçe krallıklar arası düşmanlıklar savaşa dönüşebilir; savaşlar sınır toprağı kaybettirebilir, uzun savaşlar barışla bitebilir ve dost krallıklar ittifak kurabilir. Savaş, ittifak, ilişkiler, bölge sahipliği ve bekleme süreleri kaydedilir. Oyuncuya ait bölgeler AI tarafından otomatik alınmaz.
- **Üç kuşatma sahası:** Karanlık Taç Kalesi, Doğu Gözetleme Kalesi ve Karakış Kal'ası kendi kapı canına, saldırı ve fetih durumuna sahiptir. Yakın sahaya gelindiğinde o sahaya geçilir; uzaktayken komut vererek uzaktan kuşatma başlatılamaz.
- **Dallanan ana hikâye:** kalıntılar görevinden sonra halkı koruma veya güçle hükmetme seçimi açılır. Seçim itibar ve ödülleri değiştirir; son görev farklı final mesajıyla kapanır.
- **Yoldaş kişisel hikâyeleri:** Darian, Runa, Taren ve Selka'nın farklı hedefleri, ilerlemeleri, sadakatleri ve final seçimleri vardır. İlerleme, seçim ve sadakat kayıt dosyasına yazılır; sadakat, yoldaşın savaş pasifinin gücünü de değiştirir.
- **Yaşayan dünya:** yağmur, sis, kar ve açık hava arasında geçiş; süreli hasat/ticaret/haydut/kayıp sandık olayları; üç hareketli kervan ve etkinliğe göre değişen alış-satış fiyatları bulunur. Hava, olay zamanlayıcıları, gün sayacı ve kervan konumları kaydedilir.

**Test durumu:** Python yapısal/entegrasyon testleri kaynak dosyalarını ve bağlantıları kontrol eder; bunlar gerçek oyun testi değildir. Bu ortamda Godot editörü/çalıştırılabilir dosyası bulunmadığı için motor içi parse, oyun başlangıcı ve Android APK derlemesi burada doğrulanamadı. GitHub Actions iş akışı Godot import, headless startup ve APK dışa aktarma adımlarını içerir.
